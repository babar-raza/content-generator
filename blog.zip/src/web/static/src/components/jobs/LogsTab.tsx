import React from 'react';

const LogsTab: React.FC<{ jobId: string }> = ({ jobId }) => {
  return (
    <div className="text-center text-gray-500 py-8">
      Logs viewer - To be implemented in TASK-UI-011
    </div>
  );
};

export default LogsTab;
