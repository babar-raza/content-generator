import React from 'react';

const CheckpointsTab: React.FC<{ jobId: string }> = ({ jobId }) => {
  return (
    <div className="text-center text-gray-500 py-8">
      Checkpoints - To be implemented with TASK-UI-015
    </div>
  );
};

export default CheckpointsTab;
