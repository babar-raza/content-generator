"""Unit tests for job_execution_engine_enhanced.py.

Tests both legacy synchronous (JobExecutionEngineEnhanced) and modern async
(AsyncJobExecutionEngine) implementations.
"""

import asyncio
import pytest
import uuid
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch, call
from dataclasses import dataclass

from src.orchestration.job_execution_engine_enhanced import (
    JobStatusLegacy,
    JobExecution,
    JobExecutionEngineEnhanced,
    AsyncJobExecutionEngine,
    get_enhanced_engine
)
from src.orchestration.job_state import JobStatus, JobMetadata, JobState, StepExecution
from src.orchestration.execution_plan import ExecutionPlan, ExecutionStep


# ============================================================================
# Test JobStatusLegacy Enum
# ============================================================================

class TestJobStatusLegacy:
    """Test JobStatusLegacy enum."""

    def test_status_values(self):
        """Test all status enum values."""
        assert JobStatusLegacy.PENDING.value == "pending"
        assert JobStatusLegacy.RUNNING.value == "running"
        assert JobStatusLegacy.PAUSED.value == "paused"
        assert JobStatusLegacy.COMPLETED.value == "completed"
        assert JobStatusLegacy.FAILED.value == "failed"
        assert JobStatusLegacy.CANCELLED.value == "cancelled"

    def test_status_enum_members(self):
        """Test enum has all expected members."""
        statuses = [s.value for s in JobStatusLegacy]
        assert "pending" in statuses
        assert "running" in statuses
        assert "completed" in statuses
        assert "failed" in statuses


# ============================================================================
# Test JobExecution Dataclass
# ============================================================================

class TestJobExecution:
    """Test JobExecution dataclass."""

    def test_initialization_defaults(self):
        """Test JobExecution initialization with defaults."""
        job = JobExecution(
            job_id="test-123",
            workflow_name="test_workflow",
            correlation_id="corr-123"
        )

        assert job.job_id == "test-123"
        assert job.workflow_name == "test_workflow"
        assert job.correlation_id == "corr-123"
        assert job.status == JobStatusLegacy.PENDING
        assert job.started_at is None
        assert job.completed_at is None
        assert job.current_step is None
        assert job.progress == 0.0
        assert job.input_params == {}
        assert job.output_data == {}
        assert job.error_message is None
        assert job.metadata == {}
        assert job.logs == []

    def test_initialization_with_params(self):
        """Test JobExecution initialization with custom parameters."""
        job = JobExecution(
            job_id="test-456",
            workflow_name="custom_workflow",
            correlation_id="corr-456",
            status=JobStatusLegacy.RUNNING,
            progress=50.0,
            input_params={"topic": "AI"},
            metadata={"key": "value"}
        )

        assert job.status == JobStatusLegacy.RUNNING
        assert job.progress == 50.0
        assert job.input_params == {"topic": "AI"}
        assert job.metadata == {"key": "value"}

    def test_to_dict_basic(self):
        """Test JobExecution.to_dict() basic conversion."""
        job = JobExecution(
            job_id="test-789",
            workflow_name="dict_workflow",
            correlation_id="corr-789"
        )

        result = job.to_dict()

        assert result["job_id"] == "test-789"
        assert result["workflow_name"] == "dict_workflow"
        assert result["correlation_id"] == "corr-789"
        assert result["status"] == "pending"
        assert result["progress"] == 0.0
        assert result["topic"] == "Unknown"

    def test_to_dict_with_topic(self):
        """Test to_dict extracts topic from input_params."""
        job = JobExecution(
            job_id="test-topic",
            workflow_name="workflow",
            correlation_id="corr",
            input_params={"topic": "Machine Learning"}
        )

        result = job.to_dict()
        assert result["topic"] == "Machine Learning"

    def test_to_dict_logs_truncation(self):
        """Test to_dict truncates logs to last 100 entries."""
        job = JobExecution(
            job_id="test-logs",
            workflow_name="workflow",
            correlation_id="corr"
        )

        # Add 150 logs
        for i in range(150):
            job.logs.append({"message": f"log_{i}"})

        result = job.to_dict()
        assert len(result["logs"]) == 100
        assert result["logs"][0]["message"] == "log_50"  # First of last 100

    def test_add_log_basic(self):
        """Test add_log method."""
        job = JobExecution(
            job_id="test-log",
            workflow_name="workflow",
            correlation_id="corr"
        )

        job.add_log("INFO", "Test message")

        assert len(job.logs) == 1
        assert job.logs[0]["level"] == "INFO"
        assert job.logs[0]["message"] == "Test message"
        assert "timestamp" in job.logs[0]
        assert job.logs[0]["details"] == {}

    def test_add_log_with_details(self):
        """Test add_log with details dict."""
        job = JobExecution(
            job_id="test",
            workflow_name="workflow",
            correlation_id="corr"
        )

        job.add_log("ERROR", "Failed", {"code": 500, "reason": "timeout"})

        assert job.logs[0]["details"] == {"code": 500, "reason": "timeout"}

    def test_add_log_with_job_logger(self):
        """Test add_log calls job_logger if present."""
        mock_logger = Mock()
        job = JobExecution(
            job_id="test",
            workflow_name="workflow",
            correlation_id="corr",
            metadata={"job_logger": mock_logger}
        )

        job.add_log("WARNING", "Warning message")

        mock_logger.warning.assert_called_once_with("Warning message")


# ============================================================================
# Test JobExecutionEngineEnhanced (Legacy Synchronous Engine)
# ============================================================================

class TestJobExecutionEngineEnhanced:
    """Test legacy synchronous JobExecutionEngineEnhanced."""

    @pytest.fixture
    def mock_workflow_compiler(self):
        """Mock workflow compiler."""
        compiler = Mock()
        compiler.workflows = {}
        return compiler

    @pytest.fixture
    def mock_checkpoint_manager(self):
        """Mock checkpoint manager."""
        return Mock()

    @pytest.fixture
    def engine(self, mock_workflow_compiler, mock_checkpoint_manager, tmp_path):
        """Create engine with mocked dependencies."""
        with patch('src.orchestration.job_execution_engine_enhanced.Path') as mock_path:
            mock_path.return_value = tmp_path / "jobs"
            engine = JobExecutionEngineEnhanced(
                workflow_compiler=mock_workflow_compiler,
                checkpoint_manager=mock_checkpoint_manager,
                verbose=False,
                debug=False
            )
            engine.storage_dir = tmp_path / "jobs"
            engine.storage_dir.mkdir(parents=True, exist_ok=True)
            return engine

    def test_initialization(self, mock_workflow_compiler, mock_checkpoint_manager):
        """Test engine initialization."""
        engine = JobExecutionEngineEnhanced(
            workflow_compiler=mock_workflow_compiler,
            checkpoint_manager=mock_checkpoint_manager,
            verbose=True,
            debug=True
        )

        assert engine.workflow_compiler == mock_workflow_compiler
        assert engine.checkpoint_manager == mock_checkpoint_manager
        assert engine.verbose is True
        assert engine.debug is True
        assert engine._jobs == {}
        assert engine._status_callbacks == []
        assert engine._progress_callbacks == []

    def test_initialization_creates_storage_dir(self, mock_workflow_compiler, mock_checkpoint_manager, tmp_path):
        """Test initialization creates storage directory."""
        with patch('src.orchestration.job_execution_engine_enhanced.Path') as mock_path_cls:
            mock_path = tmp_path / "test_jobs"
            mock_path_cls.return_value = mock_path

            engine = JobExecutionEngineEnhanced(
                workflow_compiler=mock_workflow_compiler,
                checkpoint_manager=mock_checkpoint_manager
            )

            assert mock_path.exists()

    def test_resolve_workflow_from_compiler_profiles(self, engine):
        """Test _resolve_workflow_definition from compiler profiles."""
        engine.workflow_compiler.workflows = {
            "profiles": {
                "test_workflow": {
                    "name": "test_workflow",
                    "steps": {"step1": {"agent": "agent1"}}
                }
            }
        }

        result = engine._resolve_workflow_definition("test_workflow")

        assert result["name"] == "test_workflow"
        assert "steps" in result

    def test_resolve_workflow_from_compiler_direct(self, engine):
        """Test _resolve_workflow_definition from compiler direct key."""
        engine.workflow_compiler.workflows = {
            "my_workflow": {
                "name": "my_workflow",
                "steps": {"step1": {"agent": "agent1"}}
            }
        }

        result = engine._resolve_workflow_definition("my_workflow")

        assert result["name"] == "my_workflow"

    def test_resolve_workflow_synthesized_fallback(self, engine):
        """Test _resolve_workflow_definition synthesized fallback."""
        result = engine._resolve_workflow_definition("unknown_workflow")

        assert result["synthesized"] is True
        assert "steps" in result
        assert "ingest" in result["steps"]
        assert "plan" in result["steps"]
        assert "generate" in result["steps"]

    def test_pipeline_from_workflow_dict_steps(self, engine):
        """Test _pipeline_from_workflow with dict steps."""
        workflow_def = {
            "steps": {
                "step1": {"name": "Step 1", "agent": "agent1"},
                "step2": {"name": "Step 2", "agent": "agent2"}
            }
        }

        pipeline = engine._pipeline_from_workflow(workflow_def)

        assert len(pipeline) == 2
        assert pipeline[0]["id"] in ["step1", "step2"]
        assert all(s["status"] == "pending" for s in pipeline)

    def test_pipeline_from_workflow_list_steps(self, engine):
        """Test _pipeline_from_workflow with list steps."""
        workflow_def = {
            "steps": [
                {"id": "s1", "name": "Step 1", "agent": "agent1"},
                {"id": "s2", "name": "Step 2", "agent": "agent2"}
            ]
        }

        pipeline = engine._pipeline_from_workflow(workflow_def)

        assert len(pipeline) == 2
        assert pipeline[0]["id"] == "s1"

    def test_pipeline_from_workflow_empty_steps(self, engine):
        """Test _pipeline_from_workflow with empty steps."""
        workflow_def = {"steps": {}}

        pipeline = engine._pipeline_from_workflow(workflow_def)

        assert pipeline == []

    def test_get_job(self, engine):
        """Test get_job retrieval."""
        job = JobExecution(
            job_id="get-test",
            workflow_name="workflow",
            correlation_id="corr"
        )
        engine._jobs["get-test"] = job

        result = engine.get_job("get-test")

        assert result == job

    def test_get_job_not_found(self, engine):
        """Test get_job returns None for missing job."""
        result = engine.get_job("nonexistent")
        assert result is None

    def test_get_all_jobs(self, engine):
        """Test get_all_jobs returns all jobs."""
        job1 = JobExecution(job_id="j1", workflow_name="w1", correlation_id="c1")
        job2 = JobExecution(job_id="j2", workflow_name="w2", correlation_id="c2")
        engine._jobs["j1"] = job1
        engine._jobs["j2"] = job2

        result = engine.get_all_jobs()

        assert len(result) == 2
        assert job1 in result
        assert job2 in result

    def test_register_status_callback(self, engine):
        """Test register_status_callback."""
        callback = Mock()

        engine.register_status_callback(callback)

        assert callback in engine._status_callbacks

    def test_register_progress_callback(self, engine):
        """Test register_progress_callback."""
        callback = Mock()

        engine.register_progress_callback(callback)

        assert callback in engine._progress_callbacks

    def test_notify_status_change(self, engine):
        """Test _notify_status_change calls callbacks."""
        callback1 = Mock()
        callback2 = Mock()
        engine._status_callbacks = [callback1, callback2]

        job = JobExecution(job_id="test", workflow_name="w", correlation_id="c")
        engine._notify_status_change(job)

        callback1.assert_called_once_with(job)
        callback2.assert_called_once_with(job)

    def test_notify_progress(self, engine):
        """Test _notify_progress calls callbacks."""
        callback = Mock()
        engine._progress_callbacks = [callback]

        engine._notify_progress("job-123", 50.0, "Processing")

        callback.assert_called_once_with("job-123", 50.0, "Processing")

    def test_make_serializable_path(self, engine):
        """Test _make_serializable converts Path to string."""
        test_path = Path("/test/path")
        result = engine._make_serializable(test_path)
        assert result == str(test_path)

    def test_make_serializable_datetime(self, engine):
        """Test _make_serializable converts datetime to ISO string."""
        dt = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        result = engine._make_serializable(dt)
        assert result == "2025-01-01T12:00:00+00:00"

    def test_make_serializable_dict(self, engine):
        """Test _make_serializable handles nested dicts."""
        test_path = Path("/test")
        obj = {"path": test_path, "date": datetime(2025, 1, 1, tzinfo=timezone.utc)}
        result = engine._make_serializable(obj)

        assert result["path"] == str(test_path)
        assert "2025-01-01" in result["date"]

    def test_make_serializable_list(self, engine):
        """Test _make_serializable handles lists."""
        path_a = Path("/a")
        path_b = Path("/b")
        obj = [path_a, path_b]
        result = engine._make_serializable(obj)

        assert result == [str(path_a), str(path_b)]

    def test_persist_job(self, engine):
        """Test _persist_job writes job to file."""
        job = JobExecution(
            job_id="persist-test",
            workflow_name="workflow",
            correlation_id="corr"
        )

        # Create job directory
        job_dir = engine.storage_dir / "persist-test"
        job_dir.mkdir(parents=True, exist_ok=True)

        engine._persist_job(job)

        job_file = job_dir / "job.json"
        assert job_file.exists()

    def test_load_job(self, engine):
        """Test _load_job reads job from file."""
        job = JobExecution(
            job_id="load-test",
            workflow_name="workflow",
            correlation_id="corr",
            status=JobStatusLegacy.COMPLETED,
            progress=100.0
        )

        # Create job directory
        job_dir = engine.storage_dir / "load-test"
        job_dir.mkdir(parents=True, exist_ok=True)

        engine._persist_job(job)

        loaded = engine._load_job("load-test")

        assert loaded is not None
        assert loaded.job_id == "load-test"
        assert loaded.workflow_name == "workflow"
        assert loaded.status == JobStatusLegacy.COMPLETED
        assert loaded.progress == 100.0

    def test_load_job_not_found(self, engine):
        """Test _load_job returns None for missing job."""
        result = engine._load_job("nonexistent")
        assert result is None

    def test_load_persisted_jobs(self, engine):
        """Test load_persisted_jobs loads all jobs from disk."""
        job1 = JobExecution(job_id="j1", workflow_name="w1", correlation_id="c1")
        job2 = JobExecution(job_id="j2", workflow_name="w2", correlation_id="c2")

        # Create job directories
        (engine.storage_dir / "j1").mkdir(parents=True, exist_ok=True)
        (engine.storage_dir / "j2").mkdir(parents=True, exist_ok=True)

        engine._persist_job(job1)
        engine._persist_job(job2)
        engine._jobs.clear()

        engine.load_persisted_jobs()

        assert len(engine._jobs) == 2
        assert "j1" in engine._jobs
        assert "j2" in engine._jobs

    def test_get_job_logs_success(self, engine):
        """Test get_job_logs returns log file content."""
        job = JobExecution(job_id="log-test", workflow_name="w", correlation_id="c")
        log_dir = engine.storage_dir / "log-test" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "job.log"
        log_file.write_text("Log line 1\nLog line 2", encoding="utf-8")
        job.metadata["log_file"] = str(log_file)
        engine._jobs["log-test"] = job

        result = engine.get_job_logs("log-test")

        assert result == "Log line 1\nLog line 2"

    def test_get_job_logs_no_job(self, engine):
        """Test get_job_logs returns None for missing job."""
        result = engine.get_job_logs("nonexistent")
        assert result is None

    def test_get_job_logs_no_file(self, engine):
        """Test get_job_logs returns None when log file doesn't exist."""
        job = JobExecution(job_id="test", workflow_name="w", correlation_id="c")
        job.metadata["log_file"] = "/nonexistent/path.log"
        engine._jobs["test"] = job

        result = engine.get_job_logs("test")
        assert result is None


# ============================================================================
# Test AsyncJobExecutionEngine (Modern Async Engine)
# ============================================================================

class TestAsyncJobExecutionEngine:
    """Test modern async AsyncJobExecutionEngine."""

    @pytest.fixture
    def mock_compiler(self):
        """Mock WorkflowCompiler."""
        compiler = Mock()
        plan = ExecutionPlan(
            workflow_id="test_workflow",
            steps=[
                ExecutionStep(agent_id="agent1", dependencies=[], metadata={})
            ]
        )
        compiler.compile = Mock(return_value=plan)
        return compiler

    @pytest.fixture
    def mock_registry(self):
        """Mock EnhancedAgentRegistry."""
        registry = Mock()
        agent = Mock()
        agent.run = Mock(return_value={"result": "success"})
        registry.get_agent = Mock(return_value=agent)
        return registry

    @pytest.fixture
    def mock_event_bus(self):
        """Mock EventBus."""
        return Mock()

    @pytest.fixture
    def mock_config(self):
        """Mock Config."""
        return Mock()

    @pytest.fixture
    def engine(self, mock_compiler, mock_registry, mock_event_bus, mock_config, tmp_path):
        """Create async engine with mocked dependencies."""
        engine = AsyncJobExecutionEngine(
            compiler=mock_compiler,
            registry=mock_registry,
            event_bus=mock_event_bus,
            config=mock_config,
            max_concurrent_jobs=2,
            storage_dir=tmp_path / "async_jobs"
        )
        return engine

    @pytest.mark.asyncio
    async def test_initialization(self, mock_compiler, mock_registry, tmp_path):
        """Test async engine initialization."""
        engine = AsyncJobExecutionEngine(
            compiler=mock_compiler,
            registry=mock_registry,
            max_concurrent_jobs=3,
            storage_dir=tmp_path
        )

        assert engine.compiler == mock_compiler
        assert engine.registry == mock_registry
        assert engine.max_concurrent_jobs == 3
        assert engine._jobs == {}
        assert engine._running is False

    @pytest.mark.asyncio
    async def test_start_engine(self, engine):
        """Test starting the async engine."""
        await engine.start()

        assert engine._running is True
        assert len(engine._worker_tasks) == 2

        await engine.stop()

    @pytest.mark.asyncio
    async def test_stop_engine(self, engine):
        """Test stopping the async engine."""
        await engine.start()
        await engine.stop(timeout=1.0)

        assert engine._running is False
        assert len(engine._worker_tasks) == 0

    @pytest.mark.asyncio
    async def test_submit_job(self, engine, mock_compiler):
        """Test submitting a job."""
        job_id = await engine.submit_job(
            workflow_id="test_workflow",
            inputs={"topic": "AI"},
            correlation_id="corr-123"
        )

        assert job_id is not None
        assert job_id in engine._jobs
        mock_compiler.compile.assert_called_once_with("test_workflow")

    @pytest.mark.asyncio
    async def test_submit_job_emits_event(self, engine, mock_event_bus):
        """Test submit_job emits JobSubmitted event."""
        await engine.submit_job("workflow", {"data": "test"})

        assert mock_event_bus.publish.called

    @pytest.mark.asyncio
    async def test_get_job_status(self, engine):
        """Test getting job status."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        status = await engine.get_job_status(job_id)

        assert status is not None
        assert status.job_id == job_id
        assert status.workflow_id == "workflow"

    @pytest.mark.asyncio
    async def test_get_job_status_not_found(self, engine):
        """Test get_job_status returns None for missing job."""
        status = await engine.get_job_status("nonexistent")
        assert status is None

    @pytest.mark.asyncio
    async def test_pause_job(self, engine):
        """Test pausing a running job."""
        await engine.start()
        job_id = await engine.submit_job("workflow", {"data": "test"})

        # Set status to running manually for test
        async with engine._lock:
            engine._jobs[job_id].metadata.status = JobStatus.RUNNING
            engine._pause_events[job_id] = asyncio.Event()

        result = await engine.pause_job(job_id)

        assert result is True
        await engine.stop()

    @pytest.mark.asyncio
    async def test_pause_job_not_running(self, engine):
        """Test pause_job returns False for non-running job."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        result = await engine.pause_job(job_id)

        assert result is False

    @pytest.mark.asyncio
    async def test_resume_job(self, engine):
        """Test resuming a paused job."""
        await engine.start()
        job_id = await engine.submit_job("workflow", {"data": "test"})

        # Set status to paused
        async with engine._lock:
            engine._jobs[job_id].metadata.status = JobStatus.PAUSED

        result = await engine.resume_job(job_id)

        assert result is True
        await engine.stop()

    @pytest.mark.asyncio
    async def test_resume_job_not_paused(self, engine):
        """Test resume_job returns False for non-paused job."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        result = await engine.resume_job(job_id)

        assert result is False

    @pytest.mark.asyncio
    async def test_cancel_job_pending(self, engine):
        """Test cancelling a pending job."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        result = await engine.cancel_job(job_id)

        assert result is True
        async with engine._lock:
            assert engine._jobs[job_id].metadata.status == JobStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_cancel_job_running(self, engine):
        """Test cancelling a running job."""
        await engine.start()
        job_id = await engine.submit_job("workflow", {"data": "test"})

        # Set status to running
        async with engine._lock:
            engine._jobs[job_id].metadata.status = JobStatus.RUNNING
            engine._cancel_events[job_id] = asyncio.Event()

        result = await engine.cancel_job(job_id)

        assert result is True
        await engine.stop()

    @pytest.mark.asyncio
    async def test_cancel_completed_job(self, engine):
        """Test cancel_job returns False for completed job."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        async with engine._lock:
            engine._jobs[job_id].metadata.status = JobStatus.COMPLETED

        result = await engine.cancel_job(job_id)

        assert result is False

    @pytest.mark.asyncio
    async def test_delete_job(self, engine):
        """Test deleting a job."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        result = await engine.delete_job(job_id)

        assert result is True
        async with engine._lock:
            assert job_id not in engine._jobs

    @pytest.mark.asyncio
    async def test_list_jobs(self, engine):
        """Test listing jobs."""
        await engine.submit_job("workflow1", {"data": "test1"})
        await engine.submit_job("workflow2", {"data": "test2"})

        jobs = engine.list_jobs()

        assert len(jobs) >= 2

    @pytest.mark.asyncio
    async def test_list_jobs_by_status(self, engine):
        """Test listing jobs filtered by status."""
        job_id = await engine.submit_job("workflow", {"data": "test"})

        jobs = engine.list_jobs(status=JobStatus.PENDING)

        assert len(jobs) >= 1

    @pytest.mark.asyncio
    async def test_get_engine_stats(self, engine):
        """Test getting engine statistics."""
        await engine.start()
        await engine.submit_job("workflow", {"data": "test"})

        stats = await engine.get_engine_stats()

        assert "running" in stats
        assert "max_concurrent_jobs" in stats
        assert "worker_tasks" in stats
        assert "jobs_in_memory" in stats
        assert stats["running"] is True
        assert stats["max_concurrent_jobs"] == 2

        await engine.stop()

    @pytest.mark.asyncio
    async def test_prepare_agent_inputs(self, engine):
        """Test _prepare_agent_inputs method."""
        metadata = JobMetadata(
            job_id="test-job",
            workflow_id="test-workflow",
            status=JobStatus.PENDING,
            created_at=datetime.now()
        )
        job_state = JobState(
            metadata=metadata,
            inputs={"topic": "AI"},
            outputs={"previous_result": "data"}
        )
        step = ExecutionStep(agent_id="agent1", dependencies=[], metadata={})

        inputs = engine._prepare_agent_inputs(job_state, step)

        assert inputs["topic"] == "AI"
        assert inputs["previous_result"] == "data"
        assert inputs["_job_id"] == "test-job"
        assert inputs["_workflow_id"] == "test-workflow"
        assert inputs["_agent_id"] == "agent1"


# ============================================================================
# Test Singleton Accessor
# ============================================================================

class TestGetEnhancedEngine:
    """Test get_enhanced_engine singleton accessor."""

    def test_get_enhanced_engine_first_call_requires_params(self):
        """Test first call requires workflow_compiler and checkpoint_manager."""
        # Reset singleton
        import src.orchestration.job_execution_engine_enhanced as module
        module._engine_instance = None

        with pytest.raises(ValueError, match="workflow_compiler and checkpoint_manager required"):
            get_enhanced_engine()

    def test_get_enhanced_engine_creates_singleton(self):
        """Test get_enhanced_engine creates singleton instance."""
        import src.orchestration.job_execution_engine_enhanced as module
        module._engine_instance = None

        compiler = Mock()
        compiler.workflows = {}
        checkpoint = Mock()

        with patch.object(JobExecutionEngineEnhanced, 'load_persisted_jobs'):
            engine1 = get_enhanced_engine(compiler, checkpoint, verbose=False)
            engine2 = get_enhanced_engine()

            assert engine1 is engine2

        # Cleanup
        module._engine_instance = None

    def test_get_enhanced_engine_loads_persisted_jobs(self):
        """Test get_enhanced_engine calls load_persisted_jobs on first init."""
        import src.orchestration.job_execution_engine_enhanced as module
        module._engine_instance = None

        compiler = Mock()
        compiler.workflows = {}
        checkpoint = Mock()

        with patch.object(JobExecutionEngineEnhanced, 'load_persisted_jobs') as mock_load:
            get_enhanced_engine(compiler, checkpoint)
            mock_load.assert_called_once()

        # Cleanup
        module._engine_instance = None
