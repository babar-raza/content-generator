"""Enhanced Agent Registry with auto-discovery and dependency management."""

import logging
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Type, Set
from datetime import datetime

from src.core import Agent, EventBus, Config
from .agent_scanner import AgentScanner, AgentMetadata
from .dependency_resolver import DependencyResolver

logger = logging.getLogger(__name__)

# Global registry instance
_registry_instance: Optional['EnhancedAgentRegistry'] = None
_registry_lock = threading.RLock()


class EnhancedAgentRegistry:
    """Enhanced registry with auto-discovery, dependency management, and caching."""
    
    def __init__(self, agents_dir: Optional[Path] = None, config_dir: Optional[Path] = None):
        """Initialize the enhanced agent registry.
        
        Args:
            agents_dir: Directory containing agent modules (default: src/agents)
            config_dir: Directory for configuration files (default: ./config)
        """
        self.agents_dir = agents_dir or Path("src/agents")
        self.config_dir = config_dir or Path("./config")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Core components
        self.scanner = AgentScanner(self.agents_dir)
        self.dependency_resolver = DependencyResolver()
        
        # Registry state
        self._agent_classes: Dict[str, Type[Agent]] = {}
        self._agent_instances: Dict[str, Agent] = {}
        self._agent_metadata: Dict[str, AgentMetadata] = {}
        self._agents_by_category: Dict[str, List[str]] = {}
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Auto-discover agents on initialization
        self.discover_agents()
    
    def discover_agents(self, force_rescan: bool = False) -> int:
        """Discover all agents in the agents directory.
        
        Args:
            force_rescan: Force rescan even if cache is valid
            
        Returns:
            Number of agents discovered
        """
        with self._lock:
            logger.info("Discovering agents...")
            
            # Discover agents using scanner
            agent_classes = self.scanner.discover(force_rescan=force_rescan)
            
            # Update registry
            self._agent_classes.clear()
            self._agent_metadata.clear()
            self._agents_by_category.clear()
            self.dependency_resolver.clear()
            
            metadata_map = self.scanner.get_all_metadata()
            
            for class_name, agent_class in zip(metadata_map.keys(), agent_classes):
                metadata = metadata_map[class_name]
                
                self._agent_classes[class_name] = agent_class
                self._agent_metadata[class_name] = metadata
                
                # Group by category
                category = metadata.category
                if category not in self._agents_by_category:
                    self._agents_by_category[category] = []
                self._agents_by_category[category].append(class_name)
                
                # Add to dependency resolver
                self.dependency_resolver.add_agent(class_name, metadata.dependencies)
            
            logger.info(f"Discovered {len(self._agent_classes)} agents across {len(self._agents_by_category)} categories")
            
            return len(self._agent_classes)
    
    def register_agent(self, agent_class: Type[Agent]) -> None:
        """Manually register an agent class.
        
        Args:
            agent_class: Agent class to register
        """
        with self._lock:
            class_name = agent_class.__name__
            self._agent_classes[class_name] = agent_class
            logger.info(f"Manually registered agent: {class_name}")
    
    def get_agent(
        self, 
        name: str, 
        config: Optional[Config] = None,
        event_bus: Optional[EventBus] = None,
        **kwargs
    ) -> Optional[Agent]:
        """Get or create an agent instance.
        
        Args:
            name: Agent class name
            config: Configuration object (required for first instantiation)
            event_bus: EventBus object (required for first instantiation)
            **kwargs: Additional arguments to pass to agent constructor
            
        Returns:
            Agent instance if found, None otherwise
        """
        with self._lock:
            # Return cached instance if available
            if name in self._agent_instances:
                return self._agent_instances[name]
            
            # Create new instance
            agent_class = self._agent_classes.get(name)
            if not agent_class:
                logger.warning(f"Agent {name} not found in registry")
                return None
            
            if config is None or event_bus is None:
                logger.error(f"Cannot instantiate {name} without config and event_bus")
                return None
            
            try:
                # Get metadata to determine required services
                metadata = self._agent_metadata.get(name)
                init_args = [config, event_bus]
                
                # Add service dependencies if needed
                if metadata and metadata.dependencies:
                    # For now, we'll add None placeholders for services
                    # In production, these would be actual service instances
                    for dep in metadata.dependencies:
                        init_args.append(kwargs.get(dep))
                
                # Instantiate agent
                agent = agent_class(*init_args)
                self._agent_instances[name] = agent
                
                logger.info(f"Instantiated agent: {name}")
                return agent
                
            except Exception as e:
                logger.error(f"Failed to instantiate agent {name}: {e}")
                return None
    
    def get_dependencies(self, agent_name: str) -> List[str]:
        """Get the dependencies for a specific agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            List of agent names that this agent depends on
        """
        with self._lock:
            metadata = self._agent_metadata.get(agent_name)
            if metadata:
                return metadata.dependencies.copy()
            return []
    
    def agents_by_category(self, category: str) -> List[Agent]:
        """Get all agents in a specific category.
        
        Args:
            category: Category name (e.g., 'content', 'research', 'seo')
            
        Returns:
            List of agent metadata for agents in the category
        """
        with self._lock:
            agent_names = self._agents_by_category.get(category, [])
            # Return metadata instead of instances since the signature asks for List[Agent]
            # but actually we should return the agent instances or names
            return [self._agent_metadata[name] for name in agent_names if name in self._agent_metadata]
    
    def get_all_agents(self) -> Dict[str, Type[Agent]]:
        """Get all registered agent classes.
        
        Returns:
            Dictionary mapping agent names to agent classes
        """
        with self._lock:
            return self._agent_classes.copy()
    
    def get_agent_metadata(self, agent_name: str) -> Optional[AgentMetadata]:
        """Get metadata for a specific agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            AgentMetadata if found, None otherwise
        """
        with self._lock:
            return self._agent_metadata.get(agent_name)
    
    def get_all_categories(self) -> List[str]:
        """Get all agent categories.
        
        Returns:
            List of category names
        """
        with self._lock:
            return list(self._agents_by_category.keys())
    
    def resolve_execution_order(self, agent_names: List[str]) -> List[str]:
        """Resolve the execution order for a list of agents.
        
        Args:
            agent_names: List of agent names to order
            
        Returns:
            List of agent names in execution order (dependencies first)
        """
        with self._lock:
            return self.dependency_resolver.resolve_order(agent_names)
    
    def validate_dependencies(self) -> Dict[str, List[str]]:
        """Validate that all agent dependencies are satisfied.
        
        Returns:
            Dictionary mapping agent names to lists of missing dependencies
        """
        with self._lock:
            available_agents = set(self._agent_classes.keys())
            return self.dependency_resolver.validate_dependencies(available_agents)
    
    def detect_cycles(self) -> Optional[List[str]]:
        """Detect circular dependencies.
        
        Returns:
            List of agent names forming a cycle, or None if no cycle exists
        """
        with self._lock:
            return self.dependency_resolver.detect_cycles()
    
    def get_registry_stats(self) -> Dict[str, Any]:
        """Get registry statistics.
        
        Returns:
            Dictionary with registry stats
        """
        with self._lock:
            return {
                "total_agents": len(self._agent_classes),
                "categories": len(self._agents_by_category),
                "instantiated_agents": len(self._agent_instances),
                "agents_by_category": {
                    cat: len(agents) for cat, agents in self._agents_by_category.items()
                },
                "discovery_time": datetime.now().isoformat()
            }
    
    def clear_instances(self) -> None:
        """Clear all cached agent instances."""
        with self._lock:
            self._agent_instances.clear()
            logger.info("Cleared all agent instances")
    
    def rescan(self) -> int:
        """Force rescan of agents directory.
        
        Returns:
            Number of agents discovered
        """
        return self.discover_agents(force_rescan=True)


def get_registry(
    agents_dir: Optional[Path] = None,
    config_dir: Optional[Path] = None
) -> EnhancedAgentRegistry:
    """Get the global registry instance (singleton pattern).
    
    Args:
        agents_dir: Directory containing agent modules (default: src/agents)
        config_dir: Directory for configuration files (default: ./config)
        
    Returns:
        Global EnhancedAgentRegistry instance
    """
    global _registry_instance
    
    with _registry_lock:
        if _registry_instance is None:
            _registry_instance = EnhancedAgentRegistry(agents_dir, config_dir)
        return _registry_instance
# DOCGEN:LLM-FIRST@v4