"""Agent Scanner - Auto-discovers agents from src/agents directory."""

import ast
import importlib
import inspect
import logging
from pathlib import Path
from typing import Dict, List, Optional, Set, Type, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class AgentMetadata:
    """Metadata extracted from agent class analysis."""
    name: str
    class_name: str
    module_path: str
    file_path: Path
    category: str
    capabilities: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    publishes: List[str] = field(default_factory=list)
    docstring: Optional[str] = None


class AgentScanner:
    """Discovers and registers agents from src/agents directory."""
    
    def __init__(self, base_path: Optional[Path] = None):
        """Initialize scanner with base path to agents directory.
        
        Args:
            base_path: Path to agents directory (default: src/agents)
        """
        self.base_path = base_path or Path("src/agents")
        self._discovered_agents: Dict[str, AgentMetadata] = {}
        self._agent_classes: Dict[str, Type] = {}
        self._cache_valid = False
        
    def discover(self, force_rescan: bool = False) -> List[Type]:
        """Discover all Agent subclasses in base_path.
        
        Args:
            force_rescan: Force rescan even if cache is valid
            
        Returns:
            List of discovered Agent class types (or None if import failed)
        """
        if self._cache_valid and not force_rescan:
            return [cls for cls in self._agent_classes.values() if cls is not None]
        
        self._discovered_agents.clear()
        self._agent_classes.clear()
        
        if not self.base_path.exists():
            logger.warning(f"Agents directory {self.base_path} does not exist")
            return []
        
        # Scan all subdirectories for agent files
        for agent_file in self.base_path.rglob("*.py"):
            if agent_file.name in ["__init__.py", "base.py", "agents_complete.py"]:
                continue
            
            self._scan_file(agent_file)
        
        self._cache_valid = True
        logger.info(f"Discovered {len(self._agent_classes)} agents")
        
        return [cls for cls in self._agent_classes.values() if cls is not None]
    
    def _scan_file(self, file_path: Path) -> None:
        """Scan a Python file for Agent subclasses using AST.
        
        Args:
            file_path: Path to Python file to scan
        """
        try:
            # Use AST to find Agent subclasses without importing
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            agent_classes = self._find_agent_classes_ast(tree)
            
            if not agent_classes:
                return
            
            module_path = self._file_to_module_path(file_path)
            
            for class_name, class_node in agent_classes:
                # Extract metadata from AST
                metadata = self._extract_metadata_from_ast(
                    class_name, class_node, file_path, module_path, content
                )
                self._discovered_agents[class_name] = metadata
                
                # Try to import the class, but don't fail if we can't
                try:
                    module = importlib.import_module(module_path)
                    if hasattr(module, class_name):
                        agent_class = getattr(module, class_name)
                        self._agent_classes[class_name] = agent_class
                    else:
                        # Store None to indicate we found it but couldn't import
                        self._agent_classes[class_name] = None
                except Exception as e:
                    logger.debug(f"Could not import {module_path}.{class_name}: {e}")
                    # Store None to indicate we found it but couldn't import
                    self._agent_classes[class_name] = None
                
        except Exception as e:
            logger.debug(f"Error scanning {file_path}: {e}")
    
    def _find_agent_classes_ast(self, tree: ast.AST) -> List[tuple]:
        """Find class definitions that inherit from Agent using AST.
        
        Args:
            tree: AST tree of Python file
            
        Returns:
            List of tuples (class_name, class_node) for Agent subclasses
        """
        agent_classes = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if class inherits from Agent
                for base in node.bases:
                    base_name = None
                    if isinstance(base, ast.Name):
                        base_name = base.id
                    elif isinstance(base, ast.Attribute):
                        base_name = base.attr
                    
                    if base_name == 'Agent':
                        agent_classes.append((node.name, node))
                        break
        
        return agent_classes
    
    def _file_to_module_path(self, file_path: Path) -> str:
        """Convert file path to Python module path.
        
        Args:
            file_path: Path to Python file
            
        Returns:
            Module path string (e.g., 'src.agents.content.outline_creation')
        """
        try:
            # Get relative path from current directory
            rel_path = file_path.relative_to(Path.cwd())
        except ValueError:
            # If not relative to cwd, use absolute
            rel_path = file_path
        
        # Remove .py extension and convert to module path
        module_path = str(rel_path.with_suffix('')).replace('/', '.').replace('\\', '.')
        return module_path
    
    def _extract_metadata_from_ast(
        self,
        class_name: str,
        class_node: ast.ClassDef,
        file_path: Path,
        module_path: str,
        source_code: str
    ) -> AgentMetadata:
        """Extract metadata from AST class node.
        
        Args:
            class_name: Name of the class
            class_node: AST class definition node
            file_path: Path to file containing class
            module_path: Module path string
            source_code: Full source code of the file
            
        Returns:
            AgentMetadata object with extracted information
        """
        # Get category from directory structure
        category = self._extract_category(file_path)
        
        # Extract capabilities and other info from _create_contract method
        capabilities = []
        publishes = []
        
        for item in class_node.body:
            if isinstance(item, ast.FunctionDef) and item.name == '_create_contract':
                capabilities, publishes = self._parse_contract_from_ast(item)
                break
        
        # Extract dependencies from __init__ signature
        dependencies = []
        for item in class_node.body:
            if isinstance(item, ast.FunctionDef) and item.name == '__init__':
                dependencies = self._extract_dependencies_from_ast(item)
                break
        
        # Get docstring
        docstring = ast.get_docstring(class_node)
        
        return AgentMetadata(
            name=class_name,
            class_name=class_name,
            module_path=module_path,
            file_path=file_path,
            category=category,
            capabilities=capabilities,
            dependencies=dependencies,
            input_schema={},
            output_schema={},
            publishes=publishes,
            docstring=docstring
        )
    
    def _extract_category(self, file_path: Path) -> str:
        """Extract agent category from file path.
        
        Args:
            file_path: Path to agent file
            
        Returns:
            Category name (e.g., 'content', 'research', 'seo')
        """
        # Get parent directory name as category
        try:
            rel_path = file_path.relative_to(self.base_path)
            if len(rel_path.parts) > 1:
                return rel_path.parts[0]
        except ValueError:
            pass
        
        return "unknown"
    
    def _parse_contract_from_ast(self, method_node: ast.FunctionDef) -> tuple:
        """Parse contract details from _create_contract method AST.
        
        Args:
            method_node: AST node for _create_contract method
            
        Returns:
            Tuple of (capabilities, publishes)
        """
        capabilities = []
        publishes = []
        
        for node in ast.walk(method_node):
            if isinstance(node, ast.Call):
                # Look for AgentContract calls
                func_name = None
                if isinstance(node.func, ast.Name):
                    func_name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    func_name = node.func.attr
                
                if func_name == 'AgentContract':
                    for keyword in node.keywords:
                        if keyword.arg == 'capabilities':
                            capabilities = self._extract_list_from_ast(keyword.value)
                        elif keyword.arg == 'publishes':
                            publishes = self._extract_list_from_ast(keyword.value)
        
        return capabilities, publishes
    
    def _extract_list_from_ast(self, node: ast.AST) -> List[str]:
        """Extract list of strings from AST node.
        
        Args:
            node: AST node representing a list
            
        Returns:
            List of strings
        """
        result = []
        
        if isinstance(node, ast.List):
            for elt in node.elts:
                if isinstance(elt, ast.Constant):
                    result.append(str(elt.value))
                elif isinstance(elt, ast.Str):  # Python < 3.8
                    result.append(elt.s)
        
        return result
    
    def _extract_dependencies_from_ast(self, init_node: ast.FunctionDef) -> List[str]:
        """Extract service dependencies from __init__ AST node.
        
        Args:
            init_node: AST node for __init__ method
            
        Returns:
            List of dependency names
        """
        dependencies = []
        
        for arg in init_node.args.args[1:]:  # Skip 'self'
            param_name = arg.arg
            
            if param_name in ['agent_id', 'config', 'event_bus', 
                             'enable_mesh', 'tone_config', 'perf_config', 
                             'agent_config']:
                continue
            
            # Service parameters
            if 'service' in param_name.lower():
                dependencies.append(param_name)
            elif param_name in ['llm', 'database', 'embedding', 'gist', 
                               'trends', 'link_checker']:
                dependencies.append(param_name)
        
        return dependencies
    
    def get_metadata(self, agent_name: str) -> Optional[AgentMetadata]:
        """Get metadata for a specific agent.
        
        Args:
            agent_name: Name of agent class
            
        Returns:
            AgentMetadata if found, None otherwise
        """
        return self._discovered_agents.get(agent_name)
    
    def get_all_metadata(self) -> Dict[str, AgentMetadata]:
        """Get metadata for all discovered agents.
        
        Returns:
            Dictionary mapping agent names to metadata
        """
        return self._discovered_agents.copy()
    
    def get_agents_by_category(self, category: str) -> List[AgentMetadata]:
        """Get all agents in a specific category.
        
        Args:
            category: Category name (e.g., 'content', 'research')
            
        Returns:
            List of agent metadata for agents in category
        """
        return [
            metadata for metadata in self._discovered_agents.values()
            if metadata.category == category
        ]
    
    def invalidate_cache(self) -> None:
        """Invalidate the agent discovery cache."""
        self._cache_valid = False
    
    def trigger_reload(self) -> List[Type]:
        """Trigger a full agent reload.
        
        This method is called by hot reload monitor when agent configurations change.
        
        Returns:
            List of discovered Agent class types
        """
        logger.info("Triggering agent reload due to configuration change")
        return self.discover(force_rescan=True)
