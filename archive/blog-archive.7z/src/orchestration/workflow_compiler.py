"""Workflow Compiler - Parses YAML workflow definitions and builds execution plans."""

import yaml
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Set
from collections import defaultdict, deque

from .execution_plan import ExecutionPlan, ExecutionStep
from .dependency_resolver import DependencyResolver

logger = logging.getLogger(__name__)


class CompilationError(Exception):
    """Raised when workflow compilation fails."""
    pass


class WorkflowCompiler:
    """Compiles workflow definitions into executable plans."""
    
    def __init__(
        self, 
        registry: Optional[Any] = None,
        workflows_path: Optional[Path] = None
    ):
        """Initialize workflow compiler.
        
        Args:
            registry: EnhancedAgentRegistry instance for validation
            workflows_path: Path to workflows.yaml (default: templates/workflows.yaml)
        """
        self.registry = registry
        self.workflows_path = workflows_path or Path("templates/workflows.yaml")
        self.workflows: Dict[str, Any] = {}
        self.dependencies: Dict[str, List[str]] = {}
        self.conditions: Dict[str, Dict[str, Any]] = {}
        
        # Load workflows
        self._load_workflows()
    
    def _load_workflows(self) -> None:
        """Load workflow definitions from YAML."""
        if not self.workflows_path.exists():
            logger.warning(f"Workflows file not found: {self.workflows_path}")
            return
        
        try:
            with open(self.workflows_path, 'r') as f:
                data = yaml.safe_load(f)
            
            if not data:
                logger.warning("Empty workflows file")
                return
            
            # Extract dependencies
            self.dependencies = data.get('dependencies', {})
            
            # Extract workflow profiles
            self.workflows = data.get('profiles', {})
            
            # Extract conditions
            self.conditions = data.get('conditions', {})
            
            logger.info(f"Loaded {len(self.workflows)} workflow profiles")
            
        except Exception as e:
            logger.error(f"Failed to load workflows: {e}")
            raise CompilationError(f"Failed to load workflows: {e}")
    
    def compile(self, workflow_id: str) -> ExecutionPlan:
        """Compile a workflow into an execution plan.
        
        Args:
            workflow_id: Workflow profile ID (e.g., 'fast-draft', 'full')
            
        Returns:
            ExecutionPlan with steps in topological order
            
        Raises:
            CompilationError: If compilation fails
        """
        if workflow_id not in self.workflows:
            raise CompilationError(f"Workflow '{workflow_id}' not found")
        
        workflow_def = self.workflows[workflow_id]
        
        # Get step order from workflow
        step_order = workflow_def.get('order', [])
        skip_steps = set(workflow_def.get('skip', []))
        
        # Filter out skipped steps
        active_steps = [step for step in step_order if step not in skip_steps]
        
        # Build execution steps with dependencies
        steps = []
        for agent_id in active_steps:
            # Get dependencies for this agent
            deps = self.dependencies.get(agent_id, [])
            
            # Filter dependencies to only include active steps
            active_deps = [dep for dep in deps if dep in active_steps]
            
            # Get condition if defined
            condition = self.conditions.get(agent_id)
            
            # Create execution step
            step = ExecutionStep(
                agent_id=agent_id,
                dependencies=active_deps,
                condition=condition,
                timeout=workflow_def.get('resources', {}).get('max_runtime_s', 300),
                retry=workflow_def.get('max_retries', 3),
                metadata={
                    'workflow_id': workflow_id,
                    'llm_settings': workflow_def.get('llm', {}),
                    'deterministic': workflow_def.get('deterministic', False)
                }
            )
            steps.append(step)
        
        # Validate and topologically sort steps
        sorted_steps = self._topological_sort(steps)
        
        # Identify parallel groups
        parallel_groups = self._identify_parallel_groups(sorted_steps)
        
        # Validate workflow structure
        self._validate_workflow(sorted_steps, workflow_id)
        
        # Create execution plan
        plan = ExecutionPlan(
            workflow_id=workflow_id,
            steps=sorted_steps,
            parallel_groups=parallel_groups,
            metadata={
                'deterministic': workflow_def.get('deterministic', False),
                'warnings_as_errors': workflow_def.get('warnings_as_errors', False),
                'llm_settings': workflow_def.get('llm', {}),
                'disabled_agents': workflow_def.get('disabled_agents', [])
            }
        )
        
        logger.info(
            f"Compiled workflow '{workflow_id}': {len(sorted_steps)} steps, "
            f"{len(parallel_groups)} parallel groups"
        )
        
        return plan
    
    def _topological_sort(self, steps: List[ExecutionStep]) -> List[ExecutionStep]:
        """Sort steps in topological order.
        
        Args:
            steps: List of execution steps
            
        Returns:
            Steps sorted in execution order
            
        Raises:
            CompilationError: If circular dependency detected
        """
        # Build adjacency list and in-degree map
        graph = defaultdict(list)
        in_degree = defaultdict(int)
        step_map = {step.agent_id: step for step in steps}
        
        # Initialize all steps with 0 in-degree
        for step in steps:
            in_degree[step.agent_id] = 0
        
        # Build graph
        for step in steps:
            for dep in step.dependencies:
                if dep in step_map:
                    graph[dep].append(step.agent_id)
                    in_degree[step.agent_id] += 1
        
        # Kahn's algorithm for topological sort
        queue = deque([
            step.agent_id for step in steps 
            if in_degree[step.agent_id] == 0
        ])
        
        sorted_ids = []
        
        while queue:
            # Use sorted to ensure deterministic ordering
            current = queue.popleft()
            sorted_ids.append(current)
            
            # Reduce in-degree for neighbors
            for neighbor in sorted(graph[current]):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        
        # Check for cycles
        if len(sorted_ids) != len(steps):
            remaining = set(step.agent_id for step in steps) - set(sorted_ids)
            raise CompilationError(
                f"Circular dependency detected involving: {remaining}"
            )
        
        # Return steps in sorted order
        return [step_map[agent_id] for agent_id in sorted_ids]
    
    def _identify_parallel_groups(
        self, 
        steps: List[ExecutionStep]
    ) -> List[List[str]]:
        """Identify groups of steps that can run in parallel.
        
        Args:
            steps: Topologically sorted steps
            
        Returns:
            List of parallel groups (each group is a list of agent IDs)
        """
        parallel_groups = []
        processed = set()
        
        while len(processed) < len(steps):
            # Find steps with all dependencies satisfied
            current_group = []
            
            for step in steps:
                if step.agent_id in processed:
                    continue
                
                # Check if all dependencies are processed
                if all(dep in processed for dep in step.dependencies):
                    current_group.append(step.agent_id)
            
            if not current_group:
                # Should not happen if topological sort succeeded
                break
            
            # Mark steps as processed
            processed.update(current_group)
            
            # Add to parallel groups
            if len(current_group) > 0:
                parallel_groups.append(current_group)
        
        return parallel_groups
    
    def _validate_workflow(
        self, 
        steps: List[ExecutionStep], 
        workflow_id: str
    ) -> None:
        """Validate workflow structure.
        
        Args:
            steps: Execution steps to validate
            workflow_id: Workflow identifier
            
        Raises:
            CompilationError: If validation fails
        """
        errors = []
        
        # Check for empty workflow
        if not steps:
            errors.append(f"Workflow '{workflow_id}' has no steps")
        
        # Check for duplicate agent IDs
        agent_ids = [step.agent_id for step in steps]
        if len(agent_ids) != len(set(agent_ids)):
            duplicates = [
                aid for aid in agent_ids 
                if agent_ids.count(aid) > 1
            ]
            errors.append(f"Duplicate agent IDs: {set(duplicates)}")
        
        # Check dependencies exist
        valid_ids = set(agent_ids)
        for step in steps:
            for dep in step.dependencies:
                if dep not in valid_ids:
                    errors.append(
                        f"Agent '{step.agent_id}' depends on non-existent '{dep}'"
                    )
        
        # Validate against registry if available
        if self.registry:
            try:
                all_agents = self.registry.get_all_agents()
                registry_ids = set(all_agents.keys())
                
                for step in steps:
                    # Check if agent exists in registry
                    # Note: workflow uses capability names, not class names
                    # So we skip this check for now
                    pass
            except Exception as e:
                logger.warning(f"Could not validate against registry: {e}")
        
        if errors:
            raise CompilationError(
                f"Workflow '{workflow_id}' validation failed:\n" + 
                "\n".join(f"  - {err}" for err in errors)
            )
    
    def list_workflows(self) -> List[str]:
        """List available workflow IDs.
        
        Returns:
            List of workflow profile IDs
        """
        return list(self.workflows.keys())
    
    def get_workflow_metadata(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a workflow.
        
        Args:
            workflow_id: Workflow identifier
            
        Returns:
            Workflow metadata dictionary, or None if not found
        """
        if workflow_id not in self.workflows:
            return None
        
        workflow_def = self.workflows[workflow_id]
        
        return {
            'workflow_id': workflow_id,
            'deterministic': workflow_def.get('deterministic', False),
            'warnings_as_errors': workflow_def.get('warnings_as_errors', False),
            'max_retries': workflow_def.get('max_retries', 3),
            'llm_settings': workflow_def.get('llm', {}),
            'total_steps': len(workflow_def.get('order', [])),
            'skipped_steps': len(workflow_def.get('skip', [])),
            'disabled_agents': workflow_def.get('disabled_agents', [])
        }
    
    def compile_with_conditions(
        self, 
        workflow_id: str,
        conditions: Dict[str, Dict[str, Any]]
    ) -> ExecutionPlan:
        """Compile workflow with conditional steps.
        
        Args:
            workflow_id: Workflow profile ID
            conditions: Map of agent_id to condition definitions
            
        Returns:
            ExecutionPlan with conditional steps
        """
        # Start with basic compilation
        plan = self.compile(workflow_id)
        
        # Add conditions to steps
        for step in plan.steps:
            if step.agent_id in conditions:
                step.condition = conditions[step.agent_id]
        
        return plan
# DOCGEN:LLM-FIRST@v4