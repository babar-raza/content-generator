# checkpoint_manager.py
"""Checkpoint management for workflow state persistence and resumption.

Provides save/restore capabilities for workflow state at any point in execution.
"""

import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class CheckpointMetadata:
    """Metadata for a checkpoint."""
    checkpoint_id: str
    job_id: str
    step_name: str
    timestamp: str
    file_path: str
    workflow_version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class CheckpointManager:
    """Manages checkpoint creation, restoration, and lifecycle."""
    
    def __init__(self, storage_path: Path = Path(".checkpoints")):
        """Initialize checkpoint manager.
        
        Args:
            storage_path: Root directory for checkpoint storage
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.workflow_version = "1.0"
        logger.info(f"CheckpointManager initialized with storage: {self.storage_path}")
    
    def save(self, job_id: str, step: str, state: Dict[str, Any]) -> str:
        """Save workflow state as a checkpoint.
        
        Args:
            job_id: Unique job identifier
            step: Current step name
            state: Complete workflow state including inputs, outputs, context
            
        Returns:
            checkpoint_id: Unique identifier for the checkpoint
        """
        # Create job checkpoint directory
        job_dir = self.storage_path / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate checkpoint ID and filename
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        checkpoint_id = f"{step}_{timestamp}"
        checkpoint_file = job_dir / f"{checkpoint_id}.json"
        
        # Prepare checkpoint data
        checkpoint_data = {
            "checkpoint_id": checkpoint_id,
            "job_id": job_id,
            "step_name": step,
            "timestamp": datetime.utcnow().isoformat(),
            "workflow_version": self.workflow_version,
            "state": state
        }
        
        try:
            # Write checkpoint to file
            with open(checkpoint_file, 'w', encoding='utf-8') as f:
                json.dump(checkpoint_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Checkpoint saved: {checkpoint_id} for job {job_id}")
            return checkpoint_id
            
        except Exception as e:
            logger.error(f"Failed to save checkpoint {checkpoint_id}: {e}")
            raise
    
    def restore(self, job_id: str, checkpoint_id: str) -> Dict[str, Any]:
        """Restore workflow state from a checkpoint.
        
        Args:
            job_id: Job identifier
            checkpoint_id: Checkpoint identifier to restore
            
        Returns:
            Complete workflow state dictionary
            
        Raises:
            FileNotFoundError: If checkpoint doesn't exist
            ValueError: If checkpoint is corrupted or incompatible
        """
        checkpoint_file = self.storage_path / job_id / f"{checkpoint_id}.json"
        
        if not checkpoint_file.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_id}")
        
        try:
            with open(checkpoint_file, 'r', encoding='utf-8') as f:
                checkpoint_data = json.load(f)
            
            # Validate checkpoint compatibility
            saved_version = checkpoint_data.get("workflow_version", "1.0")
            if saved_version != self.workflow_version:
                logger.warning(
                    f"Checkpoint version mismatch: {saved_version} != {self.workflow_version}"
                )
            
            # Validate required fields
            if "state" not in checkpoint_data:
                raise ValueError("Checkpoint data is corrupted: missing 'state' field")
            
            logger.info(f"Checkpoint restored: {checkpoint_id} for job {job_id}")
            return checkpoint_data["state"]
            
        except json.JSONDecodeError as e:
            logger.error(f"Corrupted checkpoint {checkpoint_id}: {e}")
            raise ValueError(f"Checkpoint {checkpoint_id} is corrupted")
        except Exception as e:
            logger.error(f"Failed to restore checkpoint {checkpoint_id}: {e}")
            raise
    
    def list(self, job_id: str) -> List[CheckpointMetadata]:
        """List all checkpoints for a job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            List of checkpoint metadata, sorted by timestamp (newest first)
        """
        job_dir = self.storage_path / job_id
        
        if not job_dir.exists():
            return []
        
        checkpoints = []
        
        for checkpoint_file in sorted(job_dir.glob("*.json"), reverse=True):
            try:
                with open(checkpoint_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                metadata = CheckpointMetadata(
                    checkpoint_id=data.get("checkpoint_id", checkpoint_file.stem),
                    job_id=data.get("job_id", job_id),
                    step_name=data.get("step_name", "unknown"),
                    timestamp=data.get("timestamp", ""),
                    file_path=str(checkpoint_file),
                    workflow_version=data.get("workflow_version", "1.0")
                )
                checkpoints.append(metadata)
                
            except Exception as e:
                logger.warning(f"Failed to read checkpoint {checkpoint_file}: {e}")
                continue
        
        return checkpoints
    
    def delete(self, job_id: str, checkpoint_id: str) -> None:
        """Delete a specific checkpoint.
        
        Args:
            job_id: Job identifier
            checkpoint_id: Checkpoint identifier to delete
        """
        checkpoint_file = self.storage_path / job_id / f"{checkpoint_id}.json"
        
        if checkpoint_file.exists():
            try:
                checkpoint_file.unlink()
                logger.info(f"Checkpoint deleted: {checkpoint_id}")
            except Exception as e:
                logger.error(f"Failed to delete checkpoint {checkpoint_id}: {e}")
                raise
        else:
            logger.warning(f"Checkpoint not found for deletion: {checkpoint_id}")
    
    def cleanup(self, job_id: str, keep_last: int = 10) -> None:
        """Clean up old checkpoints, keeping only the last N.
        
        Args:
            job_id: Job identifier
            keep_last: Number of recent checkpoints to keep (default: 10)
        """
        checkpoints = self.list(job_id)
        
        if len(checkpoints) <= keep_last:
            return
        
        # Delete oldest checkpoints beyond keep_last
        to_delete = checkpoints[keep_last:]
        deleted_count = 0
        
        for checkpoint in to_delete:
            try:
                self.delete(job_id, checkpoint.checkpoint_id)
                deleted_count += 1
            except Exception as e:
                logger.error(f"Failed to cleanup checkpoint {checkpoint.checkpoint_id}: {e}")
        
        logger.info(f"Cleaned up {deleted_count} old checkpoints for job {job_id}")
    
    def cleanup_job(self, job_id: str) -> None:
        """Delete all checkpoints for a completed job.
        
        Args:
            job_id: Job identifier
        """
        job_dir = self.storage_path / job_id
        
        if job_dir.exists():
            try:
                import shutil
                shutil.rmtree(job_dir)
                logger.info(f"All checkpoints deleted for job {job_id}")
            except Exception as e:
                logger.error(f"Failed to cleanup job {job_id}: {e}")
                raise
    
    def get_latest_checkpoint(self, job_id: str) -> Optional[str]:
        """Get the ID of the most recent checkpoint for a job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            checkpoint_id of the latest checkpoint, or None if no checkpoints exist
        """
        checkpoints = self.list(job_id)
        return checkpoints[0].checkpoint_id if checkpoints else None
# DOCGEN:LLM-FIRST@v4