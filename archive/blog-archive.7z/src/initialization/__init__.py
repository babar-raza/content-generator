"""At a glance
- Purpose: Provides entry point for system initialization, exposing integrated initialization functions.
- Key inputs: None (static exports).
- Key outputs: initialize_integrated_system function and SystemInitializer class.
- External deps: integrated_init module.
- Collaborators: Imported by main application entry points for system startup.
- Lifecycle: Imported during application bootstrap.

Deeper dive
- Core concepts: Clean API surface for initialization; delegates to integrated_init for complex setup.
- Important invariants: All exported symbols must be available and functional.
- Error surface: Import errors if integrated_init module is missing or broken.
- Performance notes: Lightweight imports with no initialization overhead.
- Security notes: No security implications (pure exports).
"""

from .integrated_init import initialize_integrated_system, SystemInitializer

__all__ = ['initialize_integrated_system', 'SystemInitializer']
# DOCGEN:LLM-FIRST@v4