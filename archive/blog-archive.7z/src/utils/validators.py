"""Input validation utilities.

This module provides validation functions for configurations, inputs, and URLs.
Uses only Python standard library.
"""

import re
from typing import Any, Dict, List, Optional, Type, Union
from urllib.parse import urlparse


def validate_config(
    config: Dict[str, Any],
    required_fields: List[str],
    schema: Optional[Dict[str, Type]] = None,
    strict: bool = False
) -> None:
    """Validate configuration dictionary.
    
    Checks for required fields and optionally validates types against a schema.
    
    Args:
        config: Configuration dictionary to validate
        required_fields: List of required field names
        schema: Optional type schema {field_name: expected_type}
        strict: If True, raise error for fields not in schema (default: False)
        
    Raises:
        ValueError: If validation fails (missing fields, wrong types)
        TypeError: If config is not a dictionary
        
    Example:
        >>> config = {'api_key': 'abc123', 'timeout': 30, 'retries': 3}
        >>> validate_config(
        ...     config,
        ...     required_fields=['api_key', 'timeout'],
        ...     schema={'api_key': str, 'timeout': int, 'retries': int}
        ... )
        # Passes validation
        
        >>> validate_config(config, ['missing_field'])
        Traceback (most recent call last):
            ...
        ValueError: Missing required configuration fields: missing_field
        
        >>> bad_config = {'api_key': 123, 'timeout': '30'}
        >>> validate_config(bad_config, ['api_key'], {'api_key': str})
        Traceback (most recent call last):
            ...
        ValueError: Configuration field 'api_key' has wrong type: expected str, got int
    """
    if not isinstance(config, dict):
        raise TypeError(f"Config must be a dictionary, got {type(config).__name__}")
    
    # Check required fields
    missing = [field for field in required_fields if field not in config]
    if missing:
        raise ValueError(f"Missing required configuration fields: {', '.join(missing)}")
    
    # Validate types if schema provided
    if schema:
        for field, expected_type in schema.items():
            if field in config:
                value = config[field]
                if value is not None and not isinstance(value, expected_type):
                    raise ValueError(
                        f"Configuration field '{field}' has wrong type: "
                        f"expected {expected_type.__name__}, got {type(value).__name__}"
                    )
        
        # Check for unexpected fields if strict mode
        if strict:
            unexpected = [field for field in config if field not in schema]
            if unexpected:
                raise ValueError(
                    f"Unexpected configuration fields: {', '.join(unexpected)}"
                )


def validate_input(
    value: Any,
    param_name: str = "value",
    expected_type: Optional[Type] = None,
    min_value: Optional[Union[int, float]] = None,
    max_value: Optional[Union[int, float]] = None,
    min_length: Optional[int] = None,
    max_length: Optional[int] = None,
    allowed_values: Optional[List[Any]] = None,
    pattern: Optional[str] = None,
    not_none: bool = False,
    not_empty: bool = False
) -> None:
    """Validate input against multiple constraints.
    
    Comprehensive validation function that checks type, range, length,
    allowed values, and regex patterns.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        expected_type: Expected type (e.g., str, int, float)
        min_value: Minimum value for numbers
        max_value: Maximum value for numbers
        min_length: Minimum length for strings/collections
        max_length: Maximum length for strings/collections
        allowed_values: Whitelist of allowed values
        pattern: Regex pattern for string validation
        not_none: Raise error if value is None
        not_empty: Raise error if value is empty (for strings/collections)
        
    Raises:
        TypeError: If type validation fails
        ValueError: If value validation fails
        
    Example:
        >>> validate_input(42, "age", int, min_value=0, max_value=150)
        # Passes
        
        >>> validate_input("test@example.com", "email", str, 
        ...               pattern=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        # Passes
        
        >>> validate_input(5, "count", int, min_value=10)
        Traceback (most recent call last):
            ...
        ValueError: count must be >= 10, got 5
        
        >>> validate_input("", "name", str, not_empty=True)
        Traceback (most recent call last):
            ...
        ValueError: name cannot be empty
    """
    # Check None
    if not_none and value is None:
        raise ValueError(f"{param_name} cannot be None")
    
    # Skip remaining checks if value is None
    if value is None:
        return
    
    # Type validation
    if expected_type is not None:
        if not isinstance(value, expected_type):
            raise TypeError(
                f"{param_name} must be of type {expected_type.__name__}, "
                f"got {type(value).__name__}"
            )
    
    # Empty check
    if not_empty:
        if isinstance(value, (str, list, tuple, dict, set)) and len(value) == 0:
            raise ValueError(f"{param_name} cannot be empty")
    
    # Numeric range validation
    if min_value is not None or max_value is not None:
        if not isinstance(value, (int, float)):
            raise TypeError(
                f"{param_name} must be numeric for min/max validation, "
                f"got {type(value).__name__}"
            )
        
        if min_value is not None and value < min_value:
            raise ValueError(f"{param_name} must be >= {min_value}, got {value}")
        
        if max_value is not None and value > max_value:
            raise ValueError(f"{param_name} must be <= {max_value}, got {value}")
    
    # Length validation
    if min_length is not None or max_length is not None:
        if not hasattr(value, '__len__'):
            raise TypeError(
                f"{param_name} must have length for min_length/max_length validation"
            )
        
        length = len(value)
        
        if min_length is not None and length < min_length:
            raise ValueError(
                f"{param_name} length must be >= {min_length}, got {length}"
            )
        
        if max_length is not None and length > max_length:
            raise ValueError(
                f"{param_name} length must be <= {max_length}, got {length}"
            )
    
    # Allowed values validation
    if allowed_values is not None:
        if value not in allowed_values:
            raise ValueError(
                f"{param_name} must be one of {allowed_values}, got {value}"
            )
    
    # Pattern validation
    if pattern is not None:
        if not isinstance(value, str):
            raise TypeError(
                f"{param_name} must be a string for pattern validation, "
                f"got {type(value).__name__}"
            )
        
        if not re.match(pattern, value):
            raise ValueError(
                f"{param_name} does not match required pattern: {pattern}"
            )


def validate_url(
    url: str,
    schemes: Optional[List[str]] = None,
    require_netloc: bool = True,
    allow_fragments: bool = True,
    allow_params: bool = True
) -> bool:
    """Validate URL format and components.
    
    Args:
        url: URL string to validate
        schemes: Allowed schemes (default: ['http', 'https'])
        require_netloc: Require network location/domain (default: True)
        allow_fragments: Allow URL fragments (#anchor) (default: True)
        allow_params: Allow URL parameters (?key=value) (default: True)
        
    Returns:
        True if URL is valid, False otherwise
        
    Example:
        >>> validate_url("https://example.com/path")
        True
        
        >>> validate_url("http://example.com:8080/path?query=1")
        True
        
        >>> validate_url("ftp://example.com", schemes=['http', 'https'])
        False
        
        >>> validate_url("not a url")
        False
    """
    if not url or not isinstance(url, str):
        return False
    
    # Default allowed schemes
    if schemes is None:
        schemes = ['http', 'https']
    
    try:
        parsed = urlparse(url)
        
        # Check scheme
        if parsed.scheme.lower() not in [s.lower() for s in schemes]:
            return False
        
        # Check network location if required
        if require_netloc and not parsed.netloc:
            return False
        
        # Check fragments
        if not allow_fragments and parsed.fragment:
            return False
        
        # Check parameters
        if not allow_params and parsed.query:
            return False
        
        return True
        
    except Exception:
        return False


def validate_email(email: str, allow_localhost: bool = False) -> bool:
    """Validate email address format.
    
    Basic email validation using regex. Does not check if email actually exists.
    
    Args:
        email: Email address to validate
        allow_localhost: Allow localhost domain (default: False)
        
    Returns:
        True if email format is valid, False otherwise
        
    Example:
        >>> validate_email("user@example.com")
        True
        
        >>> validate_email("invalid.email")
        False
        
        >>> validate_email("user@localhost", allow_localhost=True)
        True
    """
    if not email or not isinstance(email, str):
        return False
    
    # Basic email pattern
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    if allow_localhost:
        # Allow localhost as domain
        pattern = r'^[a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|localhost)$'
    
    return bool(re.match(pattern, email))


def validate_port(port: Union[int, str], allow_privileged: bool = False) -> bool:
    """Validate port number.
    
    Args:
        port: Port number to validate (int or string)
        allow_privileged: Allow privileged ports 1-1023 (default: False)
        
    Returns:
        True if port is valid, False otherwise
        
    Example:
        >>> validate_port(8080)
        True
        
        >>> validate_port(80, allow_privileged=True)
        True
        
        >>> validate_port(80, allow_privileged=False)
        False
        
        >>> validate_port(99999)
        False
    """
    try:
        port_num = int(port)
        
        # Check range
        if port_num < 1 or port_num > 65535:
            return False
        
        # Check privileged ports
        if not allow_privileged and port_num < 1024:
            return False
        
        return True
        
    except (ValueError, TypeError):
        return False


def validate_ipv4(ip: str) -> bool:
    """Validate IPv4 address format.
    
    Args:
        ip: IPv4 address string to validate
        
    Returns:
        True if valid IPv4, False otherwise
        
    Example:
        >>> validate_ipv4("192.168.1.1")
        True
        
        >>> validate_ipv4("256.1.1.1")
        False
        
        >>> validate_ipv4("192.168.1")
        False
    """
    if not ip or not isinstance(ip, str):
        return False
    
    parts = ip.split('.')
    
    if len(parts) != 4:
        return False
    
    try:
        for part in parts:
            num = int(part)
            if num < 0 or num > 255:
                return False
        return True
    except ValueError:
        return False


def validate_range(
    value: Union[int, float],
    min_val: Union[int, float],
    max_val: Union[int, float],
    inclusive: bool = True
) -> bool:
    """Validate that value is within a range.
    
    Args:
        value: Value to check
        min_val: Minimum value
        max_val: Maximum value
        inclusive: Include boundaries (default: True)
        
    Returns:
        True if value is in range, False otherwise
        
    Example:
        >>> validate_range(5, 1, 10)
        True
        
        >>> validate_range(10, 1, 10, inclusive=True)
        True
        
        >>> validate_range(10, 1, 10, inclusive=False)
        False
    """
    if inclusive:
        return min_val <= value <= max_val
    else:
        return min_val < value < max_val


def validate_dict_structure(
    data: Dict[str, Any],
    required_keys: List[str],
    optional_keys: Optional[List[str]] = None,
    strict: bool = False
) -> bool:
    """Validate dictionary has required structure.
    
    Args:
        data: Dictionary to validate
        required_keys: Keys that must be present
        optional_keys: Keys that may be present (only checked in strict mode)
        strict: If True, reject keys not in required_keys or optional_keys
        
    Returns:
        True if structure is valid, False otherwise
        
    Example:
        >>> data = {'name': 'John', 'age': 30, 'email': 'john@example.com'}
        >>> validate_dict_structure(data, ['name', 'age'], ['email', 'phone'])
        True
        
        >>> validate_dict_structure(data, ['name', 'missing_key'])
        False
    """
    if not isinstance(data, dict):
        return False
    
    # Check required keys
    for key in required_keys:
        if key not in data:
            return False
    
    # Check for unexpected keys in strict mode
    if strict:
        allowed_keys = set(required_keys)
        if optional_keys:
            allowed_keys.update(optional_keys)
        
        for key in data.keys():
            if key not in allowed_keys:
                return False
    
    return True
