"""Utilities module - Helper functions and classes.

This module provides various utility functions:
- Performance tracking with sliding window metrics
- JSON repair for malformed LLM responses
- Safe path operations and slug generation
- Retry decorators with exponential backoff
- Input validation helpers

All utilities use only Python standard library.
"""

# Import from existing modules
from src.utils.json_repair import JSONRepair

# Import from new modules
from src.utils.path_utils import (
    safe_path,
    generate_slug,
    ensure_directory,
    get_safe_filename,
    is_safe_path,
    normalize_path,
)

from src.utils.retry import (
    retry_with_backoff,
    retry_on_condition,
    retry_with_timeout,
    RetryContext,
)

from src.utils.validators import (
    validate_config,
    validate_input,
    validate_url,
    validate_email,
    validate_port,
    validate_ipv4,
    validate_range,
    validate_dict_structure,
)

# Import PerformanceTracker from learning module
# Note: The existing learning.py has dependencies, but PerformanceTracker can still be used
try:
    from src.utils.learning import PerformanceTracker
except ImportError:
    # If dependencies not available, provide a fallback or warning
    import warnings
    warnings.warn("PerformanceTracker could not be imported due to missing dependencies")
    PerformanceTracker = None

# Convenience function for JSON repair
def repair_json(text: str) -> str:
    """Repair malformed JSON string.
    
    Args:
        text: Potentially malformed JSON string
        
    Returns:
        Repaired JSON string
        
    Example:
        >>> repair_json('{"key": "value",}')
        '{"key": "value"}'
    """
    import json
    result = JSONRepair.repair(text)
    return json.dumps(result) if isinstance(result, (dict, list)) else str(result)

__all__ = [
    # Performance tracking
    'PerformanceTracker',
    
    # JSON utilities
    'JSONRepair',
    'repair_json',
    
    # Path utilities
    'safe_path',
    'generate_slug',
    'ensure_directory',
    'get_safe_filename',
    'is_safe_path',
    'normalize_path',
    
    # Retry decorators
    'retry_with_backoff',
    'retry_on_condition',
    'retry_with_timeout',
    'RetryContext',
    
    # Validators
    'validate_config',
    'validate_input',
    'validate_url',
    'validate_email',
    'validate_port',
    'validate_ipv4',
    'validate_range',
    'validate_dict_structure',
]
