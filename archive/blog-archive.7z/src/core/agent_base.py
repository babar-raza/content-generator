"""DOCGEN:LLM-FIRST@v1

Module overview
- Purpose: Provides abstract base classes for agents in the content generator system, supporting both standalone and mesh-enabled operation.
- Lifecycle: Instantiated during system initialization; registers with mesh if enabled; processes events throughout operation.
- Collaborators: Extended by all agent classes in src.agents; used by src.orchestration for job execution; integrates with src.mesh for distributed capabilities.
- Key inputs: Agent configuration, event bus instance, optional mesh/tone/perf configs.
- Key outputs: AgentContract for capability declaration; execution results via AgentEvent; performance statistics.

Public API Catalog
| Symbol | Kind | Defined in | Purpose | Inputs | Outputs | Raises | Notes |
|-------:|:-----|:-----------|:--------|:-------|:--------|:-------|:------|
| Agent | class | agent_base | Abstract base agent class | agent_id: str, config, event_bus: EventBus, enable_mesh: bool, tone_config: Optional[Dict[str, Any]], perf_config: Optional[Dict[str, Any]], agent_config: Optional[Dict[str, Any]] | Agent instance | None | Supports mesh integration |
| SelfCorrectingAgent | class | agent_base | Mixin for self-correcting agents | None | SelfCorrectingAgent instance | None | For error correction |

Deeper dive
- Data flow: Agent instantiated with config → contract created → event subscriptions set up → mesh registration if enabled → events processed via execute method → statistics tracked.
- Invariants & contracts: Abstract methods must be implemented; contract creation is mandatory; thread-safe load tracking.
- Preconditions: None.
- Postconditions: Agent ready for event processing and mesh integration.
- Error surface: Mesh registration failures logged but non-fatal; execution errors tracked in statistics.
- Concurrency & async: Thread-safe load tracking; no async.
- I/O & performance: Load tracking for capacity management; configurable timeouts and limits; execution time monitoring.
- Configuration map: tone_config, perf_config, agent_config for behavior customization.
- External dependencies: logging, abc, contracts.AgentEvent/AgentContract, event_bus.EventBus.
"""

import logging
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod

from .contracts import AgentEvent, AgentContract
from .event_bus import EventBus

logger = logging.getLogger(__name__)


class Agent(ABC):
    """Base agent class with optional mesh capabilities.

    Responsibilities
    - Define agent contract with capabilities and schemas
    - Subscribe to relevant events
    - Execute work based on events
    - Track execution statistics
    - Support optional mesh integration for distributed execution

    Construction
    - Parameters: agent_id (str), config, event_bus (EventBus), enable_mesh (bool), tone_config (Optional[Dict]), perf_config (Optional[Dict]), agent_config (Optional[Dict]).
    - Preconditions in __init__: agent_id must be string; config, event_bus must be valid.
    - Attributes: agent_id (str), config, event_bus (EventBus), enable_mesh (bool), tone_config (dict), perf_config (dict), agent_config (dict), executions (int), failures (int), total_time (float), contract (AgentContract), _capability_registry (optional), _current_load (int), _max_capacity (int).

    Public API
    - _create_contract() -> AgentContract: Abstract method to create agent contract.
    - _subscribe_to_events(): Abstract method to set up event subscriptions.
    - execute(event: AgentEvent) -> Optional[AgentEvent]: Abstract method to process events.
    - get_stats() -> Dict[str, Any]: Get execution statistics.
    - register_with_mesh(capability_registry): Register with mesh if enabled.
    - increment_load(): Increase current load counter.
    - decrement_load(): Decrease current load counter.
    - get_timeout(timeout_type: str) -> float: Get timeout from perf_config.
    - get_limit(limit_type: str) -> int: Get limit from perf_config.
    - get_tone_setting(section: str, setting: str, default: Any) -> Any: Get tone configuration.
    - is_section_enabled(section: str) -> bool: Check if section is enabled in tone config.

    State & invariants
    - Attributes: executions (int), failures (int), total_time (float), _current_load (int), _max_capacity (int).
    - Invariants (validated in code): Abstract methods implemented by subclasses; contract created on init; load tracking thread-safe.

    Contracts & checks
    - Preconditions: _create_contract must return valid AgentContract; _subscribe_to_events must set up subscriptions.
    - Postconditions: execute returns Optional[AgentEvent]; get_stats returns dict with statistics.

    Concurrency & I/O
    - Thread-safe load tracking (increment/decrement).
    - No I/O operations.

    Error surface
    - Raises: None (mesh registration failures logged; execution errors tracked in stats).
    """

    def __init__(self, agent_id: str, config, event_bus: EventBus, enable_mesh: bool = False,
                 tone_config: Optional[Dict[str, Any]] = None,
                 perf_config: Optional[Dict[str, Any]] = None,
                 agent_config: Optional[Dict[str, Any]] = None):
        """Initialize agent.

        Args:
            agent_id: Unique identifier for the agent.
            config: System configuration object.
            event_bus: EventBus instance for communication.
            enable_mesh: Whether to enable mesh capabilities.
            tone_config: Optional tone configuration dictionary.
            perf_config: Optional performance configuration dictionary.
            agent_config: Optional agent-specific configuration dictionary.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            agent_id must be non-empty string; config and event_bus must be valid objects.

        Postconditions:
            Agent initialized with contract, subscriptions, and optional mesh setup.

        Side Effects:
            Event subscriptions created; mesh registration attempted if enabled.

        I/O schema:
            - Input shape: agent_id (str), config (object), event_bus (EventBus), enable_mesh (bool), tone_config (dict), perf_config (dict), agent_config (dict).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state in init.
            - Performance: Contract creation and subscription setup.

        Configuration:
            - tone_config: Controls tone-related behavior.
            - perf_config: Controls performance limits and timeouts.
            - agent_config: Agent-specific settings.

        External interactions:
            - None.
        """
        self.agent_id = agent_id
        self.config = config
        self.event_bus = event_bus
        self.enable_mesh = enable_mesh
        
        # Configuration support
        self.tone_config = tone_config or {}
        self.perf_config = perf_config or {}
        self.agent_config = agent_config or {}

        # Stats
        self.executions = 0
        self.failures = 0
        self.total_time = 0.0

        # Mesh features (optional)
        self._capability_registry = None
        self._current_load = 0
        self._max_capacity = self.perf_config.get('limits', {}).get('max_parallel', 3)

        # Contract & subscriptions
        self.contract = self._create_contract()
        self._subscribe_to_events()

        logger.info("Initialized %s (mesh=%s, tone=%s, perf=%s)", 
                   agent_id, enable_mesh, bool(tone_config), bool(perf_config))

    @abstractmethod
    def _create_contract(self) -> AgentContract:
        """Create agent contract.

        Args:
            None.

        Returns:
            AgentContract: Contract defining agent capabilities.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns valid AgentContract with agent_id, capabilities, schemas.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: AgentContract.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Contract creation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        ...

    @abstractmethod
    def _subscribe_to_events(self):
        """Set up event subscriptions.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            event_bus must be available.

        Postconditions:
            Agent subscribed to relevant events.

        Side Effects:
            Event subscriptions created.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Uses event_bus thread-safe methods.
            - Performance: Subscription operations.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        ...

    @abstractmethod
    def execute(self, event: AgentEvent) -> Optional[AgentEvent]:
        """Execute agent logic based on event.

        Args:
            event: AgentEvent to process.

        Returns:
            Optional[AgentEvent]: Result event or None.

        Raises:
            None.

        Preconditions:
            event must be valid AgentEvent.

        Postconditions:
            Execution statistics updated; returns result event if applicable.

        Side Effects:
            Agent state may change; statistics updated.

        I/O schema:
            - Input shape: event (AgentEvent).
            - Output shape: AgentEvent or None.

        Concurrency & performance:
            - Thread-safe: Implementation dependent.
            - Performance: Depends on agent logic.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        ...

    def _track_execution(self, success: bool, duration: float):
        """Track execution statistics.

        Args:
            success: Whether execution was successful.
            duration: Execution duration in seconds.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            duration must be non-negative float.

        Postconditions:
            executions, failures, total_time updated.

        Side Effects:
            Statistics counters updated.

        I/O schema:
            - Input shape: success (bool), duration (float).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple arithmetic.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        self.executions += 1
        if not success:
            self.failures += 1
        self.total_time += duration

    def get_stats(self) -> Dict[str, Any]:
        """Get execution statistics.

        Args:
            None.

        Returns:
            Dict[str, Any]: Statistics dictionary.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns dict with agent_id, executions, failures, success_rate, avg_time, total_time.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple calculations.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return {
            "agent_id": self.agent_id,
            "executions": self.executions,
            "failures": self.failures,
            "success_rate": 1.0 - (self.failures / max(self.executions, 1)),
            "avg_time": self.total_time / max(self.executions, 1),
            "total_time": self.total_time,
        }

    def register_with_mesh(self, capability_registry):
        """Register agent with mesh capability registry.

        Args:
            capability_registry: Mesh capability registry to register with.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            enable_mesh must be True; capability_registry must have register_agent method.

        Postconditions:
            Agent registered with mesh if enabled.

        Side Effects:
            _capability_registry set; log message.

        I/O schema:
            - Input shape: capability_registry (object).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Registry method call.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        if self.enable_mesh:
            self._capability_registry = capability_registry
            # Expecting registry.register_agent(agent_id, self, self.contract)
            try:
                capability_registry.register_agent(self.agent_id, self, self.contract)  # type: ignore[attr-defined]
                logger.info("%s registered with mesh", self.agent_id)
            except Exception as e:
                logger.warning("Mesh registration failed for %s: %s", self.agent_id, e)

    def increment_load(self):
        """Increment current load counter.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            enable_mesh must be True.

        Postconditions:
            _current_load increased by 1.

        Side Effects:
            Load counter updated.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple increment.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        if self.enable_mesh:
            self._current_load += 1

    def decrement_load(self):
        """Decrement current load counter.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            enable_mesh must be True.

        Postconditions:
            _current_load decreased by 1, minimum 0.

        Side Effects:
            Load counter updated.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple decrement with min check.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        if self.enable_mesh:
            self._current_load = max(0, self._current_load - 1)

    @property
    def current_load(self) -> int:
        """Get current load.

        Args:
            None.

        Returns:
            int: Current load level.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns _current_load if mesh enabled, else 0.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: int.

        Concurrency & performance:
            - Thread-safe: Property access.
            - Performance: Simple attribute access.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return self._current_load if self.enable_mesh else 0

    @property
    def max_capacity(self) -> int:
        """Get maximum capacity.

        Args:
            None.

        Returns:
            int: Maximum capacity.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns _max_capacity.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: int.

        Concurrency & performance:
            - Thread-safe: Property access.
            - Performance: Simple attribute access.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return self._max_capacity
    
    def get_timeout(self, timeout_type: str = 'agent_execution') -> float:
        """Get timeout value from perf_config.

        Args:
            timeout_type: Type of timeout to retrieve.

        Returns:
            float: Timeout value in seconds.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns timeout from perf_config or default 30.0.

        Side Effects:
            None.

        I/O schema:
            - Input shape: timeout_type (str).
            - Output shape: float.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Dict access.

        Configuration:
            - perf_config: Source of timeout values.

        External interactions:
            - None.
        """
        return self.perf_config.get('timeouts', {}).get(timeout_type, 30.0)
    
    def get_limit(self, limit_type: str) -> int:
        """Get limit value from perf_config.

        Args:
            limit_type: Type of limit to retrieve.

        Returns:
            int: Limit value.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns limit from perf_config or default value.

        Side Effects:
            None.

        I/O schema:
            - Input shape: limit_type (str).
            - Output shape: int.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Dict access.

        Configuration:
            - perf_config: Source of limit values.

        External interactions:
            - None.
        """
        limits = self.perf_config.get('limits', {})
        return limits.get(limit_type, {
            'max_tokens_per_agent': 4000,
            'max_steps': 50,
            'max_retries': 3,
            'max_context_size': 16000
        }.get(limit_type, 0))
    
    def get_tone_setting(self, section: str, setting: str, default: Any = None) -> Any:
        """Get tone configuration setting for a specific section.

        Args:
            section: Configuration section name.
            setting: Setting name within section.
            default: Default value if not found.

        Returns:
            Any: Setting value or default.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns setting from tone_config or default.

        Side Effects:
            None.

        I/O schema:
            - Input shape: section (str), setting (str), default (Any).
            - Output shape: Any.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Dict access.

        Configuration:
            - tone_config: Source of tone settings.

        External interactions:
            - None.
        """
        section_controls = self.tone_config.get('section_controls', {})
        section_config = section_controls.get(section, {})
        return section_config.get(setting, default)
    
    def is_section_enabled(self, section: str) -> bool:
        """Check if a section is enabled in tone config.

        Args:
            section: Section name to check.

        Returns:
            bool: True if section is enabled.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns enabled status from tone_config or True.

        Side Effects:
            None.

        I/O schema:
            - Input shape: section (str).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Dict access.

        Configuration:
            - tone_config: Source of section enable flags.

        External interactions:
            - None.
        """
        return self.get_tone_setting(section, 'enabled', True)


class SelfCorrectingAgent:
    """Mixin for self-correcting agents (from v5_1).

    Responsibilities
    - Provide self-correction capability for agents
    - Attempt to fix results using LLM when validation fails

    Construction
    - Parameters: None (mixin class).
    - Preconditions in __init__: None.
    - Attributes: None.

    Public API
    - self_correct(result: Dict[str, Any], prompt: str, llm_service, max_attempts: int) -> Dict[str, Any]: Attempt self-correction.

    State & invariants
    - Attributes: None.
    - Invariants (validated in code): Placeholder implementation returns original result.

    Contracts & checks
    - Preconditions: llm_service must be valid; max_attempts must be positive.
    - Postconditions: Returns result dict (potentially corrected).

    Concurrency & I/O
    - No thread-safety requirements.
    - No I/O operations.

    Error surface
    - Raises: None.
    """

    def self_correct(self, result: Dict[str, Any], prompt: str, llm_service, max_attempts: int = 3) -> Dict[str, Any]:
        """Attempt self-correction of results.

        Args:
            result: Current result dictionary.
            prompt: Correction prompt.
            llm_service: LLM service for correction.
            max_attempts: Maximum correction attempts.

        Returns:
            Dict[str, Any]: Corrected result or original.

        Raises:
            None.

        Preconditions:
            result must be dict; prompt must be string; max_attempts positive.

        Postconditions:
            Returns result dict (currently unchanged placeholder).

        Side Effects:
            None.

        I/O schema:
            - Input shape: result (dict), prompt (str), llm_service (object), max_attempts (int).
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Placeholder - no actual work.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        for _ in range(max_attempts):
            # Placeholder for validator + correction prompts
            return result
        return result


__all__ = ['Agent', 'SelfCorrectingAgent']
# DOCGEN:LLM-FIRST@v4