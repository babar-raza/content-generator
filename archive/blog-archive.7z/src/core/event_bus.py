"""DOCGEN:LLM-FIRST@v1

Module overview
- Purpose: Provides thread-safe event bus for decoupled agent communication within the content generator system.
- Lifecycle: Instantiated during system initialization; mesh integration set up optionally.
- Collaborators: Used by src.orchestration modules for job coordination; src.mesh for distributed events; src.engine for workflow events.
- Key inputs: AgentEvent instances to publish; event types and callbacks for subscriptions.
- Key outputs: Published events to subscribers; event history for debugging; subscriber counts.

Public API Catalog
| Symbol | Kind | Defined in | Purpose | Inputs | Outputs | Raises | Notes |
|-------:|:-----|:-----------|:--------|:-------|:--------|:-------|:------|
| EventBus | class | event_bus | Thread-safe event bus for agent communication | enable_mesh: bool | EventBus instance | None | Publish-subscribe pattern |

Deeper dive
- Data flow: EventBus instantiated → subscribers register callbacks → events published → callbacks invoked with error isolation → history maintained.
- Invariants & contracts: Thread safety during subscribe/unsubscribe/publish; error isolation (one handler failure doesn't stop others); history size limits.
- Preconditions: None.
- Postconditions: EventBus ready for subscriptions and publishing.
- Error surface: Exceptions in event handlers are logged but don't propagate; invalid event types handled gracefully.
- Concurrency & async: Thread-safe operations with RLock; no async.
- I/O & performance: Lightweight operations; history pruning prevents memory growth.
- Configuration map: enable_mesh flag for optional mesh integration.
- External dependencies: logging, threading, collections, contracts.AgentEvent.
"""

import logging
import threading
from typing import Dict, List, Callable, Any, Optional
from collections import defaultdict

from .contracts import AgentEvent

logger = logging.getLogger(__name__)


class EventBus:
    """Thread-safe event bus for agent communication.

    Responsibilities
    - Manage event subscriptions by type
    - Publish events to all subscribers with error isolation
    - Maintain event history for debugging
    - Support optional mesh integration

    Construction
    - Parameters: enable_mesh (bool, default False).
    - Preconditions in __init__: None.
    - Attributes: _subscribers (Dict[str, List[Callable]]), _lock (threading.RLock), _event_history (List[AgentEvent]), _max_history (int), enable_mesh (bool), _capability_registry (optional), _mesh_observer (optional).

    Public API
    - subscribe(event_type: str, callback: Callable[[AgentEvent], Any]): Register callback for event type.
    - unsubscribe(event_type: str, callback: Callable[[AgentEvent], Any]): Remove callback for event type.
    - publish(event: AgentEvent): Publish event to all subscribers.
    - get_history(event_type: Optional[str], limit: int): Get recent events from history.
    - clear_history(): Clear event history.
    - set_mesh_integration(capability_registry, mesh_observer): Enable mesh features.
    - get_subscriber_count(event_type: str) -> int: Get number of subscribers for event type.

    State & invariants
    - Attributes: _subscribers (dict of lists), _lock (RLock), _event_history (list), _max_history (1000), enable_mesh (bool).
    - Invariants (validated in code): Thread-safe subscribe/unsubscribe/publish operations; event history limited to _max_history size; subscriber errors don't prevent other callbacks.

    Contracts & checks
    - Preconditions: subscribe requires valid event_type and callable callback; publish requires AgentEvent instance.
    - Postconditions: subscribe adds callback to subscribers; publish calls all callbacks with error isolation.

    Concurrency & I/O
    - Thread-safe with RLock for all operations.
    - No I/O operations.

    Error surface
    - Raises: None (exceptions in handlers logged but not propagated).
    """

    def __init__(self, enable_mesh: bool = False):
        """Initialize EventBus.

        Args:
            enable_mesh: Whether to enable mesh integration features.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            EventBus initialized with empty subscribers, lock, and history.

        Side Effects:
            None.

        I/O schema:
            - Input shape: enable_mesh (bool).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Lock created.
            - Performance: Lightweight initialization.

        Configuration:
            - enable_mesh: Controls mesh integration.

        External interactions:
            - None.
        """
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self._lock = threading.RLock()
        self._event_history: List[AgentEvent] = []
        self._max_history = 1000
        self.enable_mesh = enable_mesh

        # Optional mesh integration
        self._capability_registry = None
        self._mesh_observer = None

    def subscribe(self, event_type: str, callback: Callable[[AgentEvent], Any]):
        """Subscribe to events of a specific type.

        Args:
            event_type: Type of events to subscribe to.
            callback: Function to call when events are published.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            event_type must be string; callback must be callable.

        Postconditions:
            Callback added to subscribers for event_type if not already present.

        Side Effects:
            None.

        I/O schema:
            - Input shape: event_type (str), callback (callable).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: Dict and list operations.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            if callback not in self._subscribers[event_type]:
                self._subscribers[event_type].append(callback)

    def unsubscribe(self, event_type: str, callback: Callable[[AgentEvent], Any]):
        """Unsubscribe from events of a specific type.

        Args:
            event_type: Type of events to unsubscribe from.
            callback: Function to remove from subscribers.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            event_type must be string; callback must be callable.

        Postconditions:
            Callback removed from subscribers for event_type if present.

        Side Effects:
            None.

        I/O schema:
            - Input shape: event_type (str), callback (callable).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: List removal operation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            if callback in self._subscribers[event_type]:
                self._subscribers[event_type].remove(callback)

    def publish(self, event: AgentEvent):
        """Publish an event to all subscribers with full error handling.

        Args:
            event: AgentEvent to publish.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            event must be AgentEvent instance.

        Postconditions:
            Event added to history; all subscribers called with error isolation.

        Side Effects:
            Event handlers may have side effects; history may be pruned.

        I/O schema:
            - Input shape: event (AgentEvent).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Uses internal lock for history; subscribers called outside lock.
            - Performance: History append/prune; callback invocation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            # Add to history
            self._event_history.append(event)
            if len(self._event_history) > self._max_history:
                self._event_history.pop(0)
            
            # Get subscribers
            subscribers = self._subscribers.get(event.event_type, [])
            
            if not subscribers:
                logger.debug(f"No subscribers for {event.event_type}")
                return
            
            logger.debug(f"Publishing {event.event_type} to {len(subscribers)} subscribers")
        
        # Call subscribers (outside lock to prevent deadlock)
        for callback in subscribers:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Error in event handler for {event.event_type}: {e}")
                # Continue with other subscribers - don't break the chain
                continue
                
    def get_history(self, event_type: Optional[str] = None, limit: int = 100):
        """Get event history.

        Args:
            event_type: Optional event type filter.
            limit: Maximum number of events to return.

        Returns:
            List[AgentEvent]: Recent events from history.

        Raises:
            None.

        Preconditions:
            limit must be positive integer.

        Postconditions:
            Returns list of recent events, filtered by event_type if provided.

        Side Effects:
            None.

        I/O schema:
            - Input shape: event_type (str), limit (int).
            - Output shape: list of AgentEvent.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: List slicing operations.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            if event_type:
                events = [e for e in self._event_history if e.event_type == event_type]
            else:
                events = list(self._event_history)
            return events[-limit:]

    def clear_history(self):
        """Clear event history.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Event history is empty.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: List clear operation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            self._event_history.clear()

    def set_mesh_integration(self, capability_registry, mesh_observer):
        """Set mesh integration components.

        Args:
            capability_registry: Mesh capability registry.
            mesh_observer: Mesh observer component.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            capability_registry and mesh_observer must be valid objects.

        Postconditions:
            Mesh integration enabled with provided components.

        Side Effects:
            enable_mesh set to True; info log message.

        I/O schema:
            - Input shape: capability_registry (object), mesh_observer (object).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Attribute assignment.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        self._capability_registry = capability_registry
        self._mesh_observer = mesh_observer
        self.enable_mesh = True
        logger.info("Mesh integration enabled")

    def get_subscriber_count(self, event_type: str) -> int:
        """Get number of subscribers for an event type.

        Args:
            event_type: Event type to check.

        Returns:
            int: Number of subscribers.

        Raises:
            None.

        Preconditions:
            event_type must be string.

        Postconditions:
            Returns count of subscribers for event_type.

        Side Effects:
            None.

        I/O schema:
            - Input shape: event_type (str).
            - Output shape: int.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: Dict and list length operations.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            return len(self._subscribers.get(event_type, []))


__all__ = ['EventBus']
# DOCGEN:LLM-FIRST@v4