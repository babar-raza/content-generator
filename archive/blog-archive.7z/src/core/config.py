"""DOCGEN:LLM-FIRST@v1

Module overview
- Purpose: Centralizes all configuration management for the content generator system, including LLM providers, database, mesh, and orchestration settings.
- Lifecycle: Instantiated during startup; loads from env and files; provides runtime configuration throughout operation.
- Collaborators: Used by src.initialization for system setup; consumed by all modules requiring configuration; drives behavior of src.services and src.orchestration.
- Key inputs: Environment variables, config files (tone.json, main.yaml, agents.yaml), template files.
- Key outputs: Configured instances of Config class; loaded schemas, templates, and tone settings; auto-detected device and provider settings.

Public API Catalog
| Symbol | Kind | Defined in | Purpose | Inputs | Outputs | Raises | Notes |
|-------:|:-----|:-----------|:--------|:-------|:--------|:-------|:------|
| Config | class | config | Main configuration class | Various paths and settings | Config instance | None | Hierarchical config |
| LLMConfig | class | config | LLM provider configuration | API keys, models, settings | LLMConfig instance | None | Sub-config for LLM |
| DatabaseConfig | class | config | Database configuration | Paths, models | DatabaseConfig instance | None | Sub-config for DB |
| MeshConfig | class | config | Mesh configuration | Enabled, timeouts, strategies | MeshConfig instance | None | Sub-config for mesh |
| OrchestrationConfig | class | config | Orchestration configuration | Host, port, dirs | OrchestrationConfig instance | None | Sub-config for orchestration |
| SCHEMAS | dict | config | Loaded schemas registry | None | Dict[str, Dict[str, Any]] | None | From agents.yaml |
| load_schemas | function | config | Load schemas from config | config | None | Exception | Populates SCHEMAS |

Deeper dive
- Data flow: Config instantiated → load_from_env called → files loaded lazily → configuration used throughout system.
- Invariants & contracts: Config paths must exist or be creatable; environment variables override defaults; family detection from paths is consistent.
- Preconditions: None.
- Postconditions: Config ready with all settings loaded.
- Error surface: File loading failures logged but non-fatal; missing dependencies (torch, yaml) handled gracefully; provider auto-detection may default to Ollama.
- Concurrency & async: No concurrency requirements; lazy loading.
- I/O & performance: Lazy loading prevents startup delays; caching of loaded configs; optional PyYAML import avoids hard dependencies.
- Configuration map: Environment variables override defaults; config files provide detailed settings.
- External dependencies: os, json, pathlib, dataclasses, logging; optional torch, yaml.
"""

import os
import json
from typing import Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)

# CUDA detection
try:
    import torch  # type: ignore
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None  # type: ignore

# Optional YAML import (lazy-fallback to avoid hard dependency at import time)
try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None  # type: ignore


@dataclass
class LLMConfig:
    """LLM provider configuration.

    Args:
        gemini_api_key: Gemini API key.
        openai_api_key: OpenAI API key.
        ollama_base_url: Ollama server URL.
        default_model: Default model name.
        temperature: Generation temperature.
        max_tokens: Maximum tokens per request.

    Returns:
        LLMConfig instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        LLMConfig initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: gemini_api_key (str), openai_api_key (str), ollama_base_url (str), default_model (str), temperature (float), max_tokens (int).
        - Output shape: LLMConfig instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    gemini_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    ollama_base_url: str = "http://localhost:11434"
    default_model: str = "llama2"
    temperature: float = 0.7
    max_tokens: int = 4096


@dataclass
class DatabaseConfig:
    """Database configuration.

    Args:
        chroma_db_path: Path to ChromaDB database.
        embedding_model: Embedding model name.
        collection_name: Collection name for knowledge base.

    Returns:
        DatabaseConfig instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        DatabaseConfig initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: chroma_db_path (str), embedding_model (str), collection_name (str).
        - Output shape: DatabaseConfig instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    chroma_db_path: str = "./chroma_db"
    embedding_model: str = "all-MiniLM-L6-v2"
    collection_name: str = "blog_knowledge"


@dataclass
class MeshConfig:
    """Mesh configuration.

    Args:
        enabled: Whether mesh is enabled.
        registry_timeout: Timeout for registry operations.
        bid_strategy: Strategy for bid selection.
        cache_enabled: Whether caching is enabled.
        async_enabled: Whether async operations are enabled.
        max_workers: Maximum worker threads.
        batch_size: Batch size for operations.

    Returns:
        MeshConfig instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        MeshConfig initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: enabled (bool), registry_timeout (float), bid_strategy (str), cache_enabled (bool), async_enabled (bool), max_workers (int), batch_size (int).
        - Output shape: MeshConfig instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    enabled: bool = False
    registry_timeout: float = 2.0
    bid_strategy: str = "highest_score"
    cache_enabled: bool = True
    async_enabled: bool = True
    max_workers: int = 4
    batch_size: int = 5


@dataclass
class OrchestrationConfig:
    """Orchestration configuration.

    Args:
        enabled: Whether orchestration is enabled.
        ops_console_host: Host for ops console.
        ops_console_port: Port for ops console.
        checkpoint_dir: Directory for checkpoints.
        workflow_dir: Directory for workflows.
        hot_reload: Whether hot reload is enabled.

    Returns:
        OrchestrationConfig instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        OrchestrationConfig initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: enabled (bool), ops_console_host (str), ops_console_port (int), checkpoint_dir (str), workflow_dir (str), hot_reload (bool).
        - Output shape: OrchestrationConfig instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    enabled: bool = False
    ops_console_host: str = "0.0.0.0"
    ops_console_port: int = 8080
    checkpoint_dir: str = "./checkpoints"
    workflow_dir: str = "./templates"
    hot_reload: bool = True


@dataclass
class Config:
    """Main configuration class.

    Responsibilities
    - Manage hierarchical configuration with sub-configs
    - Auto-detect device and LLM provider
    - Load configuration from environment and files
    - Provide lazy loading of templates and schemas

    Construction
    - Parameters: Various path and configuration fields.
    - Preconditions in __init__: None.
    - Attributes: Paths (config_dir, templates_dir, etc.), family (str), device (str), sub-configs (llm, database, mesh, orchestration), provider settings, feature flags, loaded data (_tone_config, _templates, _schemas).

    Public API
    - __post_init__(): Resolve auto-detection fields.
    - load_from_env(): Load from environment variables.
    - _auto_detect_provider() -> str: Auto-detect LLM provider.
    - load_tone_config() -> Dict[str, Any]: Load tone configuration.
    - load_templates() -> Dict[str, Any]: Load templates.
    - get_template(template_type: str) -> Dict[str, Any]: Get specific template.
    - load_workflow_config() -> Dict[str, Any]: Load workflow config.

    State & invariants
    - Attributes: _tone_config, _templates, _schemas (lazy loaded).
    - Invariants (validated in code): Paths are Path objects; device resolved to 'cuda' or 'cpu'; provider auto-detection works.

    Contracts & checks
    - Preconditions: detect_family_from_path requires valid Path.
    - Postconditions: load_from_env updates instance fields; lazy loaders cache results.

    Concurrency & I/O
    - No thread-safety requirements.
    - I/O in lazy loaders (file reading).

    Error surface
    - Raises: None (file loading failures logged).
    """
    
    # Paths
    config_dir: Path = field(default_factory=lambda: Path("./config"))
    templates_dir: Path = field(default_factory=lambda: Path("./templates"))
    output_dir: Path = field(default_factory=lambda: Path("./output"))
    cache_dir: Path = field(default_factory=lambda: Path("./cache"))
    chroma_db_path: Path = field(default_factory=lambda: Path("./chroma_db"))
    ingestion_state_file: Path = field(default_factory=lambda: Path("./ingestion_state.json"))
    
    # Family detection (auto-detected from paths or set manually)
    family: str = "general"
    
    # Family name mapping (for API products)
    FAMILY_NAME_MAP = {
        'words': 'Aspose.Words',
        'pdf': 'Aspose.PDF',
        'cells': 'Aspose.Cells',
        'slides': 'Aspose.Slides',
        'email': 'Aspose.Email',
        'barcode': 'Aspose.BarCode',
        'diagram': 'Aspose.Diagram',
        'tasks': 'Aspose.Tasks',
        'ocr': 'Aspose.OCR',
        'note': 'Aspose.Note',
        'imaging': 'Aspose.Imaging',
        'zip': 'Aspose.ZIP',
    }
    
    # Device settings - CUDA auto-detection (overrideable by RUNTIME_DEVICE env var)
    device: str = field(default="auto")  # Will be resolved in post_init
    embedding_batch_size: int = 32

    # Sub-configurations
    llm: LLMConfig = field(default_factory=LLMConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    mesh: MeshConfig = field(default_factory=MeshConfig)
    orchestration: OrchestrationConfig = field(default_factory=OrchestrationConfig)

    # LLM Provider Settings
    llm_provider: Optional[str] = None
    gemini_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    gemini_rpm_limit: int = 15
    
    # Model Configuration
    gemini_model: str = "models/gemini-2.0-flash"
    openai_model: str = "gpt-4o-mini"
    
    # Ollama-specific settings
    ollama_base_url: str = "http://localhost:11434"
    ollama_topic_model: str = "llama2"
    ollama_content_model: str = "qwen2.5"
    ollama_code_model: str = "qwen2.5-coder"
    
    llm_temperature: float = 0.7
    deterministic: bool = False
    cache_ttl: int = 86400  # 24 hours
    
    # Ollama Model Router settings
    enable_smart_routing: bool = True  # Enable intelligent model selection
    
    # GitHub settings
    gist_upload_enabled: bool = False
    github_gist_token: Optional[str] = None

    # Feature flags
    enable_mesh: bool = False
    enable_orchestration: bool = False
    enable_caching: bool = True
    enable_learning: bool = True
    
    # Workflow execution mode
    use_langgraph: bool = False  # Enable LangGraph-based execution (experimental)
    
    # Parallel execution settings
    enable_parallel_execution: bool = False  # Enable parallel agent execution
    max_parallel_agents: int = 3  # Maximum concurrent agents

    # Performance
    request_timeout: int = 300
    max_retries: int = 3
    backoff_factor: float = 2.0

    # Logging
    log_level: str = "INFO"
    log_format: str = "json"

    # Loaded data (lazy)
    _tone_config: Optional[Dict[str, Any]] = None
    _templates: Optional[Dict[str, Any]] = None
    _schemas: Optional[Dict[str, Any]] = None

    @staticmethod
    def detect_family_from_path(path: Path) -> str:
        """Detect API family from file path.

        Args:
            path: Path to analyze.

        Returns:
            str: Detected family or 'general'.

        Raises:
            None.

        Preconditions:
            path must be valid Path object.

        Postconditions:
            Returns family key if found in path parts.

        Side Effects:
            None.

        I/O schema:
            - Input shape: path (Path).
            - Output shape: str.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Path parts iteration.

        Configuration:
            - FAMILY_NAME_MAP: Used for family detection.

        External interactions:
            - None.
        """
        path_parts = [part.lower() for part in path.parts]
        
        for family_key in Config.FAMILY_NAME_MAP.keys():
            if family_key in path_parts:
                return family_key
        
        return "general"
    
    def __post_init__(self):
        """Resolve auto-detection fields after initialization.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            device resolved to 'cuda' or 'cpu'.

        Side Effects:
            device attribute updated.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: CUDA availability check.

        Configuration:
            - RUNTIME_DEVICE: Environment variable for device override.

        External interactions:
            - torch.cuda.is_available() if torch available.
        """
        # Auto-detect device if set to 'auto'
        if self.device == "auto":
            env_device = os.getenv("RUNTIME_DEVICE", "").lower()
            if env_device in ["cuda", "cpu"]:
                self.device = env_device
            else:
                # Auto-detect CUDA
                self.device = "cuda" if (TORCH_AVAILABLE and torch.cuda.is_available()) else "cpu"

    def load_from_env(self):
        """Load configuration from environment variables with smart defaults.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Instance fields updated from environment.

        Side Effects:
            Many instance attributes updated.

        I/O schema:
            - Input shape: None.
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Environment variable access.

        Configuration:
            - Many environment variables (LLM_PROVIDER, GEMINI_API_KEY, etc.).

        External interactions:
            - os.getenv calls.
        """
        
        # LLM Provider - with auto-detection fallback
        env_provider = os.getenv("LLM_PROVIDER", "").upper()
        if env_provider in ["OLLAMA", "GEMINI", "OPENAI"]:
            self.llm_provider = env_provider
        else:
            # Auto-detect: Ollama (free) → Gemini (free tier) → OpenAI (paid)
            self.llm_provider = self._auto_detect_provider()
        
        # API Keys
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        
        # Store in llm sub-config for backwards compatibility
        self.llm.gemini_api_key = self.gemini_api_key
        self.llm.openai_api_key = self.openai_api_key
        self.llm.ollama_base_url = os.getenv("OLLAMA_BASE_URL", self.ollama_base_url)
        
        # Model Configuration
        self.gemini_model = os.getenv("GEMINI_MODEL", self.gemini_model)
        self.openai_model = os.getenv("OPENAI_MODEL", self.openai_model)
        self.gemini_rpm_limit = int(os.getenv("GEMINI_RPM_LIMIT", str(self.gemini_rpm_limit)))
        
        # Ollama Models
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL", self.ollama_base_url)
        self.ollama_topic_model = os.getenv("OLLAMA_TOPIC_MODEL", self.ollama_topic_model)
        self.ollama_content_model = os.getenv("OLLAMA_CONTENT_MODEL", self.ollama_content_model)
        self.ollama_code_model = os.getenv("OLLAMA_CODE_MODEL", self.ollama_code_model)
        
        # Performance Settings
        self.llm_temperature = float(os.getenv("LLM_TEMPERATURE", str(self.llm_temperature)))
        self.cache_ttl = int(os.getenv("CACHE_TTL", str(self.cache_ttl)))
        self.enable_smart_routing = os.getenv("ENABLE_SMART_ROUTING", "true").lower() == "true"
        
        # Database
        self.database.chroma_db_path = os.getenv("CHROMA_DB_PATH", self.database.chroma_db_path)

        # Feature Flags
        self.mesh.enabled = os.getenv("MESH_ENABLED", "false").lower() == "true"
        self.enable_mesh = self.mesh.enabled

        self.orchestration.enabled = os.getenv("ORCHESTRATION_ENABLED", "false").lower() == "true"
        self.enable_orchestration = self.orchestration.enabled
        
        self.enable_caching = os.getenv("ENABLE_CACHING", "true").lower() == "true"

        # Logging
        self.log_level = os.getenv("LOG_LEVEL", self.log_level)
        
        # GitHub Gist
        self.gist_upload_enabled = os.getenv("GIST_UPLOAD_ENABLED", "false").lower() == "true"
        self.github_gist_token = os.getenv("GITHUB_GIST_TOKEN")
    
    def _auto_detect_provider(self) -> str:
        """Auto-detect available LLM provider.

        Args:
            None.

        Returns:
            str: Best available provider name.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns 'OLLAMA', 'GEMINI', or 'OPENAI'.

        Side Effects:
            Logger messages for detection results.

        I/O schema:
            - Input shape: None.
            - Output shape: str.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: HTTP request to Ollama.

        Configuration:
            - ollama_base_url: Used for Ollama detection.

        External interactions:
            - HTTP request to Ollama /api/tags endpoint.
        """
        # 1. Try Ollama (free, local)
        try:
            import requests  # type: ignore
            response = requests.get(
                f"{self.ollama_base_url}/api/tags",
                timeout=2
            )
            if response.status_code == 200:
                logger.info("✓ Auto-detected Ollama as LLM provider")
                return "OLLAMA"
        except Exception:
            pass
        
        # 2. Try Gemini (free tier, requires API key)
        if os.getenv("GEMINI_API_KEY"):
            logger.info("✓ Auto-detected Gemini as LLM provider (API key found)")
            return "GEMINI"
        
        # 3. Try OpenAI (paid, requires API key)
        if os.getenv("OPENAI_API_KEY"):
            logger.info("✓ Auto-detected OpenAI as LLM provider (API key found)")
            return "OPENAI"
        
        # 4. Default to Ollama (will need manual setup)
        logger.warning("⚠ No LLM provider detected, defaulting to Ollama")
        logger.warning("  Make sure Ollama is running or set GEMINI_API_KEY/OPENAI_API_KEY")
        return "OLLAMA"

    def load_tone_config(self) -> Dict[str, Any]:
        """Load tone configuration from tone.json.

        Args:
            None.

        Returns:
            Dict[str, Any]: Tone configuration.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns loaded config or empty dict.

        Side Effects:
            _tone_config cached if loaded.

        I/O schema:
            - Input shape: None.
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: File read operation.

        Configuration:
            - config_dir / "tone.json": Source file.

        External interactions:
            - File system read.
        """
        if self._tone_config is None:
            tone_file = self.config_dir / "tone.json"
            if tone_file.exists():
                try:
                    self._tone_config = json.loads(tone_file.read_text(encoding="utf-8"))
                except Exception as e:  # pragma: no cover
                    logger.warning("Failed to load tone.json: %s", e)
                    self._tone_config = {}
            else:
                self._tone_config = {}
        return self._tone_config

    def load_templates(self) -> Dict[str, Any]:
        """Load templates from YAML files.

        Args:
            None.

        Returns:
            Dict[str, Any]: Loaded templates.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns loaded templates dict.

        Side Effects:
            _templates cached if loaded.

        I/O schema:
            - Input shape: None.
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Multiple file reads.

        Configuration:
            - templates_dir: Directory containing YAML files.

        External interactions:
            - File system reads.
        """
        if self._templates is not None:
            return self._templates

        templates: Dict[str, Any] = {}
        if yaml is None:
            logger.info("PyYAML not available at import time; skipping templates load until runtime.")
            self._templates = templates
            return templates

        try:
            for template_file in self.templates_dir.glob("*.yaml"):
                with open(template_file, "r", encoding="utf-8") as f:
                    templates[template_file.stem] = yaml.safe_load(f) or {}
        except Exception as e:  # pragma: no cover
            logger.warning("Failed to load templates: %s", e)
        self._templates = templates
        return templates

    def get_template(self, template_type: str) -> Dict[str, Any]:
        """Get specific template by type.

        Args:
            template_type: Template type to retrieve.

        Returns:
            Dict[str, Any]: Template configuration.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns template dict or empty dict.

        Side Effects:
            None.

        I/O schema:
            - Input shape: template_type (str).
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Dict access.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        templates = self.load_templates()
        # naming convention: blog_templates, code_templates, frontmatter_templates, workflows
        return templates.get(f"{template_type}_templates", templates.get(template_type, {}))
    
    def load_workflow_config(self) -> Dict[str, Any]:
        """Load workflow configuration from main.yaml.

        Args:
            None.

        Returns:
            Dict[str, Any]: Workflow configuration.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns loaded config or empty dict.

        Side Effects:
            use_langgraph, enable_parallel_execution, max_parallel_agents updated if present.

        I/O schema:
            - Input shape: None.
            - Output shape: dict.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: File read operation.

        Configuration:
            - config_dir / "main.yaml": Source file.

        External interactions:
            - File system read.
        """
        if yaml is None:
            logger.warning("PyYAML not available; cannot load workflow config")
            return {}
        
        main_config_file = self.config_dir / "main.yaml"
        if not main_config_file.exists():
            logger.warning(f"main.yaml not found at {main_config_file}")
            return {}
        
        try:
            with open(main_config_file, "r", encoding="utf-8") as f:
                main_config = yaml.safe_load(f) or {}
            
            workflows_config = main_config.get('workflows', {})
            
            # Set use_langgraph flag if present
            if 'use_langgraph' in workflows_config:
                self.use_langgraph = workflows_config['use_langgraph']
            
            # Set parallel execution flags if present
            if 'enable_parallel_execution' in workflows_config:
                self.enable_parallel_execution = workflows_config['enable_parallel_execution']
            if 'max_parallel_agents' in workflows_config:
                self.max_parallel_agents = workflows_config['max_parallel_agents']
            
            return workflows_config
        except Exception as e:
            logger.warning(f"Failed to load workflow config: {e}")
            return {}


# Schemas registry (loaded from config/agents.yaml when available)
SCHEMAS: Dict[str, Dict[str, Any]] = {}


def load_schemas(config: Config):
    """Load schemas from agents.yaml if available.

    Args:
        config: Config instance with paths.

    Returns:
        None.

    Raises:
        Exception: If YAML loading fails.

    Preconditions:
        config must be valid Config instance.

    Postconditions:
        SCHEMAS global dict populated.

    Side Effects:
        SCHEMAS updated.

    I/O schema:
        - Input shape: config (Config).
        - Output shape: None.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: File read operation.

    Configuration:
        - config.config_dir / "agents.yaml": Source file.

    External interactions:
        - File system read.
    """
    global SCHEMAS
    agents_file = config.config_dir / "agents.yaml"
    if not agents_file.exists():
        SCHEMAS = {}
        return
    try:
        if yaml is None:
            logger.info("PyYAML not available; cannot parse agents.yaml at this time.")
            SCHEMAS = {}
            return
        with open(agents_file, "r", encoding="utf-8") as f:
            agents_data = yaml.safe_load(f) or {}
            SCHEMAS = agents_data.get("schemas", {})
    except Exception as e:  # pragma: no cover
        logger.warning("Failed to load schemas from agents.yaml: %s", e)
        SCHEMAS = {}


# ============================================================================
# CONSTANTS (from v5_1)
# ============================================================================

CSHARP_LICENSE_HEADER = """// Create an instance of the Metered class
Metered metered = new Metered();
// Set the metered key
string publicKey = "YourPublicKey";
string privateKey = "YourPrivateKey";
metered.SetMeteredKey(publicKey, privateKey);"""

# PROMPTS dictionary - loaded from templates
PROMPTS = {}

# FAILURE_STRATEGIES - error handling strategies
FAILURE_STRATEGIES = {
    "TimeoutError": [
        {"action": "increase_timeout", "params": {"multiplier": 2, "max": 30}},
        {"action": "switch_provider", "params": {"priority": ["OPENAI", "GEMINI", "OLLAMA"]}},
    ],
    "JSONParseError": [
        {"action": "enforce_json_mode", "params": {"strict": True}},
    ],
    "RateLimit": [
        {"action": "exponential_backoff", "params": {"max_attempts": 5}},
    ],
}


__all__ = [
    'Config', 'LLMConfig', 'DatabaseConfig', 'MeshConfig', 'OrchestrationConfig',
    'SCHEMAS', 'load_schemas', 'PROMPTS', 'CSHARP_LICENSE_HEADER', 'FAILURE_STRATEGIES'
]
# DOCGEN:LLM-FIRST@v4