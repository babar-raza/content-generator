"""At a glance
- Purpose: Provides mock LLM implementations for testing and development without external API dependencies.
- Key inputs: Prompts and agent types; configuration dictionaries.
- Key outputs: MockResponse objects with generated content; streaming chunks; usage metrics.
- External deps: json, logging, random, typing, dataclasses, hashlib.
- Collaborators: Used by tests and development environments; mimics real LLM service interfaces.
- Lifecycle: Instantiated per test/development session; caches responses for consistency.

Deeper dive
- Core concepts: Template-based content generation; prompt analysis for response type inference; caching for deterministic testing.
- Important invariants: Responses cached by prompt hash; token counts approximated consistently; streaming yields realistic chunks.
- Error surface: No external failures (fully mocked); template replacements may fail if placeholders missing.
- Performance notes: Fast generation with template substitution; caching prevents regeneration; lightweight for testing.
- Security notes: No real API calls; safe for development environments.
"""

import json
import logging
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import hashlib

logger = logging.getLogger(__name__)


@dataclass
class MockResponse:
    """Mock LLM response."""
    content: str
    tokens_used: int
    model: str
    provider: str


class MockLLMProvider:
    """Mock LLM provider for testing and development."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.response_cache = {}
        self.call_count = 0
        self.templates = self._load_templates()
        
    def _load_templates(self) -> Dict[str, List[str]]:
        """Load response templates for different agent types."""
        return {
            "outline": [
                """# {title}

## Introduction
- Hook the reader
- Introduce the topic
- Preview main points

## Main Content
### Section 1: Understanding {topic}
- Key concept 1
- Key concept 2
- Examples

### Section 2: Implementation
- Step-by-step guide
- Best practices
- Common pitfalls

### Section 3: Advanced Topics
- Advanced technique 1
- Advanced technique 2
- Real-world applications

## Conclusion
- Recap main points
- Call to action
- Additional resources""",
            ],
            "introduction": [
                """Have you ever wondered about {topic}? In today's rapidly evolving tech landscape, 
understanding {topic} has become more crucial than ever. Whether you're a seasoned developer 
or just starting your journey, this comprehensive guide will walk you through everything 
you need to know about {topic}, from basic concepts to advanced implementation strategies.""",
            ],
            "section": [
                """This section explores the fundamental aspects of {topic}. We'll start by breaking down 
the core concepts into digestible pieces. {topic} is essentially a method for achieving 
{purpose}, and it has revolutionized how we approach {domain}. 

Key benefits include:
- Improved efficiency
- Better scalability
- Enhanced maintainability

Let's dive deeper into each of these aspects...""",
            ],
            "conclusion": [
                """In this comprehensive guide, we've explored the ins and outs of {topic}. From understanding 
the basic concepts to implementing advanced techniques, you now have the knowledge needed to 
leverage {topic} in your own projects. Remember, mastery comes with practice, so don't hesitate 
to experiment with the concepts we've discussed. Happy coding!""",
            ],
            "code": [
                """```python
# Example implementation of {topic}
import example_module

class {class_name}:
    def __init__(self, config):
        self.config = config
        
    def process(self, data):
        # Process the data
        result = self._transform(data)
        return result
        
    def _transform(self, data):
        # Implementation details
        return f"Processed: {{data}}"

# Usage example
instance = {class_name}({{"key": "value"}})
result = instance.process("sample data")
print(result)
```""",
            ],
            "keywords": [
                '["python", "programming", "tutorial", "development", "software", "coding", "best practices"]',
            ],
            "metadata": [
                """{
    "title": "Complete Guide to {topic}",
    "description": "Learn everything about {topic} with this comprehensive tutorial",
    "keywords": ["tutorial", "{topic}", "guide", "programming"],
    "author": "AI Content Generator",
    "category": "Technology"
}""",
            ]
        }
        
    def generate(self, prompt: str, agent_type: Optional[str] = None, **kwargs) -> MockResponse:
        """Generate a mock response based on the prompt and agent type."""
        self.call_count += 1
        
        # Check cache
        prompt_hash = hashlib.md5(prompt.encode()).hexdigest()
        if prompt_hash in self.response_cache:
            logger.info(f"Returning cached response for prompt hash: {prompt_hash}")
            return self.response_cache[prompt_hash]
            
        # Extract context from prompt
        context = self._extract_context(prompt)
        
        # Determine response type
        if agent_type:
            response_type = agent_type.lower()
        else:
            response_type = self._infer_response_type(prompt)
            
        # Generate response
        content = self._generate_content(response_type, context)
        
        # Calculate mock token usage
        tokens = len(content.split()) * 2  # Rough approximation
        
        response = MockResponse(
            content=content,
            tokens_used=tokens,
            model="mock-model-v1",
            provider="MockLLMProvider"
        )
        
        # Cache the response
        self.response_cache[prompt_hash] = response
        
        logger.info(f"Generated mock response for {response_type} (tokens: {tokens})")
        return response
        
    def _extract_context(self, prompt: str) -> Dict[str, str]:
        """Extract context variables from the prompt."""
        context = {
            "topic": "Python Programming",
            "title": "Complete Guide",
            "purpose": "efficient development",
            "domain": "software engineering",
            "class_name": "ExampleClass"
        }
        
        # Try to extract topic from prompt
        if "about" in prompt.lower():
            words = prompt.split("about")[-1].split()[:3]
            context["topic"] = " ".join(words).strip(".,!?")
            
        return context
        
    def _infer_response_type(self, prompt: str) -> str:
        """Infer the type of response needed based on the prompt."""
        prompt_lower = prompt.lower()
        
        if any(word in prompt_lower for word in ["outline", "structure", "plan"]):
            return "outline"
        elif any(word in prompt_lower for word in ["introduction", "intro", "beginning"]):
            return "introduction"
        elif any(word in prompt_lower for word in ["conclusion", "summary", "wrap"]):
            return "conclusion"
        elif any(word in prompt_lower for word in ["code", "example", "implementation"]):
            return "code"
        elif any(word in prompt_lower for word in ["keyword", "seo", "tags"]):
            return "keywords"
        elif any(word in prompt_lower for word in ["metadata", "frontmatter"]):
            return "metadata"
        else:
            return "section"
            
    def _generate_content(self, response_type: str, context: Dict[str, str]) -> str:
        """Generate content based on type and context."""
        templates = self.templates.get(response_type, self.templates["section"])
        template = random.choice(templates)
        
        # Replace placeholders with context
        for key, value in context.items():
            template = template.replace(f"{{{key}}}", value)
            
        return template
        
    def stream_generate(self, prompt: str, agent_type: Optional[str] = None, **kwargs):
        """Stream mock response (yields chunks of text)."""
        response = self.generate(prompt, agent_type, **kwargs)
        
        # Simulate streaming by yielding chunks
        words = response.content.split()
        chunk_size = 5
        
        for i in range(0, len(words), chunk_size):
            chunk = " ".join(words[i:i+chunk_size])
            if i + chunk_size < len(words):
                chunk += " "
            yield chunk
            
    def get_metrics(self) -> Dict[str, Any]:
        """Get usage metrics."""
        return {
            "call_count": self.call_count,
            "cache_size": len(self.response_cache),
            "provider": "MockLLMProvider",
            "model": "mock-model-v1"
        }
        
    def reset(self):
        """Reset the mock provider state."""
        self.response_cache.clear()
        self.call_count = 0
        logger.info("Mock LLM provider reset")


class MockLLMService:
    """Mock LLM service that mimics the real LLMService interface."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.provider = MockLLMProvider(config)
        self.fallback_providers = []
        
    def call_llm(self, prompt: str, **kwargs) -> str:
        """Call the mock LLM and return response content."""
        response = self.provider.generate(prompt, **kwargs)
        return response.content
        
    async def call_llm_async(self, prompt: str, **kwargs) -> str:
        """Async version of call_llm."""
        return self.call_llm(prompt, **kwargs)
        
    def call_llm_with_fallback(self, prompt: str, **kwargs) -> str:
        """Call LLM with fallback support (mock always succeeds)."""
        return self.call_llm(prompt, **kwargs)
        
    def get_token_usage(self) -> int:
        """Get total token usage."""
        return sum(r.tokens_used for r in self.provider.response_cache.values())
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get service metrics."""
        return self.provider.get_metrics()
        
    def reset(self):
        """Reset the service."""
        self.provider.reset()


def create_mock_agents() -> Dict[str, callable]:
    """Create mock agent functions for testing."""
    
    provider = MockLLMProvider()
    
    def mock_outline_agent(input_data: Dict) -> Dict:
        prompt = f"Create an outline about {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="outline")
        return {"outline": response.content}
        
    def mock_introduction_agent(input_data: Dict) -> Dict:
        prompt = f"Write an introduction about {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="introduction")
        return {"introduction": response.content}
        
    def mock_section_agent(input_data: Dict) -> Dict:
        prompt = f"Write a section about {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="section")
        return {"section": response.content}
        
    def mock_conclusion_agent(input_data: Dict) -> Dict:
        prompt = f"Write a conclusion about {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="conclusion")
        return {"conclusion": response.content}
        
    def mock_code_agent(input_data: Dict) -> Dict:
        prompt = f"Generate code example for {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="code")
        return {"code": response.content}
        
    def mock_keyword_agent(input_data: Dict) -> Dict:
        prompt = f"Extract keywords from content"
        response = provider.generate(prompt, agent_type="keywords")
        return {"keywords": json.loads(response.content)}
        
    def mock_metadata_agent(input_data: Dict) -> Dict:
        prompt = f"Generate metadata for {input_data.get('topic', 'Python')}"
        response = provider.generate(prompt, agent_type="metadata")
        return {"metadata": json.loads(response.content)}
        
    return {
        "OutlineCreationAgent": mock_outline_agent,
        "IntroductionWriterAgent": mock_introduction_agent,
        "SectionWriterAgent": mock_section_agent,
        "ConclusionWriterAgent": mock_conclusion_agent,
        "CodeGenerationAgent": mock_code_agent,
        "KeywordExtractionAgent": mock_keyword_agent,
        "SEOMetadataAgent": mock_metadata_agent
    }


if __name__ == "__main__":
    # Test the mock provider
    provider = MockLLMProvider()
    
    test_prompts = [
        "Create an outline for a tutorial about machine learning",
        "Write an introduction about Python decorators",
        "Generate code example for async programming",
        "Extract keywords from this content",
        "Create metadata for a blog post"
    ]
    
    for prompt in test_prompts:
        response = provider.generate(prompt)
        print(f"\nPrompt: {prompt[:50]}...")
        print(f"Response Type: {provider._infer_response_type(prompt)}")
        print(f"Tokens: {response.tokens_used}")
        print(f"Content Preview: {response.content[:200]}...")
        
    print(f"\nMetrics: {provider.get_metrics()}")
