"""DOCGEN:LLM-FIRST@v1

Module overview
- Purpose: Defines unified contract system for agent communication, capabilities, and mesh interactions across the content generator system.
- Lifecycle: Imported during system startup to establish communication protocols.
- Collaborators: Used by src.core.event_bus, src.core.agent_base, src.mesh.negotiation, and orchestration modules.
- Key inputs: None (static definitions).
- Key outputs: Contract classes and enums for event handling, agent capabilities, bidding, and negotiation.

Public API Catalog
| Symbol | Kind | Defined in | Purpose | Inputs | Outputs | Raises | Notes |
|-------:|:-----|:-----------|:--------|:-------|:--------|:-------|:------|
| AgentEvent | class | contracts | Event for agent communication | event_type: str, data: Dict[str, Any], source_agent: str, correlation_id: str, timestamp: str, metadata: Dict[str, Any] | AgentEvent instance | None | Serializable via to_dict/from_dict |
| AgentContract | class | contracts | Contract defining agent capabilities and schemas | agent_id: str, capabilities: List[str], input_schema: Dict[str, Any], output_schema: Dict[str, Any], publishes: List[str], resource_profile: str, version: str | AgentContract instance | None | Defines agent interfaces |
| DataContract | class | contracts | Contract for data validation and extraction | input_schema: Dict[str, Any], output_schema: Dict[str, Any] | Dict[str, Any] | None | Thread-safe with threading.Lock |
| CapabilitySpec | class | contracts | Rich metadata for agent capabilities | name: str, input_requirements: List[str], output_guarantees: List[str], preconditions: Optional[Callable], cost_estimate: float, max_concurrency: int, confidence_threshold: float, retry_policy: Dict[str, Any] | CapabilitySpec instance | Exception | Evaluates preconditions; raises in evaluate_preconditions |
| Bid | class | contracts | Bid for capability execution | agent_id: str, capability: str, correlation_id: str, estimated_time: float, confidence: float, priority: int, current_load: int, max_capacity: int, health_score: float, success_rate: float, additional_info: Dict[str, Any], timestamp: datetime | Bid instance | None | Has score property (weighted calculation) |
| WorkSpec | class | contracts | Specification for work to be done | work_id: str, capability: str, correlation_id: str, input_data: Dict[str, Any], timeout: float, max_retries: int, priority: int, metadata: Dict[str, Any] | WorkSpec instance | None | Defines work requirements |
| BidResult | class | contracts | Result of bidding process | work_spec: WorkSpec, winning_bid: Optional[Bid], all_bids: List[Bid], selection_time: datetime, strategy_used: str | BidResult instance | None | Contains bidding outcomes |
| CapacityInfo | class | contracts | Information about agent capacity | agent_id: str, current_load: int, max_capacity: int, status: FlowControlStatus, capacity_level: CapacityLevel | CapacityInfo instance | None | Has utilization property (current_load/max_capacity) |
| FlowControlEvent | class | contracts | Event for flow control | event_type: str, agent_id: str, capacity_info: CapacityInfo, timestamp: datetime | FlowControlEvent instance | None | For overload/throttle management |
| CapabilityStatus | enum | contracts | Status of capability | None | CapabilityStatus | None | Values: AVAILABLE, BIDDING, EXECUTING, COMPLETED, FAILED |
| FlowControlStatus | enum | contracts | Status of flow control | None | FlowControlStatus | None | Values: AVAILABLE, OVERLOADED, THROTTLED, UNAVAILABLE |
| CapacityLevel | enum | contracts | Level of capacity | None | CapacityLevel | None | Values: LOW, MEDIUM, HIGH, CRITICAL |
| NegotiationStatus | enum | contracts | Status of negotiation | None | NegotiationStatus | None | Values: REQUESTED, BIDDING, CLAIMED, EXECUTING, COMPLETED, FAILED, CANCELLED |
| CapabilityRequest | class | contracts | Request for capability | request_id: str, requester_id: str, capability: str, correlation_id: str, input_data: Dict[str, Any], constraints: Dict[str, Any], urgency: str, deadline: Optional[datetime], dependencies: List[str], preferred_agents: List[str], excluded_agents: List[str], max_wait_time: float, timestamp: datetime | CapabilityRequest instance | None | For distributed work requests |
| NegotiationBid | class | contracts | Bid in negotiation | request_id: str, bid_id: str, agent_id: str, capability: str, correlation_id: str, estimated_time: float, confidence: float, priority: int, conditions: Dict[str, Any], dependencies_ready: bool, can_start_immediately: bool, alternative_capability: Optional[str], timestamp: datetime | NegotiationBid instance | None | Response to capability requests |
| CapabilityClaim | class | contracts | Claim for capability | request_id: str, claim_id: str, agent_id: str, capability: str, correlation_id: str, estimated_completion: datetime, conditions_accepted: Dict[str, Any], dependencies_tracking: List[str], timestamp: datetime | CapabilityClaim instance | None | Agent commitment to execute |
| DependencySpec | class | contracts | Specification of dependency | dependency_id: str, required_capability: str, required_output: str, correlation_id: str, timeout: float, is_critical: bool, fallback_strategy: Optional[str], timestamp: datetime | DependencySpec instance | None | For work dependencies |

Deeper dive
- Data flow: Static definitions loaded at import → classes instantiated by event_bus, agent_base, mesh modules → contracts used for validation, bidding, negotiation.
- Invariants & contracts: All contract classes must be serializable; enums must be stable across versions; thread-safety in DataContract.
- Preconditions: None.
- Postconditions: All classes and enums available for import.
- Error surface: Validation failures in DataContract methods; precondition evaluation exceptions in CapabilitySpec.
- Concurrency & async: Thread-safe DataContract with Lock; no async.
- I/O & performance: Lightweight dataclasses with minimal computation; thread locks in DataContract for concurrent access.
- Configuration map: None.
- External dependencies: typing, datetime, dataclasses, enum, logging, threading.
"""

from typing import Dict, List, Optional, Any, Callable
from datetime import datetime, timezone
from dataclasses import dataclass, field
from enum import Enum
import logging
import threading

logger = logging.getLogger(__name__)


# ============================================================================
# BASE EVENT MODEL (from v5_1)
# ============================================================================

@dataclass
class AgentEvent:
    """Event for agent communication.

    Args:
        event_type: Type of event (e.g., 'task_completed', 'error_occurred').
        data: Event payload data.
        source_agent: ID of the agent that generated the event.
        correlation_id: ID for correlating related events.
        timestamp: ISO format timestamp (auto-generated if not provided).
        metadata: Additional event metadata.

    Returns:
        AgentEvent instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        Event is properly initialized with timestamp.

    Side Effects:
        None.

    I/O schema:
        - Input shape: event_type (str), data (dict), source_agent (str), correlation_id (str), timestamp (str), metadata (dict).
        - Output shape: AgentEvent instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    event_type: str
    data: Dict[str, Any]
    source_agent: str
    correlation_id: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.

        Args:
            None.

        Returns:
            Dict[str, Any]: Dictionary representation of the event.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Dictionary contains all event fields.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: {'event_type': str, 'data': dict, 'source_agent': str, 'correlation_id': str, 'timestamp': str, 'metadata': dict}.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple dict creation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return {
            "event_type": self.event_type,
            "data": self.data,
            "source_agent": self.source_agent,
            "correlation_id": self.correlation_id,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentEvent':
        """Create from dictionary.

        Args:
            data: Dictionary containing event fields.

        Returns:
            AgentEvent: New AgentEvent instance.

        Raises:
            None.

        Preconditions:
            data must contain required fields.

        Postconditions:
            AgentEvent instance created from dict.

        Side Effects:
            None.

        I/O schema:
            - Input shape: {'event_type': str, 'data': dict, 'source_agent': str, 'correlation_id': str, 'timestamp': str, 'metadata': dict}.
            - Output shape: AgentEvent instance.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple class instantiation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return cls(**data)


# ============================================================================
# BASE CONTRACT MODELS (from v5_1)
# ============================================================================

@dataclass
class AgentContract:
    """Contract defining agent capabilities and schemas.

    Args:
        agent_id: Unique identifier for the agent.
        capabilities: List of capability names the agent provides.
        input_schema: JSON schema for input validation.
        output_schema: JSON schema for output validation.
        publishes: List of event types the agent publishes.
        resource_profile: Resource profile (e.g., 'cpu_light').
        version: Contract version string.

    Returns:
        AgentContract instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        Contract is properly initialized.

    Side Effects:
        None.

    I/O schema:
        - Input shape: agent_id (str), capabilities (list), input_schema (dict), output_schema (dict), publishes (list), resource_profile (str), version (str).
        - Output shape: AgentContract instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    agent_id: str
    capabilities: List[str]
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    publishes: List[str]
    resource_profile: str = "cpu_light"
    version: str = "1.0.0"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.

        Args:
            None.

        Returns:
            Dict[str, Any]: Dictionary representation.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Dictionary contains all contract fields.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: {'agent_id': str, 'capabilities': list, 'input_schema': dict, 'output_schema': dict, 'publishes': list, 'resource_profile': str, 'version': str}.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Simple dict creation.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return {
            "agent_id": self.agent_id,
            "capabilities": self.capabilities,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "publishes": self.publishes,
            "resource_profile": self.resource_profile,
            "version": self.version
        }


class DataContract:
    """Contract for data validation and extraction.

    Responsibilities
        - Validate input and output data against schemas.
        - Extract required data fields from full data dict.
        - Thread-safe operations with internal lock.

    Construction
        - Parameters: input_schema (Dict[str, Any]), output_schema (Dict[str, Any]).
        - Preconditions in __init__: None.
        - Attributes: input_schema, output_schema, _lock (threading.RLock).

    Public API
        - extract_required_data(full_data: Dict[str, Any]) -> Dict[str, Any]: Extract required fields.
        - validate_input(data: Dict[str, Any]) -> bool: Validate input data.
        - validate_output(data: Dict[str, Any]) -> bool: Validate output data.

    State & invariants
        - Attributes: input_schema (dict), output_schema (dict), _lock (RLock).
        - Invariants (validated in code): Thread-safe access to shared state.

    Contracts & checks
        - Preconditions: extract_required_data requires full_data to be dict.
        - Postconditions: extract_required_data returns dict with only required fields.

    Concurrency & I/O
        - Thread-safe with RLock for concurrent access.
        - No I/O operations.

    Error surface
        - Raises: None (methods return bool or dict).
    """

    def __init__(self, input_schema: Dict[str, Any], output_schema: Dict[str, Any]):
        """Initialize DataContract.

        Args:
            input_schema: Schema for input validation.
            output_schema: Schema for output validation.

        Returns:
            None.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            DataContract initialized with schemas and lock.

        Side Effects:
            None.

        I/O schema:
            - Input shape: input_schema (dict), output_schema (dict).
            - Output shape: None.

        Concurrency & performance:
            - Thread-safe: Lock created.
            - Performance: Lightweight initialization.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        self.input_schema = input_schema
        self.output_schema = output_schema
        self._lock = threading.Lock()

    def extract_required_data(self, full_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract required data fields.

        Args:
            full_data: Full data dictionary.

        Returns:
            Dict[str, Any]: Dictionary with only required fields.

        Raises:
            None.

        Preconditions:
            full_data must be a dictionary.

        Postconditions:
            Returns dict containing only required fields present in full_data.

        Side Effects:
            None.

        I/O schema:
            - Input shape: full_data (dict).
            - Output shape: dict with required fields.

        Concurrency & performance:
            - Thread-safe: Uses internal lock.
            - Performance: Linear scan of required fields.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        with self._lock:
            required_fields = self.input_schema.get("required", [])
            minimal = {}
            for f in required_fields:
                if f in full_data:
                    minimal[f] = full_data[f]
            return minimal

    def validate_input(self, data: Dict[str, Any]) -> bool:
        """Validate input data.

        Args:
            data: Data to validate.

        Returns:
            bool: True if valid, False otherwise.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns True if all required fields present.

        Side Effects:
            None.

        I/O schema:
            - Input shape: data (dict).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Linear check of required fields.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        required_fields = self.input_schema.get("required", [])
        return all(f in data for f in required_fields)

    def validate_output(self, data: Dict[str, Any]) -> bool:
        """Validate output data.

        Args:
            data: Data to validate.

        Returns:
            bool: True if valid, False otherwise.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns True if all required fields present.

        Side Effects:
            None.

        I/O schema:
            - Input shape: data (dict).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Linear check of required fields.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        required_fields = self.output_schema.get("required", [])
        return all(f in data for f in required_fields)


# ============================================================================
# MESH ENHANCEMENTS (from v5_2)
# ============================================================================

class CapabilityStatus(Enum):
    """Status of capability."""
    AVAILABLE = "available"
    BIDDING = "bidding"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"


class FlowControlStatus(Enum):
    """Status of flow control."""
    AVAILABLE = "available"
    OVERLOADED = "overloaded"
    THROTTLED = "throttled"
    UNAVAILABLE = "unavailable"


class CapacityLevel(Enum):
    """Level of capacity."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class CapabilitySpec:
    """Rich metadata for agent capabilities.

    Args:
        name: Name of the capability.
        input_requirements: List of required input conditions.
        output_guarantees: List of guaranteed outputs.
        preconditions: Optional callable to check preconditions.
        cost_estimate: Estimated cost (default 1.0).
        max_concurrency: Maximum concurrent executions (default 3).
        confidence_threshold: Minimum confidence required (default 0.7).
        retry_policy: Retry configuration dict.

    Returns:
        CapabilitySpec instance.

    Raises:
        Exception: In evaluate_preconditions if preconditions callable raises.

    Preconditions:
        None.

    Postconditions:
        CapabilitySpec initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: name (str), input_requirements (list), output_guarantees (list), preconditions (callable), cost_estimate (float), max_concurrency (int), confidence_threshold (float), retry_policy (dict).
        - Output shape: CapabilitySpec instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    name: str
    input_requirements: List[str]
    output_guarantees: List[str]
    preconditions: Optional[Callable] = None
    cost_estimate: float = 1.0
    max_concurrency: int = 3
    confidence_threshold: float = 0.7
    retry_policy: Dict[str, Any] = field(default_factory=lambda: {"max_retries": 3, "backoff": 2})

    def evaluate_preconditions(self, state: Dict[str, Any]) -> bool:
        """Evaluate preconditions.

        Args:
            state: Current state dictionary.

        Returns:
            bool: True if preconditions met.

        Raises:
            Exception: If preconditions callable raises.

        Preconditions:
            None.

        Postconditions:
            Returns bool result of precondition check.

        Side Effects:
            None.

        I/O schema:
            - Input shape: state (dict).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Depends on preconditions callable.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        if self.preconditions:
            try:
                return self.preconditions(state)
            except Exception:
                return False
        return True

    def check_inputs(self, state: Dict[str, Any]) -> bool:
        """Check input requirements.

        Args:
            state: Current state dictionary.

        Returns:
            bool: True if all requirements met.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns True if all input requirements satisfied.

        Side Effects:
            None.

        I/O schema:
            - Input shape: state (dict).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: Linear check of requirements.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        for requirement in self.input_requirements:
            if not self._evaluate_requirement(requirement, state):
                return False
        return True

    def _evaluate_requirement(self, requirement: str, state: Dict[str, Any]) -> bool:
        """Evaluate single requirement.

        Args:
            requirement: Requirement string.
            state: Current state dictionary.

        Returns:
            bool: True if requirement met.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns True if requirement logic satisfied.

        Side Effects:
            None.

        I/O schema:
            - Input shape: requirement (str), state (dict).
            - Output shape: bool.

        Concurrency & performance:
            - Thread-safe: No shared state.
            - Performance: String parsing and dict lookup.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        if " OR " in requirement:
            parts = requirement.strip("()").split(" OR ")
            return any(part.strip() in state for part in parts)
        if " AND " in requirement:
            parts = requirement.split(" AND ")
            return all(part.strip() in state for part in parts)
        return requirement in state


@dataclass
class Bid:
    """Bid for capability execution.

    Args:
        agent_id: ID of bidding agent.
        capability: Capability being bid on.
        correlation_id: Correlation ID.
        estimated_time: Estimated execution time.
        confidence: Confidence score (0-1).
        priority: Priority level.
        current_load: Current agent load.
        max_capacity: Maximum capacity.
        health_score: Health score (0-1).
        success_rate: Success rate (0-1).
        additional_info: Extra information dict.
        timestamp: Bid timestamp.

    Returns:
        Bid instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        Bid initialized with score property.

    Side Effects:
        None.

    I/O schema:
        - Input shape: agent_id (str), capability (str), correlation_id (str), estimated_time (float), confidence (float), priority (int), current_load (int), max_capacity (int), health_score (float), success_rate (float), additional_info (dict), timestamp (datetime).
        - Output shape: Bid instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    agent_id: str
    capability: str
    correlation_id: str
    estimated_time: float
    confidence: float
    priority: int
    current_load: int
    max_capacity: int
    health_score: float
    success_rate: float
    additional_info: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def score(self) -> float:
        """Calculate bid score.

        Args:
            None.

        Returns:
            float: Weighted score.

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns calculated score between 0-1.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: float.

        Concurrency & performance:
            - Thread-safe: Property access.
            - Performance: Simple arithmetic.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        load_factor = 1 - (self.current_load / max(self.max_capacity, 1))
        return (self.confidence * 0.4 +
                (self.priority / 10) * 0.2 +
                load_factor * 0.2 +
                self.health_score * 0.1 +
                self.success_rate * 0.1)


@dataclass
class WorkSpec:
    """Specification for work to be done.

    Args:
        work_id: Unique work identifier.
        capability: Required capability.
        correlation_id: Correlation ID.
        input_data: Input data dictionary.
        timeout: Timeout in seconds (default 30.0).
        max_retries: Maximum retries (default 3).
        priority: Priority level (default 5).
        metadata: Additional metadata dict.

    Returns:
        WorkSpec instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        WorkSpec initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: work_id (str), capability (str), correlation_id (str), input_data (dict), timeout (float), max_retries (int), priority (int), metadata (dict).
        - Output shape: WorkSpec instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    work_id: str
    capability: str
    correlation_id: str
    input_data: Dict[str, Any]
    timeout: float = 30.0
    max_retries: int = 3
    priority: int = 5
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BidResult:
    """Result of bidding process.

    Args:
        work_spec: Original work specification.
        winning_bid: Winning bid if any.
        all_bids: List of all bids received.
        selection_time: Time of selection.
        strategy_used: Selection strategy name.

    Returns:
        BidResult instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        BidResult initialized.

    Side Effects:
        None.

    I/O schema:
        - Input shape: work_spec (WorkSpec), winning_bid (Bid), all_bids (list), selection_time (datetime), strategy_used (str).
        - Output shape: BidResult instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    work_spec: WorkSpec
    winning_bid: Optional[Bid]
    all_bids: List[Bid]
    selection_time: datetime
    strategy_used: str


@dataclass
class CapacityInfo:
    """Information about agent capacity.

    Args:
        agent_id: Agent identifier.
        current_load: Current load level.
        max_capacity: Maximum capacity.
        status: Flow control status.
        capacity_level: Capacity level.

    Returns:
        CapacityInfo instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        CapacityInfo initialized with utilization property.

    Side Effects:
        None.

    I/O schema:
        - Input shape: agent_id (str), current_load (int), max_capacity (int), status (FlowControlStatus), capacity_level (CapacityLevel).
        - Output shape: CapacityInfo instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    agent_id: str
    current_load: int
    max_capacity: int
    status: FlowControlStatus
    capacity_level: CapacityLevel

    @property
    def utilization(self) -> float:
        """Calculate utilization ratio.

        Args:
            None.

        Returns:
            float: Utilization ratio (0-1).

        Raises:
            None.

        Preconditions:
            None.

        Postconditions:
            Returns current_load / max_capacity.

        Side Effects:
            None.

        I/O schema:
            - Input shape: None.
            - Output shape: float.

        Concurrency & performance:
            - Thread-safe: Property access.
            - Performance: Simple division.

        Configuration:
            - None.

        External interactions:
            - None.
        """
        return self.current_load / max(self.max_capacity, 1)


@dataclass
class FlowControlEvent:
    """Event for flow control.

    Args:
        event_type: Type of flow control event.
        agent_id: Affected agent ID.
        capacity_info: Current capacity information.
        timestamp: Event timestamp.

    Returns:
        FlowControlEvent instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        FlowControlEvent initialized.

    Side Effects:
        None.

    I/O schema:
        - Input shape: event_type (str), agent_id (str), capacity_info (CapacityInfo), timestamp (datetime).
        - Output shape: FlowControlEvent instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    event_type: str  # "overload", "throttle", "resume"
    agent_id: str
    capacity_info: CapacityInfo
    timestamp: datetime = field(default_factory=datetime.now)


# ============================================================================
# NEGOTIATION CONTRACTS (from v5_2)
# ============================================================================

class NegotiationStatus(Enum):
    """Status of capability negotiation."""
    REQUESTED = "requested"
    BIDDING = "bidding"
    CLAIMED = "claimed"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class CapabilityRequest:
    """Request for a capability from peer agents.

    Args:
        request_id: Unique request identifier.
        requester_id: ID of requesting agent.
        capability: Required capability name.
        correlation_id: Correlation ID.
        input_data: Input data for capability.
        constraints: Additional constraints dict.
        urgency: Urgency level (default 'normal').
        deadline: Optional deadline datetime.
        dependencies: List of dependency IDs.
        preferred_agents: List of preferred agent IDs.
        excluded_agents: List of excluded agent IDs.
        max_wait_time: Maximum wait time in seconds.
        timestamp: Request timestamp.

    Returns:
        CapabilityRequest instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        CapabilityRequest initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: request_id (str), requester_id (str), capability (str), correlation_id (str), input_data (dict), constraints (dict), urgency (str), deadline (datetime), dependencies (list), preferred_agents (list), excluded_agents (list), max_wait_time (float), timestamp (datetime).
        - Output shape: CapabilityRequest instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    request_id: str
    requester_id: str
    capability: str
    correlation_id: str
    input_data: Dict[str, Any]
    constraints: Dict[str, Any] = field(default_factory=dict)
    urgency: str = "normal"
    deadline: Optional[datetime] = None
    dependencies: List[str] = field(default_factory=list)
    preferred_agents: List[str] = field(default_factory=list)
    excluded_agents: List[str] = field(default_factory=list)
    max_wait_time: float = 30.0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class NegotiationBid:
    """Bid response to a capability request.

    Args:
        request_id: ID of request being bid on.
        bid_id: Unique bid identifier.
        agent_id: ID of bidding agent.
        capability: Capability being bid on.
        correlation_id: Correlation ID.
        estimated_time: Estimated execution time.
        confidence: Confidence score.
        priority: Priority level.
        conditions: Additional conditions dict.
        dependencies_ready: Whether dependencies are ready.
        can_start_immediately: Whether can start immediately.
        alternative_capability: Optional alternative capability.
        timestamp: Bid timestamp.

    Returns:
        NegotiationBid instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        NegotiationBid initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: request_id (str), bid_id (str), agent_id (str), capability (str), correlation_id (str), estimated_time (float), confidence (float), priority (int), conditions (dict), dependencies_ready (bool), can_start_immediately (bool), alternative_capability (str), timestamp (datetime).
        - Output shape: NegotiationBid instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    request_id: str
    bid_id: str
    agent_id: str
    capability: str
    correlation_id: str
    estimated_time: float
    confidence: float
    priority: int
    conditions: Dict[str, Any] = field(default_factory=dict)
    dependencies_ready: bool = False
    can_start_immediately: bool = True
    alternative_capability: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class CapabilityClaim:
    """Claim that an agent will execute a capability.

    Args:
        request_id: ID of request being claimed.
        claim_id: Unique claim identifier.
        agent_id: ID of claiming agent.
        capability: Capability being claimed.
        correlation_id: Correlation ID.
        estimated_completion: Estimated completion datetime.
        conditions_accepted: Accepted conditions dict.
        dependencies_tracking: Dependencies tracking list.
        timestamp: Claim timestamp.

    Returns:
        CapabilityClaim instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        CapabilityClaim initialized.

    Side Effects:
        None.

    I/O schema:
        - Input shape: request_id (str), claim_id (str), agent_id (str), capability (str), correlation_id (str), estimated_completion (datetime), conditions_accepted (dict), dependencies_tracking (list), timestamp (datetime).
        - Output shape: CapabilityClaim instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    request_id: str
    claim_id: str
    agent_id: str
    capability: str
    correlation_id: str
    estimated_completion: datetime
    conditions_accepted: Dict[str, Any] = field(default_factory=dict)
    dependencies_tracking: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class DependencySpec:
    """Specification of what an agent depends on.

    Args:
        dependency_id: Unique dependency identifier.
        required_capability: Required capability name.
        required_output: Required output name.
        correlation_id: Correlation ID.
        timeout: Timeout in seconds (default 60.0).
        is_critical: Whether dependency is critical (default True).
        fallback_strategy: Optional fallback strategy.
        timestamp: Specification timestamp.

    Returns:
        DependencySpec instance.

    Raises:
        None.

    Preconditions:
        None.

    Postconditions:
        DependencySpec initialized with defaults.

    Side Effects:
        None.

    I/O schema:
        - Input shape: dependency_id (str), required_capability (str), required_output (str), correlation_id (str), timeout (float), is_critical (bool), fallback_strategy (str), timestamp (datetime).
        - Output shape: DependencySpec instance.

    Concurrency & performance:
        - Thread-safe: No shared state.
        - Performance: Lightweight dataclass.

    Configuration:
        - None.

    External interactions:
        - None.
    """
    dependency_id: str
    required_capability: str
    required_output: str
    correlation_id: str
    timeout: float = 60.0
    is_critical: bool = True
    fallback_strategy: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


__all__ = [
    # Base
    'AgentEvent',
    'AgentContract',
    'DataContract',

    # Mesh Enhancements
    'CapabilityStatus',
    'FlowControlStatus',
    'CapacityLevel',
    'CapabilitySpec',
    'Bid',
    'WorkSpec',
    'BidResult',
    'CapacityInfo',
    'FlowControlEvent',
    
    # Negotiation
    'NegotiationStatus',
    'CapabilityRequest',
    'NegotiationBid',
    'CapabilityClaim',
    'DependencySpec',
]
# DOCGEN:LLM-FIRST@v4