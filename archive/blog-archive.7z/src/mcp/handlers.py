"""
MCP Endpoint Handlers for UCOP

Implements handler functions for all MCP protocol endpoints:
- workflow.execute
- workflow.status
- workflow.checkpoint.list
- workflow.checkpoint.restore
- agent.invoke
- agent.list
- realtime.subscribe
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
import json

from src.mcp.protocol import (
    MCPRequest,
    MCPResponse,
    MCPError,
    ResourceType,
    ResourceStatus,
    JobResource,
    AgentResource,
    WorkflowResource,
    AgentCapability,
    create_resource_uri,
)

logger = logging.getLogger(__name__)

# Global executor reference (set by initialization)
_executor = None
_job_engine = None
_agent_registry = None


def set_dependencies(executor, job_engine=None, agent_registry=None):
    """Set handler dependencies.
    
    Args:
        executor: Unified execution engine
        job_engine: Job execution engine
        agent_registry: Agent registry for agent discovery
    """
    global _executor, _job_engine, _agent_registry
    _executor = executor
    _job_engine = job_engine
    _agent_registry = agent_registry
    logger.info("MCP handlers initialized with dependencies")


def get_executor():
    """Get executor instance."""
    if _executor is None:
        raise RuntimeError("Executor not initialized. Call set_dependencies first.")
    return _executor


def get_job_engine():
    """Get job engine instance."""
    if _job_engine is None:
        # Fallback to executor's job engine
        executor = get_executor()
        if hasattr(executor, 'job_engine'):
            return executor.job_engine
        raise RuntimeError("Job engine not available")
    return _job_engine


def get_agent_registry():
    """Get agent registry instance."""
    if _agent_registry is None:
        logger.warning("Agent registry not available, using fallback")
        return None
    return _agent_registry


# ============================================================================
# Workflow Handlers
# ============================================================================

async def handle_workflow_execute(params: Dict[str, Any]) -> Dict[str, Any]:
    """Execute a workflow.
    
    Args:
        params: {
            "workflow_id": str,
            "inputs": dict,
            "checkpoint_enabled": bool (optional)
        }
    
    Returns:
        Job resource with execution details
        
    Example:
        >>> params = {
        ...     "workflow_id": "fast-draft",
        ...     "inputs": {"topic": "AI trends", "output_dir": "./output"}
        ... }
        >>> result = await handle_workflow_execute(params)
    """
    logger.info(f"MCP: workflow.execute called with params: {params}")
    
    workflow_id = params.get("workflow_id")
    inputs = params.get("inputs", {})
    checkpoint_enabled = params.get("checkpoint_enabled", True)
    
    if not workflow_id:
        raise ValueError("workflow_id is required")
    
    # Get job engine
    job_engine = get_job_engine()
    
    # Create job
    job_id = f"job_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
    
    # Submit job to engine
    try:
        # Create job configuration
        from src.engine.executor import JobConfig
        
        job_config = JobConfig(
            workflow=workflow_id,
            input=inputs.get("topic", ""),
            params={
                **inputs,
                "checkpoint_enabled": checkpoint_enabled
            }
        )
        
        # Execute the job
        result = get_executor().run_job(job_config)
        
        # Return job resource
        return {
            "job_id": result.job_id,
            "workflow_id": workflow_id,
            "status": result.status,
            "started_at": result.started_at,
            "uri": create_resource_uri(ResourceType.JOB, result.job_id)
        }
        
    except Exception as e:
        logger.error(f"Failed to execute workflow {workflow_id}: {e}", exc_info=True)
        raise


async def handle_workflow_status(params: Dict[str, Any]) -> Dict[str, Any]:
    """Get workflow execution status.
    
    Args:
        params: {
            "job_id": str
        }
    
    Returns:
        Job status with pipeline details
        
    Example:
        >>> params = {"job_id": "job_20250111_120000_001"}
        >>> result = await handle_workflow_status(params)
    """
    logger.info(f"MCP: workflow.status called with params: {params}")
    
    job_id = params.get("job_id")
    if not job_id:
        raise ValueError("job_id is required")
    
    # Get job engine
    job_engine = get_job_engine()
    
    # Get job details
    if hasattr(job_engine, '_jobs'):
        job = job_engine._jobs.get(job_id)
        if not job:
            raise ValueError(f"Job not found: {job_id}")
        
        # Convert job to dict
        job_dict = job.to_dict() if hasattr(job, 'to_dict') else {
            "id": job_id,
            "status": getattr(job, 'status', 'unknown'),
            "workflow_name": getattr(job, 'workflow_name', 'unknown'),
        }
        
        return {
            "job_id": job_id,
            "status": job_dict.get("status", "unknown"),
            "workflow_name": job_dict.get("workflow_name"),
            "progress": job_dict.get("progress", 0),
            "current_step": job_dict.get("current_step"),
            "pipeline": job_dict.get("pipeline", []),
            "started_at": job_dict.get("started_at"),
            "completed_at": job_dict.get("completed_at"),
            "error": job_dict.get("error"),
            "uri": create_resource_uri(ResourceType.JOB, job_id)
        }
    
    raise ValueError("Job engine not properly configured")


async def handle_workflow_checkpoint_list(params: Dict[str, Any]) -> Dict[str, Any]:
    """List available checkpoints for a job.
    
    Args:
        params: {
            "job_id": str
        }
    
    Returns:
        List of checkpoint resources
        
    Example:
        >>> params = {"job_id": "job_20250111_120000_001"}
        >>> result = await handle_workflow_checkpoint_list(params)
    """
    logger.info(f"MCP: workflow.checkpoint.list called with params: {params}")
    
    job_id = params.get("job_id")
    if not job_id:
        raise ValueError("job_id is required")
    
    # Look for checkpoints directory
    checkpoint_dir = Path(f"./data/jobs/{job_id}/checkpoints")
    
    if not checkpoint_dir.exists():
        return {"checkpoints": []}
    
    checkpoints = []
    for checkpoint_file in checkpoint_dir.glob("*.json"):
        try:
            with open(checkpoint_file, 'r') as f:
                checkpoint_data = json.load(f)
            
            checkpoints.append({
                "id": checkpoint_file.stem,
                "job_id": job_id,
                "step_id": checkpoint_data.get("step_id"),
                "timestamp": checkpoint_data.get("timestamp"),
                "status": checkpoint_data.get("status"),
                "uri": create_resource_uri(ResourceType.CHECKPOINT, checkpoint_file.stem)
            })
        except Exception as e:
            logger.error(f"Failed to read checkpoint {checkpoint_file}: {e}")
            continue
    
    return {
        "job_id": job_id,
        "checkpoints": sorted(checkpoints, key=lambda x: x.get("timestamp", ""), reverse=True)
    }


async def handle_workflow_checkpoint_restore(params: Dict[str, Any]) -> Dict[str, Any]:
    """Restore workflow from checkpoint.
    
    Args:
        params: {
            "job_id": str,
            "checkpoint_id": str
        }
    
    Returns:
        Restored job resource
        
    Example:
        >>> params = {
        ...     "job_id": "job_20250111_120000_001",
        ...     "checkpoint_id": "checkpoint_step_5"
        ... }
        >>> result = await handle_workflow_checkpoint_restore(params)
    """
    logger.info(f"MCP: workflow.checkpoint.restore called with params: {params}")
    
    job_id = params.get("job_id")
    checkpoint_id = params.get("checkpoint_id")
    
    if not job_id or not checkpoint_id:
        raise ValueError("job_id and checkpoint_id are required")
    
    # Load checkpoint
    checkpoint_file = Path(f"./data/jobs/{job_id}/checkpoints/{checkpoint_id}.json")
    
    if not checkpoint_file.exists():
        raise ValueError(f"Checkpoint not found: {checkpoint_id}")
    
    try:
        with open(checkpoint_file, 'r') as f:
            checkpoint_data = json.load(f)
        
        # Get job engine
        job_engine = get_job_engine()
        
        # Restore job state from checkpoint
        # This is a placeholder - actual restoration depends on job engine implementation
        logger.info(f"Restoring job {job_id} from checkpoint {checkpoint_id}")
        
        return {
            "job_id": job_id,
            "checkpoint_id": checkpoint_id,
            "status": "restored",
            "restored_at": datetime.now().isoformat(),
            "checkpoint_step": checkpoint_data.get("step_id"),
            "message": "Job restored from checkpoint successfully"
        }
        
    except Exception as e:
        logger.error(f"Failed to restore checkpoint: {e}", exc_info=True)
        raise


# ============================================================================
# Agent Handlers
# ============================================================================

async def handle_agent_invoke(params: Dict[str, Any]) -> Dict[str, Any]:
    """Invoke an agent directly.
    
    Args:
        params: {
            "agent_id": str,
            "input": dict,
            "context": dict (optional)
        }
    
    Returns:
        Agent execution result
        
    Example:
        >>> params = {
        ...     "agent_id": "topic_identification",
        ...     "input": {"kb_path": "./data/kb"}
        ... }
        >>> result = await handle_agent_invoke(params)
    """
    logger.info(f"MCP: agent.invoke called with params: {params}")
    
    agent_id = params.get("agent_id")
    agent_input = params.get("input", {})
    context = params.get("context", {})
    
    if not agent_id:
        raise ValueError("agent_id is required")
    
    # Get executor
    executor = get_executor()
    
    try:
        # Get agent instance from registry or executor
        agent_registry = get_agent_registry()
        
        if agent_registry and hasattr(agent_registry, 'get_agent'):
            agent = agent_registry.get_agent(agent_id)
        elif hasattr(executor, 'agents'):
            # Fallback: get from executor's agent list
            agent = next((a for a in executor.agents if a.id == agent_id), None)
            if not agent:
                raise ValueError(f"Agent not found: {agent_id}")
        else:
            raise ValueError(f"Cannot invoke agent: {agent_id} (registry not available)")
        
        # Execute agent
        logger.info(f"Invoking agent {agent_id} with input: {agent_input}")
        
        result = await agent.execute(agent_input, context=context)
        
        return {
            "agent_id": agent_id,
            "status": "completed",
            "output": result,
            "executed_at": datetime.now().isoformat(),
            "uri": create_resource_uri(ResourceType.AGENT, agent_id)
        }
        
    except Exception as e:
        logger.error(f"Failed to invoke agent {agent_id}: {e}", exc_info=True)
        return {
            "agent_id": agent_id,
            "status": "failed",
            "error": str(e),
            "executed_at": datetime.now().isoformat()
        }


async def handle_agent_list(params: Dict[str, Any]) -> Dict[str, Any]:
    """List all available agents.
    
    Args:
        params: {
            "category": str (optional) - filter by category
        }
    
    Returns:
        List of agent resources
        
    Example:
        >>> params = {"category": "research"}
        >>> result = await handle_agent_list(params)
    """
    logger.info(f"MCP: agent.list called with params: {params}")
    
    category_filter = params.get("category")
    
    # Get agents from registry or discover from filesystem
    agents = []
    
    # Try to get from agent registry first
    agent_registry = get_agent_registry()
    if agent_registry and hasattr(agent_registry, 'list_agents'):
        agents = agent_registry.list_agents()
    else:
        # Fallback: discover from src/agents directory
        agents_dir = Path(__file__).parent.parent / "agents"
        
        agent_categories = {
            "research": ["topic_identification", "kb_search", "api_search", "blog_search", "duplication_check"],
            "ingestion": ["kb_ingestion", "api_ingestion", "blog_ingestion", "docs_ingestion", "tutorial_ingestion"],
            "content": ["outline_creation", "introduction_writer", "section_writer", "conclusion_writer", 
                       "supplementary_content", "content_assembly"],
            "seo": ["keyword_extraction", "keyword_injection", "seo_metadata"],
            "code": ["code_extraction", "code_generation", "code_validation", "code_splitting", "license_injection"],
            "publishing": ["file_writer", "frontmatter", "gist_readme", "gist_upload", "link_validation"],
            "support": ["model_selection", "error_recovery"]
        }
        
        for cat, agent_names in agent_categories.items():
            if category_filter and cat != category_filter:
                continue
                
            category_dir = agents_dir / cat
            if not category_dir.exists():
                continue
                
            for agent_name in agent_names:
                agent_file = category_dir / f"{agent_name}.py"
                if agent_file.exists():
                    agents.append({
                        "id": agent_name,
                        "name": agent_name.replace("_", " ").title(),
                        "type": cat,
                        "category": cat,
                        "status": "idle",
                        "uri": create_resource_uri(ResourceType.AGENT, agent_name),
                        "capabilities": []
                    })
    
    return {
        "agents": agents,
        "total": len(agents),
        "category_filter": category_filter
    }


# ============================================================================
# Real-time Handlers
# ============================================================================

async def handle_realtime_subscribe(params: Dict[str, Any]) -> Dict[str, Any]:
    """Subscribe to real-time updates.
    
    Args:
        params: {
            "job_id": str,
            "event_types": list[str] (optional)
        }
    
    Returns:
        Subscription details and WebSocket connection info
        
    Example:
        >>> params = {
        ...     "job_id": "job_20250111_120000_001",
        ...     "event_types": ["status", "progress", "log"]
        ... }
        >>> result = await handle_realtime_subscribe(params)
    """
    logger.info(f"MCP: realtime.subscribe called with params: {params}")
    
    job_id = params.get("job_id")
    event_types = params.get("event_types", ["status", "progress", "log", "error"])
    
    if not job_id:
        raise ValueError("job_id is required")
    
    # Return WebSocket connection details
    # The actual WebSocket connection is handled separately
    return {
        "job_id": job_id,
        "subscription_id": f"sub_{job_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "event_types": event_types,
        "websocket_url": f"ws://localhost:8000/ws/mesh?job={job_id}",
        "status": "ready",
        "message": "Connect to the WebSocket URL to receive real-time updates"
    }


# ============================================================================
# Request Router
# ============================================================================

async def route_request(request: MCPRequest) -> MCPResponse:
    """Route MCP request to appropriate handler.
    
    Args:
        request: MCP request
        
    Returns:
        MCP response
    """
    logger.info(f"Routing MCP request: {request.method}")
    
    try:
        # Route to handler based on method
        if request.method == "workflow.execute":
            result = await handle_workflow_execute(request.params)
        elif request.method == "workflow.status":
            result = await handle_workflow_status(request.params)
        elif request.method == "workflow.checkpoint.list":
            result = await handle_workflow_checkpoint_list(request.params)
        elif request.method == "workflow.checkpoint.restore":
            result = await handle_workflow_checkpoint_restore(request.params)
        elif request.method == "agent.invoke":
            result = await handle_agent_invoke(request.params)
        elif request.method == "agent.list":
            result = await handle_agent_list(request.params)
        elif request.method == "realtime.subscribe":
            result = await handle_realtime_subscribe(request.params)
        else:
            # Method not found
            return MCPResponse(
                error={
                    "code": -32601,
                    "message": f"Method not found: {request.method}"
                },
                id=request.id
            )
        
        # Return successful response
        return MCPResponse(result=result, id=request.id)
        
    except ValueError as e:
        # Invalid parameters
        logger.error(f"Invalid parameters for {request.method}: {e}")
        return MCPResponse(
            error={
                "code": -32602,
                "message": f"Invalid params: {str(e)}"
            },
            id=request.id
        )
    except Exception as e:
        # Internal error
        logger.error(f"Internal error processing {request.method}: {e}", exc_info=True)
        return MCPResponse(
            error={
                "code": -32603,
                "message": f"Internal error: {str(e)}"
            },
            id=request.id
        )
# DOCGEN:LLM-FIRST@v4