"""Pydantic models for FastAPI web application."""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
from pydantic import BaseModel, Field


class JobCreate(BaseModel):
    """Request model for creating a job."""
    workflow_id: str = Field(..., description="Workflow identifier")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Job input parameters")


class RunSpec(BaseModel):
    """Request model for /api/generate endpoint with full run specification."""
    topic: str = Field(..., description="Topic for content generation")
    template: str = Field(default="default_blog", description="Template to use")
    workflow: Optional[str] = Field(default=None, description="Workflow ID override")
    config_overrides: Optional[Dict[str, Any]] = Field(default=None, description="Config overrides")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")


class BatchJobCreate(BaseModel):
    """Request model for batch job creation."""
    workflow_id: str = Field(..., description="Workflow identifier for all jobs")
    jobs: List[Dict[str, Any]] = Field(..., description="List of job input specifications")
    batch_name: Optional[str] = Field(default=None, description="Optional batch identifier")


class JobResponse(BaseModel):
    """Response model for job creation."""
    job_id: str = Field(..., description="Unique job identifier")
    status: str = Field(..., description="Initial job status")
    message: Optional[str] = Field(default=None, description="Additional information")


class BatchJobResponse(BaseModel):
    """Response model for batch job creation."""
    batch_id: str = Field(..., description="Batch identifier")
    job_ids: List[str] = Field(..., description="List of created job IDs")
    status: str = Field(..., description="Batch status")
    message: Optional[str] = Field(default=None, description="Additional information")


class JobStatus(BaseModel):
    """Response model for job status."""
    job_id: str
    status: str
    progress: Optional[float] = None
    current_stage: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None


class JobList(BaseModel):
    """Response model for job list."""
    jobs: List[JobStatus] = Field(default_factory=list)
    total: int = Field(default=0)


class JobControl(BaseModel):
    """Response model for job control actions (pause/resume/cancel)."""
    job_id: str
    action: str
    status: str
    message: Optional[str] = None


class AgentLogEntry(BaseModel):
    """Model for a single agent log entry."""
    timestamp: datetime
    level: str
    agent_name: str
    message: str
    metadata: Optional[Dict[str, Any]] = None


class AgentLogs(BaseModel):
    """Response model for agent logs."""
    job_id: Optional[str] = None
    agent_name: str
    logs: List[AgentLogEntry] = Field(default_factory=list)
    total: int = Field(default=0)


class WorkflowInfo(BaseModel):
    """Response model for workflow information."""
    workflow_id: str
    name: str
    description: Optional[str] = None
    agents: List[str] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = None


class WorkflowList(BaseModel):
    """Response model for workflow list."""
    workflows: List[WorkflowInfo] = Field(default_factory=list)
    total: int = Field(default=0)


class AgentInfo(BaseModel):
    """Response model for agent information."""
    agent_id: str
    name: str
    type: str
    description: Optional[str] = None
    status: str = Field(default="available")
    capabilities: List[str] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = None


class AgentList(BaseModel):
    """Response model for agent list."""
    agents: List[AgentInfo] = Field(default_factory=list)
    total: int = Field(default=0)


class SystemHealth(BaseModel):
    """Response model for system health check."""
    status: str = Field(..., description="Overall system status")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    components: Dict[str, Dict[str, Any]] = Field(default_factory=dict, description="Component health status")
    version: Optional[str] = None
    uptime: Optional[float] = None


class ErrorResponse(BaseModel):
    """Response model for error cases."""
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None


# ============================================================================
# Visualization Models
# ============================================================================

class WorkflowListResponse(BaseModel):
    """Response model for workflow list."""
    workflows: List[Dict[str, Any]] = Field(default_factory=list)
    total: int = Field(default=0)


class WorkflowGraphResponse(BaseModel):
    """Response model for workflow graph data."""
    profile_name: str
    name: str
    description: str = Field(default="")
    nodes: List[Dict[str, Any]] = Field(default_factory=list)
    edges: List[Dict[str, Any]] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WorkflowRenderResponse(BaseModel):
    """Response model for rendered workflow."""
    workflow_id: str
    format: str
    content: Dict[str, Any]


class AgentMetricsResponse(BaseModel):
    """Response model for agent metrics."""
    agent_id: str
    total_executions: int = 0
    successful_executions: int = 0
    failed_executions: int = 0
    success_rate: float = 0.0
    avg_duration_ms: float = 0.0
    last_execution: Optional[str] = None
    current_status: str = "pending"
    recent_executions: List[Dict[str, Any]] = Field(default_factory=list)


class AgentListMetricsResponse(BaseModel):
    """Response model for list of agent metrics."""
    agents: List[Dict[str, Any]] = Field(default_factory=list)
    total: int = Field(default=0)


class SystemMetricsResponse(BaseModel):
    """Response model for system metrics."""
    cpu_percent: float
    memory_percent: float
    memory_available_mb: float
    memory_total_mb: float
    active_jobs: int
    total_agents: int
    uptime_seconds: float
    timestamp: datetime


class JobMetricsResponse(BaseModel):
    """Response model for job execution metrics."""
    job_id: str
    status: str
    total_agents: int = 0
    completed_agents: int = 0
    failed_agents: int = 0
    total_flows: int = 0
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_seconds: float = 0.0


# ============================================================================
# Debug Models
# ============================================================================

class BreakpointCreateRequest(BaseModel):
    """Request model for creating a breakpoint."""
    session_id: Optional[str] = None
    correlation_id: Optional[str] = None
    agent_id: str
    event_type: str
    condition: Optional[str] = None
    max_hits: Optional[int] = None


class BreakpointResponse(BaseModel):
    """Response model for breakpoint."""
    breakpoint_id: str
    session_id: str
    agent_id: str
    event_type: str
    condition: Optional[str] = None
    enabled: bool = True
    hit_count: int = 0
    max_hits: Optional[int] = None
    created_at: datetime


class BreakpointListResponse(BaseModel):
    """Response model for list of breakpoints."""
    breakpoints: List[Dict[str, Any]] = Field(default_factory=list)
    total: int = Field(default=0)


class DebugStepRequest(BaseModel):
    """Request model for debug step operation."""
    session_id: str
    action: str = Field(default="step", description="Step action: 'step', 'continue', 'step_over'")


class DebugStepResponse(BaseModel):
    """Response model for debug step operation."""
    session_id: str
    status: str
    current_step: Optional[str] = None
    message: str


class DebugStateResponse(BaseModel):
    """Response model for debug state."""
    job_id: str
    session_id: str
    status: str
    current_step: Optional[str] = None
    step_history: List[Dict[str, Any]] = Field(default_factory=list)
    variables: Dict[str, Any] = Field(default_factory=dict)
    breakpoints: List[Dict[str, Any]] = Field(default_factory=list)
