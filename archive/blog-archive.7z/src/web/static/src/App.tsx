import React, { useState } from 'react';
import WorkflowEditor from './components/WorkflowEditor';
import AgentPalette from './components/AgentPalette';
import JobMonitor from './components/JobMonitor';
import { useAgents, useJobs, useWorkflows } from './hooks/useAPI';
import { useWorkflowStore } from './utils/workflowStore';
import { Agent } from './types';

const App: React.FC = () => {
  const { agents, loading: agentsLoading } = useAgents();
  const { jobs, createJob, pauseJob, resumeJob, cancelJob } = useJobs();
  const { saveWorkflow } = useWorkflows();
  const { getWorkflowData, isDirty, setDirty } = useWorkflowStore();
  
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [draggedAgent, setDraggedAgent] = useState<Agent | null>(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [workflowName, setWorkflowName] = useState('');

  const handleDragStart = (agent: Agent) => {
    setDraggedAgent(agent);
  };

  const handleSave = async () => {
    setShowSaveDialog(true);
  };

  const handleSaveConfirm = async () => {
    if (!workflowName.trim()) {
      alert('Please enter a workflow name');
      return;
    }

    try {
      const workflow = getWorkflowData();
      workflow.name = workflowName;
      await saveWorkflow(workflow);
      setDirty(false);
      setShowSaveDialog(false);
      alert('Workflow saved successfully!');
    } catch (error) {
      console.error('Failed to save workflow:', error);
      alert('Failed to save workflow');
    }
  };

  const handleRun = async () => {
    const workflow = getWorkflowData();
    
    if (workflow.nodes.length === 0) {
      alert('Please add some nodes to the workflow first');
      return;
    }

    try {
      const job = await createJob(
        workflow.name || 'untitled',
        { topic: 'Test run' },
        {}
      );
      setActiveJobId(job.job_id);
      alert(`Job started: ${job.job_id}`);
    } catch (error) {
      console.error('Failed to start job:', error);
      alert('Failed to start job');
    }
  };

  const handlePauseJob = async (jobId: string) => {
    try {
      await pauseJob(jobId);
    } catch (error) {
      console.error('Failed to pause job:', error);
      alert('Failed to pause job');
    }
  };

  const handleResumeJob = async (jobId: string) => {
    try {
      await resumeJob(jobId);
    } catch (error) {
      console.error('Failed to resume job:', error);
      alert('Failed to resume job');
    }
  };

  const handleCancelJob = async (jobId: string) => {
    try {
      await cancelJob(jobId);
    } catch (error) {
      console.error('Failed to cancel job:', error);
      alert('Failed to cancel job');
    }
  };

  if (agentsLoading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading agents...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">W</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                Workflow Editor
              </h1>
              <p className="text-sm text-gray-600">
                Visual workflow builder for AI agents
              </p>
            </div>
          </div>
          
          {isDirty && (
            <div className="flex items-center gap-2 text-sm text-amber-600">
              <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>
              Unsaved changes
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Agent Palette */}
        <div className="w-80 border-r border-gray-200 bg-white">
          <AgentPalette agents={agents} onDragStart={handleDragStart} />
        </div>

        {/* Workflow Editor */}
        <div className="flex-1">
          <WorkflowEditor
            agents={agents}
            onSave={handleSave}
            onRun={handleRun}
            activeNodeId={
              jobs.find((j) => j.job_id === activeJobId)?.current_node
            }
          />
        </div>

        {/* Job Monitor */}
        <div className="w-96 border-l border-gray-200 bg-white">
          <JobMonitor
            jobs={jobs}
            onPauseJob={handlePauseJob}
            onResumeJob={handleResumeJob}
            onCancelJob={handleCancelJob}
          />
        </div>
      </div>

      {/* Save Dialog */}
      {showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Save Workflow
            </h2>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Workflow Name
              </label>
              <input
                type="text"
                value={workflowName}
                onChange={(e) => setWorkflowName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="Enter workflow name"
                autoFocus
              />
            </div>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowSaveDialog(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveConfirm}
                className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
