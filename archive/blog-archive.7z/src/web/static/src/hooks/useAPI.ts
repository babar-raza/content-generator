import { useState, useEffect, useCallback } from 'react';
import { Agent, Workflow, Job, JobStatus, WebSocketEvent } from '@/types';
import apiClient from '@/api/client';
import { wsManager } from '@/websocket/connection';

export function useAgents() {
  const [agents, setAgents] = useState<Record<string, Agent>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchAgents = async () => {
      try {
        setLoading(true);
        const data = await apiClient.getAgentConfigs();
        setAgents(data.agents || {});
        setError(null);
      } catch (err) {
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    fetchAgents();
  }, []);

  return { agents, loading, error };
}

export function useWorkflows() {
  const [workflows, setWorkflows] = useState<Record<string, Workflow>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchWorkflows = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiClient.getWorkflowConfigs();
      setWorkflows(data.workflows || {});
      setError(null);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWorkflows();
  }, [fetchWorkflows]);

  const saveWorkflow = useCallback(async (workflow: Workflow) => {
    try {
      await apiClient.saveWorkflow(workflow);
      await fetchWorkflows();
    } catch (err) {
      throw err;
    }
  }, [fetchWorkflows]);

  return { workflows, loading, error, saveWorkflow, refresh: fetchWorkflows };
}

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchJobs = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiClient.getJobs();
      setJobs(data);
      setError(null);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, [fetchJobs]);

  const createJob = useCallback(async (
    workflowName: string,
    inputData: any,
    params?: any
  ): Promise<Job> => {
    try {
      const job = await apiClient.createJob(workflowName, inputData, params);
      await fetchJobs();
      return job;
    } catch (err) {
      throw err;
    }
  }, [fetchJobs]);

  const pauseJob = useCallback(async (jobId: string) => {
    try {
      await apiClient.pauseJob(jobId);
      await fetchJobs();
    } catch (err) {
      throw err;
    }
  }, [fetchJobs]);

  const resumeJob = useCallback(async (jobId: string) => {
    try {
      await apiClient.resumeJob(jobId);
      await fetchJobs();
    } catch (err) {
      throw err;
    }
  }, [fetchJobs]);

  const cancelJob = useCallback(async (jobId: string) => {
    try {
      await apiClient.cancelJob(jobId);
      await fetchJobs();
    } catch (err) {
      throw err;
    }
  }, [fetchJobs]);

  return {
    jobs,
    loading,
    error,
    createJob,
    pauseJob,
    resumeJob,
    cancelJob,
    refresh: fetchJobs,
  };
}

export function useJobUpdates(jobId: string | null) {
  const [events, setEvents] = useState<WebSocketEvent[]>([]);
  const [status, setStatus] = useState<JobStatus | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!jobId) return;

    const connection = wsManager.getConnection(jobId);
    
    const connectWebSocket = async () => {
      try {
        await connection.connect();
        setConnected(true);
      } catch (error) {
        console.error('Failed to connect WebSocket:', error);
        setConnected(false);
      }
    };

    connectWebSocket();

    const unsubscribe = connection.subscribe((event: WebSocketEvent) => {
      setEvents((prev) => [...prev, event]);
      
      // Update status based on event type
      if (event.type === 'NODE.START' || event.type === 'NODE.OUTPUT' || 
          event.type === 'RUN.FINISHED' || event.type === 'NODE.ERROR') {
        apiClient.getJob(jobId).then(setStatus).catch(console.error);
      }
    });

    // Fetch initial status
    apiClient.getJob(jobId).then(setStatus).catch(console.error);

    return () => {
      unsubscribe();
      wsManager.disconnect(jobId);
      setConnected(false);
    };
  }, [jobId]);

  const sendCommand = useCallback((command: any) => {
    if (!jobId) return;
    const connection = wsManager.getConnection(jobId);
    connection.send(command);
  }, [jobId]);

  return {
    events,
    status,
    connected,
    sendCommand,
  };
}

export function useConfig() {
  const [config, setConfig] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        setLoading(true);
        const data = await apiClient.getConfig();
        setConfig(data);
        setError(null);
      } catch (err) {
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    fetchConfig();
  }, []);

  return { config, loading, error };
}
