import { useEffect, useRef, useCallback } from 'react';
import { WebSocketConnection } from '@/websocket/connection';
import { JobUpdate } from '@/types';
import { useWorkflowStore } from '@/store/workflowStore';

export function useJobUpdates(jobId: string | null) {
  const wsRef = useRef<WebSocketConnection | null>(null);
  const { addLog, updateJobStatus, updateNodeStatus } = useWorkflowStore();

  const handleUpdate = useCallback((update: JobUpdate) => {
    console.log('Job update:', update);

    switch (update.type) {
      case 'status':
        if (update.data.status) {
          updateJobStatus(update.job_id, update.data.status);
        }
        break;

      case 'progress':
        // Handle progress updates
        if (update.data.step_id && update.data.status) {
          updateNodeStatus(update.data.step_id, update.data.status);
        }
        break;

      case 'log':
        addLog({
          timestamp: update.timestamp,
          level: update.data.level || 'info',
          message: update.data.message,
          agent: update.data.agent,
        });
        break;

      case 'agent_start':
        if (update.data.agent_id) {
          updateNodeStatus(update.data.agent_id, 'running');
        }
        break;

      case 'agent_complete':
        if (update.data.agent_id) {
          updateNodeStatus(update.data.agent_id, 'completed');
        }
        break;

      case 'error':
        addLog({
          timestamp: update.timestamp,
          level: 'error',
          message: update.data.message || 'Unknown error',
          agent: update.data.agent,
        });
        break;
    }
  }, [addLog, updateJobStatus, updateNodeStatus]);

  useEffect(() => {
    if (!jobId) {
      return;
    }

    // Create WebSocket connection
    const ws = new WebSocketConnection(jobId);
    wsRef.current = ws;

    // Subscribe to updates
    const unsubscribe = ws.subscribe(handleUpdate);

    // Connect
    ws.connect();

    // Cleanup
    return () => {
      unsubscribe();
      ws.disconnect();
      wsRef.current = null;
    };
  }, [jobId, handleUpdate]);

  const sendCommand = useCallback((command: any) => {
    wsRef.current?.send(command);
  }, []);

  return {
    sendCommand,
    isConnected: wsRef.current?.isConnected() ?? false,
  };
}

export default useJobUpdates;
