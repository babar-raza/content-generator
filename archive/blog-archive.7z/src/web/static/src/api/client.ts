import axios, { AxiosInstance } from 'axios';
import { Agent, Workflow, Job, JobStatus } from '@/types';

class APIClient {
  private client: AxiosInstance;

  constructor(baseURL: string = '/mcp') {
    this.client = axios.create({
      baseURL,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  // Agents
  async getAgents(): Promise<Record<string, Agent>> {
    const response = await this.client.get('/agents');
    return response.data.agents || {};
  }

  async getAgentConfig(agentId: string): Promise<Agent> {
    const response = await this.client.get(`/agents/${agentId}`);
    return response.data;
  }

  // Workflows
  async getWorkflows(): Promise<Record<string, Workflow>> {
    const response = await this.client.get('/workflows');
    return response.data.workflows || {};
  }

  async getWorkflow(name: string): Promise<Workflow> {
    const response = await this.client.get(`/workflows/${name}`);
    return response.data;
  }

  async saveWorkflow(workflow: Workflow): Promise<void> {
    await this.client.post('/workflows', workflow);
  }

  async updateWorkflow(name: string, workflow: Workflow): Promise<void> {
    await this.client.put(`/workflows/${name}`, workflow);
  }

  async deleteWorkflow(name: string): Promise<void> {
    await this.client.delete(`/workflows/${name}`);
  }

  // Jobs
  async createJob(workflowName: string, inputData: any, params?: any): Promise<Job> {
    const response = await this.client.post('/request', {
      method: 'jobs/create',
      params: {
        workflow_name: workflowName,
        input_data: inputData,
        params: params || {},
      },
    });
    return response.data.result;
  }

  async getJobs(): Promise<Job[]> {
    const response = await this.client.post('/request', {
      method: 'jobs/list',
      params: {},
    });
    return response.data.result?.jobs || [];
  }

  async getJob(jobId: string): Promise<JobStatus> {
    const response = await this.client.post('/request', {
      method: 'jobs/get',
      params: { job_id: jobId },
    });
    return response.data.result;
  }

  async pauseJob(jobId: string): Promise<void> {
    await this.client.post('/request', {
      method: 'jobs/pause',
      params: { job_id: jobId },
    });
  }

  async resumeJob(jobId: string): Promise<void> {
    await this.client.post('/request', {
      method: 'jobs/resume',
      params: { job_id: jobId },
    });
  }

  async cancelJob(jobId: string): Promise<void> {
    await this.client.post('/request', {
      method: 'jobs/cancel',
      params: { job_id: jobId },
    });
  }

  // Configuration
  async getConfig(): Promise<any> {
    const response = await this.client.get('/config/snapshot');
    return response.data;
  }

  async getAgentConfigs(): Promise<any> {
    const response = await this.client.get('/config/agents');
    return response.data;
  }

  async getWorkflowConfigs(): Promise<any> {
    const response = await this.client.get('/config/workflows');
    return response.data;
  }
}

export const apiClient = new APIClient();
export default apiClient;
