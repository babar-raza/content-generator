# src/web/websocket_handlers.py
"""WebSocket handlers for real-time updates.

Provides WebSocket endpoints for:
- Job-specific updates
- Workflow visualization
- Agent status monitoring
"""

import logging
import asyncio
import json
from typing import Optional
from fastapi import WebSocket, WebSocketDisconnect, APIRouter
from datetime import datetime, timezone

from .connection_manager import get_connection_manager
from .dependencies import get_job_engine

logger = logging.getLogger(__name__)

router = APIRouter(tags=["websockets"])


@router.websocket("/ws/jobs/{job_id}")
async def websocket_job_endpoint(websocket: WebSocket, job_id: str):
    """WebSocket endpoint for job-specific real-time updates.
    
    Clients connect to this endpoint to receive updates about a specific job.
    
    Message types sent:
    - connection.established: Initial connection confirmation
    - job.started: Job execution started
    - job.step.started: Agent step started
    - job.step.completed: Agent step completed
    - job.step.failed: Agent step failed
    - job.progress: Job progress update
    - job.completed: Job finished successfully
    - job.failed: Job failed
    - heartbeat: Periodic heartbeat
    
    Args:
        websocket: WebSocket connection
        job_id: Job identifier
    """
    connection_manager = get_connection_manager()
    
    try:
        # Accept connection
        await connection_manager.connect_job(websocket, job_id)
        
        logger.info(f"WebSocket connected for job {job_id}")
        
        # Check if job exists
        try:
            job_engine = get_job_engine()
            job_status = job_engine.get_job_status(job_id)
            
            if job_status:
                # Send current job status
                await websocket.send_json({
                    "type": "job.status",
                    "data": job_status,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
        except Exception as e:
            logger.warning(f"Could not fetch job status: {e}")
        
        # Keep connection alive and handle incoming messages
        try:
            while True:
                # Receive message from client
                data = await websocket.receive_text()
                
                # Parse and handle message
                try:
                    message = json.loads(data)
                    await handle_client_message(websocket, job_id, message)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON from client: {data}")
                    await websocket.send_json({
                        "type": "error",
                        "data": {"message": "Invalid JSON"},
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    })
                
        except WebSocketDisconnect:
            logger.info(f"Client disconnected from job {job_id}")
        
    except Exception as e:
        logger.error(f"WebSocket error for job {job_id}: {e}", exc_info=True)
    
    finally:
        # Cleanup
        connection_manager.disconnect(websocket)


@router.websocket("/ws/visual")
async def websocket_visual_endpoint(websocket: WebSocket):
    """WebSocket endpoint for workflow visualization updates.
    
    Receives updates about workflow state changes for visualization.
    
    Message types sent:
    - connection.established: Initial connection confirmation
    - workflow.state: Workflow state update
    - workflow.graph: Workflow graph structure
    - agent.execution: Agent execution event
    - heartbeat: Periodic heartbeat
    
    Args:
        websocket: WebSocket connection
    """
    connection_manager = get_connection_manager()
    
    try:
        await connection_manager.connect_visual(websocket)
        logger.info("WebSocket connected for visual updates")
        
        # Keep connection alive
        try:
            while True:
                data = await websocket.receive_text()
                
                try:
                    message = json.loads(data)
                    await handle_visual_message(websocket, message)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON from visual client: {data}")
        
        except WebSocketDisconnect:
            logger.info("Visual client disconnected")
    
    except Exception as e:
        logger.error(f"Visual WebSocket error: {e}", exc_info=True)
    
    finally:
        connection_manager.disconnect(websocket)


@router.websocket("/ws/agents")
async def websocket_agents_endpoint(websocket: WebSocket):
    """WebSocket endpoint for agent status updates.
    
    Receives updates about agent execution and status.
    
    Message types sent:
    - connection.established: Initial connection confirmation
    - agent.status: Agent status update
    - agent.started: Agent started execution
    - agent.completed: Agent completed execution
    - agent.failed: Agent failed
    - heartbeat: Periodic heartbeat
    
    Args:
        websocket: WebSocket connection
    """
    connection_manager = get_connection_manager()
    
    try:
        await connection_manager.connect_agents(websocket)
        logger.info("WebSocket connected for agent updates")
        
        # Keep connection alive
        try:
            while True:
                data = await websocket.receive_text()
                
                try:
                    message = json.loads(data)
                    await handle_agent_message(websocket, message)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON from agent client: {data}")
        
        except WebSocketDisconnect:
            logger.info("Agent client disconnected")
    
    except Exception as e:
        logger.error(f"Agent WebSocket error: {e}", exc_info=True)
    
    finally:
        connection_manager.disconnect(websocket)


async def handle_client_message(
    websocket: WebSocket,
    job_id: str,
    message: dict
):
    """Handle incoming message from job WebSocket client.
    
    Args:
        websocket: WebSocket connection
        job_id: Job identifier
        message: Parsed message from client
    """
    message_type = message.get("type")
    
    if message_type == "ping":
        # Respond to ping
        await websocket.send_json({
            "type": "pong",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    
    elif message_type == "get_status":
        # Send current job status
        try:
            job_engine = get_job_engine()
            job_status = job_engine.get_job_status(job_id)
            
            if job_status:
                await websocket.send_json({
                    "type": "job.status",
                    "data": job_status,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
            else:
                await websocket.send_json({
                    "type": "error",
                    "data": {"message": "Job not found"},
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
        except Exception as e:
            logger.error(f"Failed to get job status: {e}")
            await websocket.send_json({
                "type": "error",
                "data": {"message": str(e)},
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    
    else:
        logger.warning(f"Unknown message type from client: {message_type}")


async def handle_visual_message(websocket: WebSocket, message: dict):
    """Handle incoming message from visual WebSocket client.
    
    Args:
        websocket: WebSocket connection
        message: Parsed message from client
    """
    message_type = message.get("type")
    
    if message_type == "ping":
        await websocket.send_json({
            "type": "pong",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    
    elif message_type == "get_workflows":
        # Could fetch and send workflow list
        pass
    
    else:
        logger.warning(f"Unknown visual message type: {message_type}")


async def handle_agent_message(websocket: WebSocket, message: dict):
    """Handle incoming message from agent WebSocket client.
    
    Args:
        websocket: WebSocket connection
        message: Parsed message from client
    """
    message_type = message.get("type")
    
    if message_type == "ping":
        await websocket.send_json({
            "type": "pong",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    
    elif message_type == "get_agents":
        # Could fetch and send agent list
        pass
    
    else:
        logger.warning(f"Unknown agent message type: {message_type}")


class WebSocketEventBridge:
    """Bridge between event bus and WebSocket connections.
    
    Subscribes to event bus and forwards relevant events to WebSocket clients.
    """
    
    def __init__(self):
        self.connection_manager = get_connection_manager()
        self.subscriptions = []
        logger.info("WebSocketEventBridge initialized")
    
    def start(self, event_bus):
        """Start listening to event bus and forwarding to WebSocket.
        
        Args:
            event_bus: EventBus instance
        """
        # Subscribe to job events
        self.subscriptions.append(
            event_bus.subscribe("job.*", self._handle_job_event)
        )
        
        # Subscribe to agent events
        self.subscriptions.append(
            event_bus.subscribe("agent.*", self._handle_agent_event)
        )
        
        # Subscribe to workflow events
        self.subscriptions.append(
            event_bus.subscribe("workflow.*", self._handle_workflow_event)
        )
        
        logger.info("WebSocketEventBridge started listening to event bus")
    
    async def _handle_job_event(self, event):
        """Handle job-related events.
        
        Args:
            event: AgentEvent from event bus
        """
        try:
            # Extract job_id from event
            job_id = event.correlation_id or event.data.get("job_id")
            
            if not job_id:
                return
            
            # Determine message type
            event_type = event.event_type
            message_type = f"job.{event_type}"
            
            # Create WebSocket message
            message = {
                "type": message_type,
                "data": event.data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
            # Broadcast to job-specific clients
            await self.connection_manager.broadcast_job(job_id, message)
            
        except Exception as e:
            logger.error(f"Failed to handle job event: {e}")
    
    async def _handle_agent_event(self, event):
        """Handle agent-related events.
        
        Args:
            event: AgentEvent from event bus
        """
        try:
            message = {
                "type": f"agent.{event.event_type}",
                "data": event.data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
            # Broadcast to agent status clients
            await self.connection_manager.broadcast_agents(message)
            
            # Also broadcast to visual clients
            await self.connection_manager.broadcast_visual(message)
            
        except Exception as e:
            logger.error(f"Failed to handle agent event: {e}")
    
    async def _handle_workflow_event(self, event):
        """Handle workflow-related events.
        
        Args:
            event: AgentEvent from event bus
        """
        try:
            message = {
                "type": f"workflow.{event.event_type}",
                "data": event.data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
            # Broadcast to visual clients
            await self.connection_manager.broadcast_visual(message)
            
        except Exception as e:
            logger.error(f"Failed to handle workflow event: {e}")


# Global bridge instance
_websocket_bridge: Optional[WebSocketEventBridge] = None


def get_websocket_bridge() -> WebSocketEventBridge:
    """Get the global WebSocket event bridge.
    
    Returns:
        WebSocketEventBridge instance
    """
    global _websocket_bridge
    
    if _websocket_bridge is None:
        _websocket_bridge = WebSocketEventBridge()
    
    return _websocket_bridge


def initialize_websocket_bridge(event_bus):
    """Initialize and start the WebSocket event bridge.
    
    Args:
        event_bus: EventBus instance
    """
    bridge = get_websocket_bridge()
    bridge.start(event_bus)
    
    # Start heartbeat
    connection_manager = get_connection_manager()
    connection_manager.start_heartbeat()
    
    logger.info("WebSocket bridge initialized and started")
