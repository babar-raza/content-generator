"""Debugging API routes for workflow inspection and control."""

import logging
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from datetime import datetime, timezone

from ..models import (
    BreakpointCreateRequest,
    BreakpointResponse,
    BreakpointListResponse,
    DebugStepRequest,
    DebugStepResponse,
    DebugStateResponse,
)
from ...visualization.workflow_debugger import WorkflowDebugger

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/debug", tags=["debug"])

# Global debugger instance
_debugger = None


def get_debugger():
    """Get or create debugger instance."""
    global _debugger
    if _debugger is None:
        _debugger = WorkflowDebugger()
    return _debugger


# ============================================================================
# Breakpoint Management
# ============================================================================

@router.post("/breakpoints", response_model=BreakpointResponse, status_code=201)
async def create_breakpoint(request: BreakpointCreateRequest):
    """Set a debugging breakpoint.
    
    Args:
        request: Breakpoint creation request
        
    Returns:
        BreakpointResponse with breakpoint ID and details
    """
    try:
        debugger = get_debugger()
        
        # Create debug session if needed
        session_id = request.session_id
        if session_id not in debugger.debug_sessions:
            session_id = debugger.start_debug_session(
                request.correlation_id or f"session_{int(datetime.now().timestamp())}"
            )
        
        # Add breakpoint
        breakpoint_id = debugger.add_breakpoint(
            session_id=session_id,
            agent_id=request.agent_id,
            event_type=request.event_type,
            condition=request.condition,
            max_hits=request.max_hits
        )
        
        breakpoint = debugger.active_breakpoints[breakpoint_id]
        
        return BreakpointResponse(
            breakpoint_id=breakpoint_id,
            session_id=session_id,
            agent_id=breakpoint.agent_id,
            event_type=breakpoint.event_type,
            condition=breakpoint.condition,
            enabled=breakpoint.enabled,
            hit_count=breakpoint.hit_count,
            max_hits=breakpoint.max_hits,
            created_at=datetime.now(timezone.utc)
        )
    except Exception as e:
        logger.error(f"Error creating breakpoint: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to create breakpoint: {str(e)}")


@router.delete("/breakpoints/{breakpoint_id}")
async def delete_breakpoint(breakpoint_id: str, session_id: Optional[str] = None):
    """Remove a debugging breakpoint.
    
    Args:
        breakpoint_id: Breakpoint identifier
        session_id: Optional session ID (if not provided, searches all sessions)
        
    Returns:
        Success message
    """
    try:
        debugger = get_debugger()
        
        # Find the session containing this breakpoint
        target_session_id = session_id
        if not target_session_id:
            for sid, session in debugger.debug_sessions.items():
                if any(bp.id == breakpoint_id for bp in session.breakpoints):
                    target_session_id = sid
                    break
        
        if not target_session_id:
            raise HTTPException(status_code=404, detail=f"Breakpoint '{breakpoint_id}' not found")
        
        if target_session_id not in debugger.debug_sessions:
            raise HTTPException(status_code=404, detail=f"Debug session '{target_session_id}' not found")
        
        # Remove breakpoint
        debugger.remove_breakpoint(target_session_id, breakpoint_id)
        
        return {"message": f"Breakpoint '{breakpoint_id}' removed successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting breakpoint: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to delete breakpoint: {str(e)}")


@router.get("/breakpoints", response_model=BreakpointListResponse)
async def list_breakpoints(session_id: Optional[str] = None, enabled_only: bool = False):
    """List active breakpoints.
    
    Args:
        session_id: Optional session ID to filter by
        enabled_only: If True, only return enabled breakpoints
        
    Returns:
        BreakpointListResponse with list of breakpoints
    """
    try:
        debugger = get_debugger()
        
        breakpoints = []
        
        if session_id:
            # Get breakpoints for specific session
            if session_id not in debugger.debug_sessions:
                raise HTTPException(status_code=404, detail=f"Debug session '{session_id}' not found")
            
            session = debugger.debug_sessions[session_id]
            for bp in session.breakpoints:
                if enabled_only and not bp.enabled:
                    continue
                breakpoints.append({
                    "breakpoint_id": bp.id,
                    "session_id": session_id,
                    "agent_id": bp.agent_id,
                    "event_type": bp.event_type,
                    "condition": bp.condition,
                    "enabled": bp.enabled,
                    "hit_count": bp.hit_count,
                    "max_hits": bp.max_hits
                })
        else:
            # Get all breakpoints across all sessions
            for sid, session in debugger.debug_sessions.items():
                for bp in session.breakpoints:
                    if enabled_only and not bp.enabled:
                        continue
                    breakpoints.append({
                        "breakpoint_id": bp.id,
                        "session_id": sid,
                        "agent_id": bp.agent_id,
                        "event_type": bp.event_type,
                        "condition": bp.condition,
                        "enabled": bp.enabled,
                        "hit_count": bp.hit_count,
                        "max_hits": bp.max_hits
                    })
        
        # Sort by breakpoint_id for deterministic output
        breakpoints.sort(key=lambda x: x['breakpoint_id'])
        
        return BreakpointListResponse(
            breakpoints=breakpoints,
            total=len(breakpoints)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing breakpoints: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to list breakpoints: {str(e)}")


# ============================================================================
# Step-through Debugging
# ============================================================================

@router.post("/step", response_model=DebugStepResponse)
async def debug_step(request: DebugStepRequest):
    """Step through workflow execution.
    
    Args:
        request: Debug step request
        
    Returns:
        DebugStepResponse with step result
    """
    try:
        debugger = get_debugger()
        
        if request.session_id not in debugger.debug_sessions:
            raise HTTPException(status_code=404, detail=f"Debug session '{request.session_id}' not found")
        
        # Enable step mode for this session
        debugger.enable_step_mode(request.session_id)
        
        session = debugger.debug_sessions[request.session_id]
        
        return DebugStepResponse(
            session_id=request.session_id,
            status="stepping",
            current_step=session.current_step,
            message=f"Step mode enabled for session '{request.session_id}'"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in debug step: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to execute debug step: {str(e)}")


@router.get("/state/{job_id}", response_model=DebugStateResponse)
async def get_debug_state(job_id: str):
    """Get current debug state for a job.
    
    Args:
        job_id: Job identifier
        
    Returns:
        DebugStateResponse with current debug state
    """
    try:
        debugger = get_debugger()
        
        # Find session for this job
        session = None
        session_id = None
        for sid, sess in debugger.debug_sessions.items():
            if sess.correlation_id == job_id:
                session = sess
                session_id = sid
                break
        
        if not session:
            raise HTTPException(status_code=404, detail=f"No debug session found for job '{job_id}'")
        
        return DebugStateResponse(
            job_id=job_id,
            session_id=session_id,
            status=session.status,
            current_step=session.current_step,
            step_history=session.step_history,
            variables=session.variables,
            breakpoints=[
                {
                    "breakpoint_id": bp.id,
                    "agent_id": bp.agent_id,
                    "event_type": bp.event_type,
                    "enabled": bp.enabled,
                    "hit_count": bp.hit_count
                }
                for bp in session.breakpoints
            ]
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting debug state: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to get debug state: {str(e)}")
