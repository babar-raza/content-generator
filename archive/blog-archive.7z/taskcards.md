### **Task Card 1 – Services: LLMService improvements**

```
Role: Senior engineer. Produce drop‑in, production‑ready code.

Scope (only this):
- Fix: LLMService lacks rate limiting and model mapping.
- Allowed paths: src/services/services.py, src/services/model_router.py, docs/SERVICES_DESIGN.md
- Forbidden: any other file

Acceptance checks (must pass locally):
- CLI: python ucop_cli.py run --workflow default_blog
- Web: python start_web.py then open http://127.0.0.1:8080 and start a job
- Tests: pytest -q
- No mock data used in production paths
- Configs in ./config/ are enforced end to end

Deliverables:
- Full file replacements only (no diffs, no stubs, no TODO)
- New tests in /tests/ covering happy path (rate limiting and model mapping work) and a failing path that used to break (e.g. unlimited provider calls are throttled)
- Updated documentation in SERVICES_DESIGN.md describing rate limiting and model mapping behaviour
- Always return the package with the structure intact, including only the files you updated

Hard rules:

- Keep public function signatures unless you justify and update all call sites
- Zero network calls in tests
- Deterministic runs: set seeds, stable ordering
- Do not introduce new dependencies

Now:
1) Show the minimal design for the change
2) Provide the full updated files in project structure
3) Provide the tests
4) Provide a short runbook: exact commands in order
```

**Minimal design guidance**: Add a per‑provider rate limiter in `LLMService.generate()` or `_call_provider()` using a simple token bucket keyed by provider.  Store timestamps of recent calls and enforce configurable minimum intervals (Gemini specific).  Introduce a model mapping (generic model names → provider‑specific names) using a dictionary or existing `model_router.py`, and add a `map_model()` helper.  Update `SERVICES_DESIGN.md` to document rate limiting and model mapping.

---

### **Task Card 2 – Services: missing methods and wrappers**

```
Role: Senior engineer. Produce drop‑in, production‑ready code.

Scope (only this):
- Fix: Incomplete implementations in services module (GistService CRUD, TrendsService missing get_trending_searches, EmbeddingService wrapper and dimension, DatabaseService embedding support, LinkChecker parallel and fallback).
- Allowed paths: src/services/services.py, src/services/__init__.py, docs/SERVICES_DESIGN.md
- Forbidden: any other file

Acceptance checks (must pass locally):
- CLI: python ucop_cli.py run --workflow default_blog
- Web: python start_web.py then open http://127.0.0.1:8080 and start a job
- Tests: pytest -q
- No mock data used in production paths
- Configs in ./config/ are enforced end to end

Deliverables:
- Full file replacements only (no diffs, no stubs, no TODO)
- New tests in /tests/ covering:
  • GistService get/update/delete happy path and failure
  • TrendsService get_trending_searches returns data
  • EmbeddingService.encode wrapper returns same embeddings and get_dimension returns correct value
  • DatabaseService.add_documents accepts and stores provided embeddings
  • LinkChecker.check_urls executes in parallel and falls back to GET when HEAD fails
- Updated documentation in SERVICES_DESIGN.md reflecting these capabilities
- Always return the package with the structure intact, including only the files you updated

Hard rules:

- Keep public function signatures unless you justify and update all call sites
- Zero network calls in tests
- Deterministic runs: set seeds, stable ordering
- Do not introduce new dependencies

Now:
1) Show the minimal design for the change
2) Provide the full updated files in project structure
3) Provide the tests
4) Provide a short runbook: exact commands in order
```

**Minimal design guidance**: Implement `GistService.get_gist()`, `update_gist()`, `delete_gist()` using authenticated GitHub API calls.  Add `TrendsService.get_trending_searches()` using pytrends.  Provide `EmbeddingService.encode()` as a wrapper over the existing `embed()` method and add `get_dimension()`.  Modify `DatabaseService.add_documents()` to accept an optional `embeddings` list and use it instead of re‑embedding.  Enhance `LinkChecker.check_urls()` to run tasks in a ThreadPoolExecutor, using GET as a fallback when HEAD returns non‑success.  Update exports in `__init__.py` and adjust docs accordingly.

---

### **Task Card 3 – Utils: expose repair_json wrapper**

```
Role: Senior engineer. Produce drop‑in, production‑ready code.

Scope (only this):
- Fix: Expose a repair_json() function that returns a JSON string, wrapping JSONRepair.repair().
- Allowed paths: src/utils/__init__.py, docs/UTILS_DESIGN.md
- Forbidden: any other file

Acceptance checks (must pass locally):
- CLI: python ucop_cli.py run --workflow default_blog
- Web: python start_web.py then open http://127.0.0.1:8080 and start a job
- Tests: pytest -q
- No mock data used in production paths
- Configs in ./config/ are enforced end to end

Deliverables:
- Full file replacements only (no diffs, no stubs, no TODO)
- New tests in /tests/ covering repair_json() for valid, malformed and unrecoverable JSON
- Updated documentation in UTILS_DESIGN.md describing repair_json() and its return type
- Always return the package with the structure intact, including only the files you updated

Hard rules:

- Keep public function signatures unless you justify and update all call sites
- Zero network calls in tests
- Deterministic runs: set seeds, stable ordering
- Do not introduce new dependencies

Now:
1) Show the minimal design for the change
2) Provide the full updated files in project structure
3) Provide the tests
4) Provide a short runbook: exact commands in order
```

**Minimal design guidance**: In `src/utils/__init__.py`, define a function `repair_json(text: str) -> str` that calls `JSONRepair.repair()` and then uses `json.dumps()` to serialize the returned object back to a JSON string.  Export it alongside other utilities.  Update `UTILS_DESIGN.md` to describe the new wrapper.

---