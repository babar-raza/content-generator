# ARCH_UI_AND_RUNTIME_MAP.md

**Repository Analysis: UI & Runtime Architecture**  
**Analysis Date:** 2025-11-13  
**Scope:** src/web/, src/realtime/, src/mesh/, src/visualization/, entry points  

---

## 1. UI & RUNTIME MAP (HIGH LEVEL)

### 1.1 UI Applications

| Name | Entry File | Backend App | Main Routes | Status | Notes |
|------|-----------|-------------|-------------|--------|-------|
| **Workflow Editor (React)** | `start_web.py` | `src/web/app.py` (4KB) | `/`, `/health`, `/mcp/*`, `/ws/mesh` | **PRIMARY** | Active. Used by main entry point. React/Vite UI + MCP protocol. |
| **Simple API Server** | `start_api.py` | `src/web/app:app` (same as above) | Same as above | **ALTERNATIVE** | Lightweight launcher without hot reload or executor setup. |
| **Unified Dashboard** | *(none)* | `src/web/app_unified.py` (9KB) | `/`, `/api/templates`, `/api/generate`, `/api/batch`, `/api/jobs/*`, `/health` | **LEGACY/UNUSED** | NOT wired to any entry point. Uses Jinja2 templates (dashboard.html, job_detail.html). |
| **Integrated Dashboard** | *(none)* | `src/web/app_integrated.py` (25KB) | `/`, `/jobs/{job_id}`, `/api/*`, `/visual/*`, `/debug/*` | **LEGACY/UNUSED** | NOT wired to any entry point. Full featured with visualization, debugging, breakpoints. Uses dashboard_integrated.html. |

### 1.2 HTML Templates

| Template | Size | Used By | Purpose | Status |
|----------|------|---------|---------|--------|
| `dashboard.html` | 13KB | app_unified.py | Simple job dashboard | UNUSED |
| `dashboard_integrated.html` | 26KB | app_integrated.py | Full-featured integrated dashboard with visualization | UNUSED |
| `job_detail.html` | 5KB | app_unified.py | Basic job detail view | UNUSED |
| `job_detail_enhanced.html` | 21KB | app_integrated.py | Enhanced job detail with debugging | UNUSED |
| `orchestration_base.html` | 33KB | *(standalone?)* | Visual orchestration base template | UNCLEAR |
| `test.html` | 4KB | *(testing)* | Test template | DEV ONLY |

### 1.3 React UI (Static)

| Component | Location | Status | Notes |
|-----------|----------|--------|-------|
| **React/Vite App** | `src/web/static/` | **PRIMARY** | Used by app.py. Has vite.config.ts, package.json. Serves from `/assets` and `/` routes. |
| **Build Output** | `src/web/static/dist/` | GENERATED | Production build output. Must be built via `npm run build`. |

### 1.4 Entry Points

| Entry Point | Purpose | Engine Used | UI Components | Status |
|-------------|---------|-------------|---------------|--------|
| `start_web.py` | Web UI + Hot Reload | UnifiedEngine | app.py (React UI) | **PRIMARY** |
| `start_api.py` | API Only (lightweight) | None (imports app directly) | app.py | **ALTERNATIVE** |
| `ucop_cli.py` | CLI Interface | get_engine() from src/engine/engine | CLI (no UI) | **PRIMARY** |
| `job_cli.py` | Job Management CLI | *(custom)* | CLI (no UI) | **ACTIVE** |
| `src/main.py` | Legacy Entry Point | Manual agent creation | None | **LEGACY** |

### 1.5 Runtime Layers

| Package | Key Modules | Used By | Usage Level |
|---------|-------------|---------|-------------|
| **src/web** | app.py, routes/*, connection_manager.py, websocket_handlers.py | start_web.py, start_api.py | **HOT PATH** |
| **src/realtime** | websocket.py, job_control.py | app.py, ops_console.py | **HOT PATH** |
| **src/mesh** | capability_registry.py, mesh_observer.py, negotiation.py, runtime_async.py, state_store.py | src/main.py, validation tools | **OPTIONAL** |
| **src/visualization** | workflow_visualizer.py, agent_flow_monitor.py, workflow_debugger.py, monitor.py, visual_api.py | app_integrated.py (UNUSED), ucop_cli.py | **OPTIONAL/UNUSED** |
| **src/engine** | unified_engine.py, engine.py, executor.py | start_web.py, ucop_cli.py | **HOT PATH** |
| **src/orchestration** | hot_reload.py, agent_scanner.py, checkpoint_manager.py, ops_console.py | start_web.py, ucop_cli.py, app_integrated.py | **HOT PATH** |
| **src/mcp** | web_adapter.py, protocol.py, handlers.py | app.py, routes/mcp.py | **HOT PATH** |

---

## 2. MODULE USAGE ANALYSIS

### 2.1 src/web (392KB, 13 files)

**Purpose:** Web UI and API server infrastructure.

**Files:**
- `app.py` (4KB) - PRIMARY FastAPI app, used by start_web.py
- `app_integrated.py` (25KB) - UNUSED full-featured app with visualization
- `app_unified.py` (9KB) - UNUSED alternative app with Jinja2 templates
- `connection_manager.py` (12KB) - WebSocket connection management
- `websocket_handlers.py` (13KB) - WebSocket event handlers
- `dependencies.py` (2.5KB) - FastAPI dependency injection
- `models.py` (3KB) - Pydantic models
- `routes/` - API route modules:
  - `agents.py` (5KB)
  - `jobs.py` (8.5KB)
  - `mcp.py` (6.5KB)
  - `workflows.py` (5KB)

**Import Relationships:**
- Imported by: start_web.py, start_api.py
- Imports: src.mcp (web_adapter), src.realtime (websocket), src.engine (unified_engine), src.orchestration

**Consolidation Candidates:**
- **app_integrated.py** and **app_unified.py** - Consider moving useful features to app.py or archiving
- Multiple HTML templates - Consolidate or remove unused templates

### 2.2 src/realtime (23KB, 3 files)

**Purpose:** Real-time WebSocket communication and job control.

**Files:**
- `websocket.py` (7KB) - WebSocket manager (get_ws_manager)
- `job_control.py` (8KB) - Job control interface

**Import Relationships:**
- Imported by: app.py, ops_console.py, integrated_init.py, validate.py
- Imports: src.core (event_bus)

**Usage:** **HOT PATH** - Actively used by app.py for `/ws/mesh` endpoint.

**Recommendations:**
- Keep as-is, actively used
- Well-scoped and focused

### 2.3 src/mesh (169KB, 9 files)

**Purpose:** Agent mesh infrastructure for distributed agent coordination.

**Files:**
- `capability_registry.py` (50KB) - Agent capability registration
- `mesh_observer.py` (35KB) - Mesh state observation
- `negotiation.py` (24KB) - Agent negotiation protocol
- `runtime_async.py` (15KB) - Async runtime for mesh
- `state_store.py` (15KB) - Mesh state persistence
- `batch_aggregators.py` (16KB) - Batch processing for mesh
- `cache/` - Caching infrastructure

**Import Relationships:**
- Imported by: src/main.py (LEGACY), validate_system.py, validate_imports.py
- NOT imported by: start_web.py, start_api.py, ucop_cli.py

**Usage:** **OPTIONAL/UNUSED** - Only used by legacy main.py and validation tools.

**Recommendations:**
- Appears to be an alternative execution model not integrated with UnifiedEngine
- Consider: Is mesh needed? If yes, integrate with UnifiedEngine. If no, archive.
- Task card: RUNTIME-MESH-01 - "Evaluate mesh integration or archival"

### 2.4 src/visualization (129KB, 6 files)

**Purpose:** Visual orchestration, debugging, and monitoring.

**Files:**
- `workflow_visualizer.py` (18KB) - Workflow graph visualization
- `agent_flow_monitor.py` (8.5KB) - Agent flow monitoring
- `workflow_debugger.py` (22KB) - Breakpoint and step-through debugging
- `monitor.py` (16KB) - System monitoring
- `visual_api.py` (25KB) - Visualization API endpoints
- `orchestration_dashboard.html` (33KB) - Standalone dashboard

**Import Relationships:**
- Imported by: app_integrated.py (UNUSED), ucop_cli.py (some CLI commands), integrated_init.py, mcp/web_adapter.py, mcp/protocol.py
- NOT imported by: app.py, start_web.py

**Usage:** **OPTIONAL** - Used by CLI visualization commands, but NOT by primary web UI (app.py).

**Recommendations:**
- Heavy visualization features not wired to primary UI (app.py)
- CLI uses some visualization (ucop_cli.py has visual commands)
- Consider: If visualization is desired in web UI, integrate into app.py. Otherwise, keep as CLI-only feature.
- Task card: UI-VIS-01 - "Evaluate visualization integration into primary web UI"

### 2.5 src/engine (142KB, 14 files)

**Purpose:** Core execution engine and workflow orchestration.

**Files:** unified_engine.py, engine.py, executor.py, device/gpu_manager.py, etc.

**Import Relationships:**
- Imported by: start_web.py, ucop_cli.py, app.py, app_integrated.py, app_unified.py
- Core component

**Usage:** **HOT PATH** - Primary execution engine.

**Recommendations:**
- Keep as-is, critical component

### 2.6 src/orchestration (354KB, 22 files)

**Purpose:** Workflow orchestration, hot reload, checkpoints, agent scanning.

**Files:** hot_reload.py, agent_scanner.py, checkpoint_manager.py, ops_console.py, etc.

**Import Relationships:**
- Imported by: start_web.py, ucop_cli.py, app_integrated.py
- Core orchestration layer

**Usage:** **HOT PATH** - Critical orchestration components.

**Recommendations:**
- Keep as-is, critical component

---

## 3. DUPLICATION CANDIDATES

### 3.1 Multiple FastAPI Apps

**Feature Area:** Web UI / API Server

| Implementation | File | Size | Features | Recommendation |
|----------------|------|------|----------|----------------|
| **A** | app.py | 4KB | MCP protocol, React UI, WebSocket, minimal | **KEEP (PRIMARY)** |
| **B** | app_unified.py | 9KB | Jinja2 templates, unified engine, job API | **ARCHIVE or MERGE useful features** |
| **C** | app_integrated.py | 25KB | Full visualization, debugging, Jinja2, extensive API | **ARCHIVE or EXTRACT visualization** |

**Analysis:** 
- app.py is the PRIMARY implementation, actively used by start_web.py
- app_unified.py and app_integrated.py are NOT wired to any entry point
- app_integrated.py has extensive visualization features that may be valuable
- Consider extracting visualization/debugging features from app_integrated.py before archiving

**Preliminary Recommendation:** 
- **KEEP app.py** (primary)
- **EXTRACT** debugging/visualization features from app_integrated.py into separate modules or routes
- **ARCHIVE** app_unified.py and app_integrated.py after extraction

### 3.2 Multiple Dashboard Templates

**Feature Area:** Dashboard UI

| Implementation | File | Size | Features | Used By |
|----------------|------|------|----------|---------|
| **A** | dashboard.html | 13KB | Basic job dashboard | app_unified.py (UNUSED) |
| **B** | dashboard_integrated.html | 26KB | Full-featured dashboard | app_integrated.py (UNUSED) |
| **C** | React UI (src/web/static/) | 119KB | Modern React/Vite app | app.py (PRIMARY) |

**Preliminary Recommendation:**
- **KEEP** React UI (primary)
- **ARCHIVE** dashboard.html and dashboard_integrated.html (not used by primary app)

### 3.3 Multiple Job Detail Views

**Feature Area:** Job Detail Page

| Implementation | File | Size | Features | Used By |
|----------------|------|------|----------|---------|
| **A** | job_detail.html | 5KB | Basic job view | app_unified.py (UNUSED) |
| **B** | job_detail_enhanced.html | 21KB | Enhanced with debugging | app_integrated.py (UNUSED) |
| **C** | React UI (job pages) | In React app | Dynamic job views | app.py (PRIMARY) |

**Preliminary Recommendation:**
- **KEEP** React UI job views (primary)
- **ARCHIVE** job_detail.html and job_detail_enhanced.html

### 3.4 Multiple Entry Points

**Feature Area:** Application Launch

| Implementation | File | Features | Recommendation |
|----------------|------|----------|----------------|
| **A** | start_web.py | Full setup, hot reload, executor | **KEEP (PRIMARY)** |
| **B** | start_api.py | Lightweight API-only | **KEEP (ALTERNATIVE)** |
| **C** | src/main.py | Legacy agent creation | **NEEDS REVIEW** |

**Analysis:**
- start_web.py is the PRIMARY web entry point with full features
- start_api.py is a useful lightweight alternative for API-only usage
- src/main.py uses manual agent creation (legacy pattern) vs unified engine

**Preliminary Recommendation:**
- **KEEP** start_web.py (primary)
- **KEEP** start_api.py (useful alternative)
- **REVIEW** src/main.py - Either modernize to use UnifiedEngine or archive

### 3.5 WebSocket Implementations

**Feature Area:** Real-time Communication

| Implementation | Location | Used By | Features |
|----------------|----------|---------|----------|
| **A** | src/realtime/websocket.py | app.py | Primary WebSocket manager |
| **B** | src/web/connection_manager.py | start_web.py, websocket_handlers.py | Connection management |
| **C** | src/web/websocket_handlers.py | app_integrated.py (UNUSED) | Event handlers |

**Analysis:**
- Two different WebSocket management approaches
- app.py uses src/realtime/websocket.py
- start_web.py uses src/web/connection_manager.py for hot reload notifications

**Preliminary Recommendation:**
- **NEEDS DEEPER REVIEW** - Clarify roles of each WebSocket component
- Task card: UI-DEDUP-02 - "Consolidate WebSocket implementations"

---

## 4. TRUTH VS REALITY TABLE

### 4.1 UI / Runtime Claims

| Claim | Where Claimed | Reality in Code | Risk | Follow-up |
|-------|---------------|-----------------|------|-----------|
| **"Web UI (`src/web/app.py`) provides visual workflow editor and debugger"** | docs/architecture.md:19 | app.py has NO workflow editor UI, NO debugger. Only MCP endpoints and React UI serving. | **HIGH** | UI-DOCS-01 |
| **"Drag-and-drop interface for workflow creation"** | docs/architecture.md:20 | React UI exists (src/web/static) but not clear if it has drag-drop. app.py serves it but doesn't implement it. | **MEDIUM** | UI-DOCS-02 |
| **"Real-time WebSocket updates for job monitoring"** | docs/architecture.md:18 | ✓ TRUE - app.py has `/ws/mesh` endpoint, uses src/realtime/websocket.py | **LOW** | - |
| **"FastAPI app integrates with set_execution_engine()"** | docs/api/FASTAPI_README.md:136 | FALSE - app.py uses `set_global_executor()`, not `set_execution_engine()`. Only app_integrated.py has set_execution_engine(). | **MEDIUM** | UI-DOCS-03 |
| **"Visual Orchestration provides breakpoint system"** | docs/visual_orchestration.md:63-73 | workflow_debugger.py has breakpoint code, but NOT wired to app.py (primary UI). Only in app_integrated.py (UNUSED). | **HIGH** | UI-VIS-02 |
| **"Flamegraph view visualizes execution time"** | docs/visual_orchestration.md:101-108 | NO flamegraph implementation found in codebase. | **HIGH** | UI-VIS-03 |
| **"Bottleneck detection automatically identifies slow agents"** | docs/visual_orchestration.md:110-115 | NO bottleneck detection found in codebase. | **HIGH** | UI-VIS-04 |
| **"Workflow Editor has Agent Palette, Workflow Canvas, Job Monitor"** | docs/web/RUNBOOK_WEB.txt:68-71 | React UI exists (src/web/static) - unclear if it has these specific components without inspecting React code. | **MEDIUM** | UI-DOCS-04 |
| **"MCP protocol endpoints: /mcp/request, /mcp/agents, /mcp/workflows, /mcp/jobs"** | docs/web/RUNBOOK_WEB.txt:144-149 | ✓ TRUE - routes/mcp.py has these endpoints | **LOW** | - |
| **"start_web.py provides --mode api option"** | docs/api/FASTAPI_README.md:44 | FALSE - start_web.py has NO --mode argument. It's a simple launcher. | **MEDIUM** | UI-DOCS-05 |
| **"Mesh infrastructure for agent coordination"** | src/mesh/README.md | mesh/ package exists (169KB) but only imported by src/main.py (LEGACY) and validation tools. NOT used by primary runtime. | **HIGH** | RUNTIME-MESH-01 |

### 4.2 Summary

**High Risk Issues (7):**
- Docs claim visual workflow editor/debugger in app.py - NOT PRESENT
- Docs claim breakpoint system - NOT wired to primary UI
- Docs claim flamegraph view - NOT FOUND
- Docs claim bottleneck detection - NOT FOUND
- Mesh infrastructure documented but not used by primary runtime

**Medium Risk Issues (4):**
- Drag-drop interface unclear without inspecting React code
- Function name mismatch (set_execution_engine vs set_global_executor)
- --mode argument documented but not implemented
- Workflow Editor components unclear

**Low Risk Issues (2):**
- WebSocket and MCP endpoints documented correctly

---

## 5. PROPOSED REFACTOR TASK LIST

### 5.1 UI Consolidation Tasks

**UI-DEDUP-01: Archive Unused Web Apps**
- **Scope:** Archive app_unified.py and app_integrated.py after feature extraction
- **Affected Modules:** src/web/app_unified.py, src/web/app_integrated.py
- **Steps:**
  1. Extract any unique debugging/visualization features from app_integrated.py
  2. Create migration guide for anyone using these apps (unlikely since not wired)
  3. Move to archive/ folder with dated suffix
  4. Update any lingering references in docs

**UI-DEDUP-02: Consolidate WebSocket Implementations**
- **Scope:** Clarify and consolidate WebSocket management
- **Affected Modules:** src/realtime/websocket.py, src/web/connection_manager.py, src/web/websocket_handlers.py
- **Steps:**
  1. Document roles of each WebSocket component
  2. Determine if there's actual duplication or complementary functionality
  3. Consolidate if appropriate or clarify separation of concerns
  4. Update architecture docs

**UI-DEDUP-03: Archive Unused HTML Templates**
- **Scope:** Remove dashboard.html, dashboard_integrated.html, job_detail.html, job_detail_enhanced.html
- **Affected Modules:** src/web/templates/*.html
- **Steps:**
  1. Confirm React UI is primary and sufficient
  2. Archive unused Jinja2 templates
  3. Remove template loading code from unused apps
  4. Update docs to reflect React-only UI

### 5.2 Visualization Integration Tasks

**UI-VIS-01: Evaluate Visualization Integration**
- **Scope:** Decide whether to integrate visualization features into primary UI
- **Affected Modules:** src/visualization/*, src/web/app.py
- **Steps:**
  1. Audit visualization features (workflow_visualizer, agent_flow_monitor, workflow_debugger)
  2. Determine which features are valuable for web UI
  3. If valuable: Create integration plan to expose via app.py routes
  4. If not: Keep as CLI-only features and update docs

**UI-VIS-02: Integrate or Remove Breakpoint System**
- **Scope:** Wire workflow_debugger.py into app.py or remove from docs
- **Affected Modules:** src/visualization/workflow_debugger.py, src/web/app.py
- **Steps:**
  1. If keeping: Create REST/WebSocket API for breakpoints in app.py
  2. If removing: Remove from docs and mark as experimental/CLI-only

**UI-VIS-03: Implement or Remove Flamegraph Documentation**
- **Scope:** Either implement flamegraph visualization or remove from docs
- **Affected Modules:** docs/visual_orchestration.md, potential new visualization module
- **Steps:**
  1. Decide if flamegraph is required feature
  2. If yes: Implement using performance data from orchestration layer
  3. If no: Remove from docs, add to future roadmap if desired

**UI-VIS-04: Implement or Remove Bottleneck Detection Documentation**
- **Scope:** Either implement bottleneck detection or remove from docs
- **Affected Modules:** docs/visual_orchestration.md, potential new monitoring module
- **Steps:**
  1. Decide if automatic bottleneck detection is required
  2. If yes: Implement using performance metrics
  3. If no: Remove from docs, add to future roadmap

### 5.3 Runtime Cleanup Tasks

**RUNTIME-MESH-01: Evaluate Mesh Integration or Archival**
- **Scope:** Determine if src/mesh is needed, integrate or archive
- **Affected Modules:** src/mesh/*, src/main.py, src/engine/*
- **Steps:**
  1. Review mesh design and intended use cases
  2. Check if any features overlap with UnifiedEngine
  3. Decision path:
     - If mesh provides unique value: Integrate with UnifiedEngine and wire to entry points
     - If mesh is experimental: Mark as experimental, keep but don't document as primary
     - If mesh is obsolete: Archive entire package
  4. Update architecture docs based on decision

**RUNTIME-CLEANUP-01: Modernize or Archive src/main.py**
- **Scope:** Update src/main.py to use UnifiedEngine or mark as legacy
- **Affected Modules:** src/main.py
- **Steps:**
  1. Review src/main.py usage patterns
  2. If still needed: Refactor to use UnifiedEngine instead of manual agent creation
  3. If obsolete: Archive and update any scripts that reference it
  4. Update docs

### 5.4 Documentation Correction Tasks

**UI-DOCS-01: Correct Architecture Doc UI Claims**
- **Scope:** Fix docs/architecture.md to accurately reflect app.py capabilities
- **Affected Modules:** docs/architecture.md
- **Steps:**
  1. Update line 19 to clarify app.py serves React UI, handles MCP protocol
  2. Remove or clarify "visual workflow editor" claim
  3. Remove or clarify "debugger" claim
  4. Add note about React UI being the primary frontend

**UI-DOCS-02: Verify React UI Features**
- **Scope:** Audit React UI to verify drag-drop and workflow editor claims
- **Affected Modules:** src/web/static/src/*, docs/architecture.md, docs/web/RUNBOOK_WEB.txt
- **Steps:**
  1. Review React code to confirm drag-drop workflow editor exists
  2. Document actual features in React UI
  3. Update docs to match reality
  4. If features missing, either implement or remove from docs

**UI-DOCS-03: Fix set_execution_engine Documentation**
- **Scope:** Correct function name in API docs
- **Affected Modules:** docs/api/FASTAPI_README.md, src/web/app.py
- **Steps:**
  1. Change docs from set_execution_engine to set_global_executor
  2. Or rename function in app.py to match docs (breaking change)
  3. Verify integration examples

**UI-DOCS-04: Document Actual Web UI Architecture**
- **Scope:** Create accurate runbook for current implementation
- **Affected Modules:** docs/web/RUNBOOK_WEB.txt
- **Steps:**
  1. Document actual app.py architecture (MCP + React)
  2. List actual API endpoints (from routes/)
  3. Document React UI build process
  4. Remove claims about features not present

**UI-DOCS-05: Fix start_web.py Documentation**
- **Scope:** Correct --mode argument documentation
- **Affected Modules:** docs/api/FASTAPI_README.md, start_web.py
- **Steps:**
  1. Remove --mode documentation or implement --mode argument
  2. Document actual start_web.py behavior (no args, port 8000)
  3. Clarify difference between start_web.py and start_api.py

---

## 6. SELF-REVIEW CHECKLIST

**Did I identify all UI entrypoints and their backing apps?**  
✅ **YES** - Identified start_web.py (primary), start_api.py (alternative), ucop_cli.py (CLI), job_cli.py (CLI), src/main.py (legacy)

**Did I clearly mark primary vs alternative vs unused UIs?**  
✅ **YES** - app.py (PRIMARY), app_unified.py (UNUSED), app_integrated.py (UNUSED), React UI (PRIMARY), Jinja2 templates (UNUSED)

**Did I classify mesh/realtime/visualization modules by actual usage, not assumptions?**  
✅ **YES** - Used grep to find actual imports:
- realtime: HOT PATH (used by app.py)
- mesh: OPTIONAL (only used by legacy main.py)
- visualization: OPTIONAL (CLI-only, not in primary web UI)

**Did I avoid changing production behaviour?**  
✅ **YES** - This is analysis only. No code changes made except creation of analysis helper script.

**Is the proposed follow-up task list concrete and actionable for future refactor tasks?**  
✅ **YES** - 14 specific task cards with clear scope, affected modules, and step-by-step actions.

---

## 7. ANALYSIS ARTIFACTS

### 7.1 Helper Scripts Created

**tools/ui_usage_scan.py**
- Purpose: Automated scanning of import patterns, entry points, UI implementations
- Usage: `python tools/ui_usage_scan.py`
- Output: Console report of file counts, imports, and UI analysis

### 7.2 Analysis Methodology

1. **File System Scan:** Used `view` and `bash_tool` to explore directory structures
2. **Import Analysis:** Used `grep -r` to find actual import relationships
3. **Entry Point Tracing:** Analyzed each entry point to understand execution flow
4. **Documentation Review:** Compared claims in docs/ against actual code implementation
5. **Cross-Reference:** Built truth-vs-reality table comparing docs to code

### 7.3 Key Findings

**Critical Discovery #1: Multiple Unused Web Apps**
- app_integrated.py (25KB) and app_unified.py (9KB) are NOT wired to any entry point
- Both have extensive features not present in primary app.py
- Neither is imported anywhere in production code

**Critical Discovery #2: Visualization Not Integrated**
- src/visualization/ has 129KB of code for debugging, monitoring, visualization
- Used by app_integrated.py (which is UNUSED)
- NOT integrated into primary web UI (app.py)
- Only available via CLI commands (ucop_cli.py)

**Critical Discovery #3: Mesh Infrastructure Unused**
- src/mesh/ has 169KB of distributed agent coordination code
- Only used by src/main.py (legacy entry point) and validation tools
- NOT used by primary runtime (start_web.py, ucop_cli.py)

**Critical Discovery #4: Documentation Mismatch**
- Docs claim visual workflow editor, debugger, breakpoints, flamegraph in web UI
- Reality: app.py is minimal (MCP + React UI serving)
- Advanced features exist but in unused app_integrated.py

---

## 8. RISK ASSESSMENT

### 8.1 High-Risk Areas

**Documentation Accuracy (Risk: HIGH)**
- Users may expect features (editor, debugger, flamegraph) that don't exist
- Could lead to confusion and support issues
- Mitigation: High-priority doc corrections (UI-DOCS-01 through UI-DOCS-05)

**Unused Code Maintenance (Risk: MEDIUM)**
- 34KB of unused web app code (app_unified.py + app_integrated.py)
- 129KB of partially-used visualization code
- 169KB of mostly-unused mesh code
- Increases maintenance burden, confuses contributors
- Mitigation: Archive unused code (UI-DEDUP-01, RUNTIME-MESH-01)

**Feature Loss Risk (Risk: LOW)**
- app_integrated.py has valuable debugging features
- Should extract before archiving
- Mitigation: UI-VIS-01, UI-VIS-02 (extract then archive)

### 8.2 Opportunities

**Clean Architecture**
- Once consolidated, will have clear single UI implementation (app.py + React)
- Easier to understand, maintain, extend

**Better Documentation**
- Accurate docs will reduce confusion
- Clear separation: app.py (web), ucop_cli.py (CLI), visualization (CLI-only or web TBD)

**Optional Feature Clarity**
- Mesh and visualization can be clearly marked as optional/experimental
- Or integrated if valuable
- Either way, clearer roles

---

## APPENDIX A: FILE STATISTICS

### Module Size Summary
- src/web: 392KB (13 files)
- src/orchestration: 354KB (22 files)
- src/mesh: 169KB (9 files)
- src/engine: 142KB (14 files)
- src/visualization: 129KB (6 files)
- src/realtime: 23KB (3 files)

### Entry Point Files
- start_web.py: 8KB
- start_api.py: 3.5KB
- ucop_cli.py: 39KB
- job_cli.py: 11KB
- src/main.py: 24KB

### Web App Files
- app.py: 4KB (PRIMARY)
- app_integrated.py: 25KB (UNUSED)
- app_unified.py: 9KB (UNUSED)

---

**END OF ANALYSIS REPORT**

**Generated:** 2025-11-13  
**Analyst:** Senior Python Engineer (Static Analysis)  
**Repository:** /mnt/data/project  
**Analysis Scope:** UI & Runtime Architecture  
**Methodology:** Import scanning, entry point tracing, doc comparison  
**Tools Used:** grep, view, bash, custom Python scanner (ui_usage_scan.py)  
