#!/usr/bin/env python3
"""Start the workflow editor web UI."""

import asyncio
import sys
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.web.app import create_app, set_global_executor
from src.engine.unified_engine import UnifiedEngine
from src.core.config import load_config
from src.core.enhanced_config import EnhancedConfigLoader
from src.core.event_bus import EventBus
from src.orchestration.hot_reload import HotReloadMonitor
from src.orchestration.agent_scanner import AgentScanner
from src.web.connection_manager import get_connection_manager
import uvicorn

logger = logging.getLogger(__name__)


def setup_hot_reload(event_bus, executor):
    """Setup hot reload monitor for config files.
    
    Args:
        event_bus: EventBus instance for notifications
        executor: Engine executor instance
        
    Returns:
        HotReloadMonitor instance
    """
    # Paths to monitor
    config_paths = [
        Path("config/agents.yaml"),
        Path("templates/workflows.yaml")
    ]
    
    # Create monitor
    monitor = HotReloadMonitor(
        paths=config_paths,
        event_bus=event_bus
    )
    
    # Create agent scanner
    scanner = AgentScanner()
    
    # Register callbacks
    def reload_agents(file_path, config_data):
        """Callback for agents.yaml reload."""
        logger.info(f"Reloading agents from {file_path}")
        try:
            # Trigger agent scanner reload
            agents = scanner.trigger_reload()
            logger.info(f"✓ Reloaded {len(agents)} agents")
            
            # Re-initialize executor if needed
            if executor and hasattr(executor, 'initialize_agents'):
                executor.initialize_agents()
                logger.info("✓ Executor agents re-initialized")
                
        except Exception as e:
            logger.error(f"Failed to reload agents: {e}", exc_info=True)
            raise
    
    def reload_workflows(file_path, config_data):
        """Callback for workflows.yaml reload."""
        logger.info(f"Reloading workflows from {file_path}")
        try:
            # Re-compile workflows
            if executor and hasattr(executor, 'reload_workflows'):
                executor.reload_workflows()
                logger.info("✓ Workflows reloaded")
        except Exception as e:
            logger.error(f"Failed to reload workflows: {e}", exc_info=True)
            raise
    
    # Register callbacks
    monitor.register_reload_callback("agents.yaml", reload_agents)
    monitor.register_reload_callback("workflows.yaml", reload_workflows)
    
    # Also register WebSocket notification callback
    async def notify_websocket_clients(event):
        """Notify WebSocket clients of config reload."""
        try:
            connection_manager = get_connection_manager()
            
            # Broadcast to all agent status clients
            await connection_manager.broadcast_agents({
                "type": "config.reloaded",
                "data": {
                    "file_path": str(event.file_path),
                    "config_type": event.config_type,
                    "success": event.success,
                    "error": event.error
                }
            })
            
            # Also broadcast to visual clients
            await connection_manager.broadcast_visual({
                "type": "config.reloaded",
                "data": {
                    "file_path": str(event.file_path),
                    "config_type": event.config_type,
                    "success": event.success
                }
            })
            
            logger.info(f"✓ WebSocket clients notified of config reload")
            
        except Exception as e:
            logger.warning(f"Failed to notify WebSocket clients: {e}")
    
    # Register WebSocket notification as async callback
    def sync_notify_wrapper(event):
        """Wrapper to handle async notification in sync context."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(notify_websocket_clients(event))
            else:
                loop.run_until_complete(notify_websocket_clients(event))
        except Exception as e:
            logger.warning(f"Failed to schedule WebSocket notification: {e}")
    
    monitor.callback = sync_notify_wrapper
    
    # Start monitoring
    monitor.start()
    logger.info("✓ Hot reload monitor started")
    logger.info(f"  Monitoring: {', '.join(str(p) for p in config_paths)}")
    
    return monitor


def main():
    """Main entry point for the web UI."""
    print("=" * 60)
    print("Workflow Editor - Web UI")
    print("=" * 60)
    print()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Load configuration
    print("Loading configuration...")
    try:
        # Try enhanced config first
        try:
            loader = EnhancedConfigLoader()
            config_snapshot = loader.get_snapshot()
            print(f"✓ Enhanced configuration loaded (hash: {config_snapshot.config_hash[:8]})")
        except Exception as e:
            print(f"⚠ Enhanced config failed, using basic config: {e}")
            config = load_config()
            config_snapshot = None
    except Exception as e:
        print(f"✗ Failed to load configuration: {e}")
        print("Continuing with limited functionality...")
        config_snapshot = None
    
    # Initialize event bus
    print("Initializing event bus...")
    event_bus = EventBus()
    print("✓ Event bus initialized")
    
    # Initialize unified engine
    print("Initializing execution engine...")
    try:
        executor = UnifiedEngine()
        print("✓ Execution engine initialized")
    except Exception as e:
        print(f"⚠ Failed to initialize engine: {e}")
        print("Some features may not work correctly")
        executor = None
    
    # Setup hot reload monitor
    print("Setting up hot reload monitor...")
    try:
        hot_reload_monitor = setup_hot_reload(event_bus, executor)
        print("✓ Hot reload monitor initialized and started")
    except Exception as e:
        print(f"⚠ Failed to setup hot reload: {e}")
        print("Config files will not auto-reload")
        hot_reload_monitor = None
    
    # Create app
    print("Creating web application...")
    app = create_app(executor, config_snapshot)
    print("✓ Web application created")
    
    # Check if UI is built
    static_dir = Path(__file__).parent / "src" / "web" / "static" / "dist"
    if not static_dir.exists():
        print()
        print("=" * 60)
        print("⚠ UI not built!")
        print("=" * 60)
        print("The React UI needs to be built before starting the server.")
        print()
        print("Please run these commands:")
        print("  cd src/web/static")
        print("  npm install")
        print("  npm run build")
        print("  cd ../../..")
        print("  python start_web.py")
        print()
        print("Starting server anyway for API access...")
        print("=" * 60)
        print()
    else:
        print("✓ UI build found")
    
    print()
    print("=" * 60)
    print("Starting server on http://localhost:8000")
    print("=" * 60)
    print()
    print("Press Ctrl+C to stop")
    print()
    
    if hot_reload_monitor:
        print("Hot reload is active - modify config files to see live reloading!")
        print()
    
    # Run server
    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            log_level="info",
            access_log=True,
        )
    except KeyboardInterrupt:
        print("\n\nShutting down...")
        
        # Stop hot reload monitor
        if hot_reload_monitor:
            print("Stopping hot reload monitor...")
            hot_reload_monitor.stop()
            print("✓ Hot reload monitor stopped")
        
        print("Goodbye!")


if __name__ == "__main__":
    main()
