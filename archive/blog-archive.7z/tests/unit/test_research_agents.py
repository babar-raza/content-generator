"""Unit tests for research agents using mocks.

Tests for TrendsResearchAgent, ContentIntelligenceAgent, and CompetitorAnalysisAgent.
These tests use mocks to avoid external dependencies and API calls.
"""

import unittest
from unittest.mock import Mock, MagicMock, patch, call
from datetime import datetime, timedelta
import json
import hashlib


class MockConfig:
    """Mock configuration object."""
    def __init__(self):
        self.rag_top_k = 10
        self.ollama_topic_model = "llama2"
        self.device = "cpu"
        self.embedding_batch_size = 8
        self.cache_dir = "/tmp/test_cache"


class MockEventBus:
    """Mock event bus for testing."""
    def __init__(self):
        self.subscriptions = {}
        self.published_events = []
    
    def subscribe(self, event_type, handler):
        """Subscribe to an event."""
        if event_type not in self.subscriptions:
            self.subscriptions[event_type] = []
        self.subscriptions[event_type].append(handler)
    
    def publish(self, event):
        """Publish an event."""
        self.published_events.append(event)


class MockAgentEvent:
    """Mock agent event."""
    def __init__(self, event_type, data, correlation_id="test-123"):
        self.event_type = event_type
        self.data = data
        self.correlation_id = correlation_id
        self.source_agent = None


class TestTrendsResearchAgent(unittest.TestCase):
    """Test cases for TrendsResearchAgent."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = MockConfig()
        self.event_bus = MockEventBus()
        self.trends_service = Mock()
        
        # Import agent
        from src.agents.research.trends_research import TrendsResearchAgent
        
        self.agent = TrendsResearchAgent(
            self.config,
            self.event_bus,
            self.trends_service
        )
    
    def test_initialization(self):
        """Test agent initializes correctly."""
        self.assertEqual(self.agent.agent_id, "TrendsResearchAgent")
        self.assertIsNotNone(self.agent.trends_service)
        self.assertEqual(len(self.agent._cache), 0)
    
    def test_contract_creation(self):
        """Test contract is created with correct schema."""
        contract = self.agent._create_contract()
        self.assertEqual(contract.agent_id, "TrendsResearchAgent")
        self.assertIn("trends_research", contract.capabilities)
        self.assertIn("keywords", contract.input_schema["required"])
        self.assertIn("trends", contract.output_schema["required"])
    
    def test_event_subscription(self):
        """Test agent subscribes to correct events."""
        self.assertIn("execute_trends_research", self.event_bus.subscriptions)
        self.assertIn("execute_keyword_analysis", self.event_bus.subscriptions)
    
    def test_cache_key_computation(self):
        """Test cache key is computed correctly."""
        keywords = ["python", "tutorial"]
        timeframe = "today 3-m"
        geo = "US"
        
        key1 = self.agent._compute_cache_key(keywords, timeframe, geo)
        key2 = self.agent._compute_cache_key(keywords, timeframe, geo)
        
        # Same inputs should produce same key
        self.assertEqual(key1, key2)
        
        # Different inputs should produce different key
        key3 = self.agent._compute_cache_key(["python"], timeframe, geo)
        self.assertNotEqual(key1, key3)
    
    def test_cache_operations(self):
        """Test cache save and retrieve."""
        cache_key = "test_key_123"
        data = {"test": "data"}
        
        # Save to cache
        self.agent._save_to_cache(cache_key, data)
        
        # Retrieve from cache
        cached_data = self.agent._get_from_cache(cache_key)
        self.assertEqual(cached_data, data)
        
        # Test cache expiration (by manually aging the entry)
        old_time = datetime.now() - timedelta(seconds=self.agent.CACHE_TTL + 1)
        self.agent._cache[cache_key] = (data, old_time)
        
        expired_data = self.agent._get_from_cache(cache_key)
        self.assertIsNone(expired_data)
    
    def test_execute_success(self):
        """Test successful trends research execution."""
        # Mock trends service responses
        self.trends_service.get_interest_over_time.return_value = {
            "keywords": ["python"],
            "timeframe": "today 3-m",
            "data": [
                {"date": "2024-01-01", "python": 50},
                {"date": "2024-01-02", "python": 55}
            ]
        }
        
        self.trends_service.get_related_queries.return_value = {
            "top": {
                "query": MagicMock(tolist=lambda: ["python tutorial", "python guide"])
            },
            "rising": {
                "query": MagicMock(tolist=lambda: ["python 3.11"])
            }
        }
        
        # Create test event
        event = MockAgentEvent(
            event_type="execute_trends_research",
            data={"keywords": ["python"]}
        )
        
        # Execute
        result = self.agent.execute(event)
        
        # Verify
        self.assertIsNotNone(result)
        self.assertEqual(result.event_type, "trends_research_complete")
        self.assertIn("keywords", result.data)
        self.assertIn("trends", result.data)
        self.assertIn("suggestions", result.data)
        self.assertEqual(result.data["keywords"], ["python"])
    
    def test_execute_with_cache(self):
        """Test execution uses cache when available."""
        # First execution to populate cache
        self.trends_service.get_interest_over_time.return_value = {
            "data": [{"python": 50}]
        }
        self.trends_service.get_related_queries.return_value = {}
        
        event = MockAgentEvent(
            event_type="execute_trends_research",
            data={"keywords": ["python"]}
        )
        
        result1 = self.agent.execute(event)
        call_count1 = self.trends_service.get_interest_over_time.call_count
        
        # Second execution should use cache
        result2 = self.agent.execute(event)
        call_count2 = self.trends_service.get_interest_over_time.call_count
        
        # Service should not be called again
        self.assertEqual(call_count1, call_count2)
        self.assertEqual(result1.data, result2.data)
    
    def test_execute_keyword_limit(self):
        """Test keyword limit enforcement (max 5)."""
        self.trends_service.get_interest_over_time.return_value = {"data": []}
        self.trends_service.get_related_queries.return_value = {}
        
        event = MockAgentEvent(
            event_type="execute_trends_research",
            data={"keywords": ["k1", "k2", "k3", "k4", "k5", "k6", "k7"]}
        )
        
        result = self.agent.execute(event)
        
        # Should limit to 5 keywords
        self.assertEqual(len(result.data["keywords"]), 5)
    
    def test_execute_no_keywords(self):
        """Test execution fails gracefully with no keywords."""
        event = MockAgentEvent(
            event_type="execute_trends_research",
            data={"keywords": []}
        )
        
        result = self.agent.execute(event)
        
        self.assertEqual(result.event_type, "trends_research_failed")
        self.assertIn("error", result.data)
    
    def test_execute_error_handling(self):
        """Test error handling during execution."""
        self.trends_service.get_interest_over_time.side_effect = Exception("API Error")
        
        event = MockAgentEvent(
            event_type="execute_trends_research",
            data={"keywords": ["python"]}
        )
        
        result = self.agent.execute(event)
        
        self.assertEqual(result.event_type, "trends_research_failed")
        self.assertIn("error", result.data)


class TestContentIntelligenceAgent(unittest.TestCase):
    """Test cases for ContentIntelligenceAgent."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = MockConfig()
        self.event_bus = MockEventBus()
        self.embedding_service = Mock()
        self.database_service = Mock()
        
        # Import agent
        from src.agents.research.content_intelligence import ContentIntelligenceAgent
        
        self.agent = ContentIntelligenceAgent(
            self.config,
            self.event_bus,
            self.embedding_service,
            self.database_service
        )
    
    def test_initialization(self):
        """Test agent initializes correctly."""
        self.assertEqual(self.agent.agent_id, "ContentIntelligenceAgent")
        self.assertIsNotNone(self.agent.embedding_service)
        self.assertIsNotNone(self.agent.database_service)
    
    def test_contract_creation(self):
        """Test contract is created with correct schema."""
        contract = self.agent._create_contract()
        self.assertEqual(contract.agent_id, "ContentIntelligenceAgent")
        self.assertIn("content_analysis", contract.capabilities)
        self.assertIn("content", contract.input_schema["required"])
        self.assertIn("related", contract.output_schema["required"])
    
    def test_event_subscription(self):
        """Test agent subscribes to correct events."""
        self.assertIn("execute_content_intelligence", self.event_bus.subscriptions)
        self.assertIn("execute_semantic_search", self.event_bus.subscriptions)
    
    def test_extract_topics_simple(self):
        """Test simple topic extraction."""
        content = """
        This is a tutorial about Python file I/O operations.
        We'll cover System.IO namespace and JSON parsing.
        HTTP requests are also important for REST API development.
        """
        
        topics = self.agent._extract_topics_simple(content)
        
        self.assertIsInstance(topics, list)
        self.assertGreater(len(topics), 0)
    
    def test_extract_entities(self):
        """Test entity extraction."""
        content = "Python tutorial by John Smith about Microsoft Azure."
        
        entities = self.agent._extract_entities(content)
        
        self.assertIsInstance(entities, list)
        self.assertIn("Python", entities)
        self.assertIn("John Smith", entities)
    
    def test_execute_success(self):
        """Test successful content intelligence execution."""
        # Mock embedding service
        self.embedding_service.encode.return_value = [[0.1] * 384]
        
        # Mock database service
        self.database_service.query_by_embedding.return_value = {
            "documents": [[
                "Related document 1 content...",
                "Related document 2 content..."
            ]],
            "distances": [[0.2, 0.3]],
            "metadatas": [[
                {"title": "Related 1", "url": "/doc1"},
                {"title": "Related 2", "url": "/doc2"}
            ]]
        }
        
        # Create test event
        event = MockAgentEvent(
            event_type="execute_content_intelligence",
            data={
                "content": "This is a comprehensive tutorial about Python programming " * 10
            }
        )
        
        # Execute
        result = self.agent.execute(event)
        
        # Verify
        self.assertIsNotNone(result)
        self.assertEqual(result.event_type, "content_intelligence_complete")
        self.assertIn("related", result.data)
        self.assertIn("topics", result.data)
        self.assertIn("links", result.data)
    
    def test_execute_short_content(self):
        """Test execution fails with too short content."""
        event = MockAgentEvent(
            event_type="execute_content_intelligence",
            data={"content": "Short"}
        )
        
        result = self.agent.execute(event)
        
        self.assertEqual(result.event_type, "content_intelligence_failed")
        self.assertIn("error", result.data)
    
    def test_find_related_content(self):
        """Test finding related content."""
        self.embedding_service.encode.return_value = [[0.1] * 384]
        self.database_service.query_by_embedding.return_value = {
            "documents": [["Related content"]],
            "distances": [[0.2]],
            "metadatas": [[{"title": "Related"}]]
        }
        
        content = "Python tutorial content " * 20
        related = self.agent._find_related_content(content, max_results=5)
        
        self.assertIsInstance(related, list)
    
    def test_cache_operations(self):
        """Test cache functionality."""
        cache_key = "test_key"
        data = {"test": "data"}
        
        self.agent._save_to_cache(cache_key, data)
        cached = self.agent._get_from_cache(cache_key)
        
        self.assertEqual(cached, data)


class TestCompetitorAnalysisAgent(unittest.TestCase):
    """Test cases for CompetitorAnalysisAgent."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = MockConfig()
        self.event_bus = MockEventBus()
        self.database_service = Mock()
        self.trends_service = Mock()
        
        # Import agent
        from src.agents.research.competitor_analysis import CompetitorAnalysisAgent
        
        self.agent = CompetitorAnalysisAgent(
            self.config,
            self.event_bus,
            self.database_service,
            self.trends_service
        )
    
    def test_initialization(self):
        """Test agent initializes correctly."""
        self.assertEqual(self.agent.agent_id, "CompetitorAnalysisAgent")
        self.assertIsNotNone(self.agent.database_service)
    
    def test_contract_creation(self):
        """Test contract is created with correct schema."""
        contract = self.agent._create_contract()
        self.assertEqual(contract.agent_id, "CompetitorAnalysisAgent")
        self.assertIn("competitor_analysis", contract.capabilities)
        self.assertIn("keyword", contract.input_schema["required"])
        self.assertIn("top_results", contract.output_schema["required"])
    
    def test_event_subscription(self):
        """Test agent subscribes to correct events."""
        self.assertIn("execute_competitor_analysis", self.event_bus.subscriptions)
        self.assertIn("execute_content_gap_analysis", self.event_bus.subscriptions)
    
    def test_simulate_search_results(self):
        """Test search result simulation."""
        # Mock database responses
        self.database_service.query.return_value = {
            "documents": [[
                "Python tutorial content...",
                "Python guide content..."
            ]],
            "metadatas": [[
                {"title": "Tutorial 1", "url": "/tutorial1"},
                {"title": "Tutorial 2", "url": "/tutorial2"}
            ]],
            "distances": [[0.1, 0.2]]
        }
        
        results = self.agent._simulate_search_results("python tutorial", top_n=5)
        
        self.assertIsInstance(results, list)
        self.assertLessEqual(len(results), 5)
    
    def test_extract_topics_from_results(self):
        """Test topic extraction from results."""
        results = [
            {
                "rank": 1,
                "content": "Python tutorial about file I/O operations and JSON parsing",
                "title": "Python I/O"
            },
            {
                "rank": 2,
                "content": "Learn Python file operations and data handling",
                "title": "Python Files"
            }
        ]
        
        topics = self.agent._extract_topics_from_results(results)
        
        self.assertIsInstance(topics, list)
        self.assertGreater(len(topics), 0)
        
        # Check topic structure
        if topics:
            self.assertIn("topic", topics[0])
            self.assertIn("frequency", topics[0])
            self.assertIn("coverage", topics[0])
    
    def test_analyze_content_structure(self):
        """Test content structure analysis."""
        results = [
            {
                "content": """
                # Introduction
                Python is great.
                
                ## File Operations
                ```python
                with open('file.txt') as f:
                    data = f.read()
                ```
                
                - Item 1
                - Item 2
                """
            },
            {
                "content": """
                # Getting Started
                Learn the basics.
                
                ```python
                print('hello')
                ```
                """
            }
        ]
        
        structure = self.agent._analyze_content_structure(results)
        
        self.assertIsInstance(structure, dict)
        self.assertIn("average_length", structure)
        self.assertIn("common_sections", structure)
        self.assertIn("code_examples_count", structure)
    
    def test_identify_content_gaps(self):
        """Test content gap identification."""
        keyword = "python tutorial"
        results = [
            {"content": "Python basics"},
            {"content": "Python advanced"}
        ]
        common_topics = [
            {"topic": "Python", "coverage": 1.0, "frequency": 2},
            {"topic": "basics", "coverage": 0.5, "frequency": 1}
        ]
        
        gaps = self.agent._identify_content_gaps(keyword, results, common_topics)
        
        self.assertIsInstance(gaps, list)
        
        # Check gap structure
        if gaps:
            self.assertIn("type", gaps[0])
            self.assertIn("priority", gaps[0])
            self.assertIn("opportunity", gaps[0])
    
    def test_generate_recommendations(self):
        """Test recommendation generation."""
        keyword = "python tutorial"
        gaps = [
            {
                "type": "code_examples",
                "priority": "high",
                "opportunity": "Add more code examples"
            }
        ]
        common_topics = [
            {"topic": "Python", "frequency": 5}
        ]
        structure = {
            "average_length": 2000,
            "code_examples_count": 3
        }
        
        recommendations = self.agent._generate_recommendations(
            keyword, gaps, common_topics, structure
        )
        
        self.assertIsInstance(recommendations, list)
        self.assertGreater(len(recommendations), 0)
    
    def test_execute_success(self):
        """Test successful competitor analysis execution."""
        # Mock database service
        self.database_service.query.return_value = {
            "documents": [[
                "Python tutorial content with file I/O operations " * 10
            ]],
            "metadatas": [[{"title": "Tutorial", "url": "/tutorial"}]],
            "distances": [[0.1]]
        }
        
        # Create test event
        event = MockAgentEvent(
            event_type="execute_competitor_analysis",
            data={"keyword": "python tutorial"}
        )
        
        # Execute
        result = self.agent.execute(event)
        
        # Verify
        self.assertIsNotNone(result)
        self.assertEqual(result.event_type, "competitor_analysis_complete")
        self.assertIn("top_results", result.data)
        self.assertIn("common_topics", result.data)
        self.assertIn("gaps", result.data)
        self.assertIn("recommendations", result.data)
    
    def test_execute_no_keyword(self):
        """Test execution fails with invalid keyword."""
        event = MockAgentEvent(
            event_type="execute_competitor_analysis",
            data={"keyword": ""}
        )
        
        result = self.agent.execute(event)
        
        self.assertEqual(result.event_type, "competitor_analysis_failed")
        self.assertIn("error", result.data)
    
    def test_execute_no_results(self):
        """Test execution handles no results gracefully."""
        self.database_service.query.return_value = {
            "documents": [[]],
            "metadatas": [[]],
            "distances": [[]]
        }
        
        event = MockAgentEvent(
            event_type="execute_competitor_analysis",
            data={"keyword": "obscure keyword"}
        )
        
        result = self.agent.execute(event)
        
        # Should return empty but valid result
        self.assertEqual(result.event_type, "competitor_analysis_complete")
        self.assertEqual(len(result.data["top_results"]), 0)
    
    def test_cache_operations(self):
        """Test cache functionality."""
        cache_key = "test_key"
        data = {"test": "data"}
        
        self.agent._save_to_cache(cache_key, data)
        cached = self.agent._get_from_cache(cache_key)
        
        self.assertEqual(cached, data)


class TestIntegration(unittest.TestCase):
    """Integration tests for research agents."""
    
    def test_all_agents_can_be_imported(self):
        """Test that all agents can be imported from research package."""
        from src.agents.research import (
            TrendsResearchAgent,
            ContentIntelligenceAgent,
            CompetitorAnalysisAgent
        )
        
        self.assertIsNotNone(TrendsResearchAgent)
        self.assertIsNotNone(ContentIntelligenceAgent)
        self.assertIsNotNone(CompetitorAnalysisAgent)
    
    def test_agents_have_execute_method(self):
        """Test that all agents have execute method with correct signature."""
        from src.agents.research import (
            TrendsResearchAgent,
            ContentIntelligenceAgent,
            CompetitorAnalysisAgent
        )
        
        config = MockConfig()
        event_bus = MockEventBus()
        
        # Create mock services
        trends_service = Mock()
        embedding_service = Mock()
        database_service = Mock()
        
        # Instantiate agents
        trends_agent = TrendsResearchAgent(config, event_bus, trends_service)
        content_agent = ContentIntelligenceAgent(
            config, event_bus, embedding_service, database_service
        )
        competitor_agent = CompetitorAnalysisAgent(
            config, event_bus, database_service
        )
        
        # Check execute method exists
        self.assertTrue(hasattr(trends_agent, 'execute'))
        self.assertTrue(hasattr(content_agent, 'execute'))
        self.assertTrue(hasattr(competitor_agent, 'execute'))
        
        # Check execute is callable
        self.assertTrue(callable(trends_agent.execute))
        self.assertTrue(callable(content_agent.execute))
        self.assertTrue(callable(competitor_agent.execute))


if __name__ == '__main__':
    unittest.main()
