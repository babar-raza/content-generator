"""Tests for complete service implementations."""

import pytest
from unittest.mock import Mock, patch, MagicMock
from concurrent.futures import ThreadPoolExecutor
import numpy as np

from src.core.config import Config
from src.services.services import (
    GistService,
    TrendsService,
    EmbeddingService,
    DatabaseService,
    LinkChecker,
)


class TestGistServiceCRUD:
    """Test GistService CRUD operations."""
    
    @pytest.fixture
    def config(self):
        """Create test configuration."""
        config = Config()
        config.github_gist_token = "test-token"
        config.gist_upload_enabled = True
        return config
    
    def test_create_gist_success(self, config):
        """Test successful Gist creation."""
        with patch('src.services.services.requests.post') as mock_post:
            mock_post.return_value = Mock(
                status_code=201,
                json=lambda: {
                    "html_url": "https://gist.github.com/test123",
                    "id": "test123"
                }
            )
            
            service = GistService(config)
            result = service.create_gist("test.py", "print('hello')", "Test gist")
            
            assert result == "https://gist.github.com/test123"
            mock_post.assert_called_once()
    
    def test_create_gist_empty_filename(self, config):
        """Test Gist creation fails with empty filename."""
        service = GistService(config)
        result = service.create_gist("", "content")
        assert result is None
    
    def test_create_gist_empty_content(self, config):
        """Test Gist creation fails with empty content."""
        service = GistService(config)
        result = service.create_gist("test.py", "")
        assert result is None
    
    def test_get_gist_success(self, config):
        """Test successful Gist retrieval."""
        with patch('src.services.services.requests.get') as mock_get:
            mock_get.return_value = Mock(
                status_code=200,
                json=lambda: {
                    "id": "test123",
                    "description": "Test gist",
                    "files": {
                        "test.py": {
                            "content": "print('hello')"
                        }
                    }
                }
            )
            
            service = GistService(config)
            result = service.get_gist("test123")
            
            assert result is not None
            assert result["id"] == "test123"
            mock_get.assert_called_once()
    
    def test_get_gist_not_found(self, config):
        """Test Gist retrieval with 404."""
        with patch('src.services.services.requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 404
            mock_response.raise_for_status.side_effect = Exception("Not found")
            mock_get.return_value = mock_response
            
            service = GistService(config)
            result = service.get_gist("nonexistent")
            
            assert result is None
    
    def test_get_gist_empty_id(self, config):
        """Test Gist retrieval fails with empty ID."""
        service = GistService(config)
        result = service.get_gist("")
        assert result is None
    
    def test_update_gist_success(self, config):
        """Test successful Gist update."""
        with patch('src.services.services.requests.patch') as mock_patch:
            mock_patch.return_value = Mock(
                status_code=200,
                json=lambda: {
                    "id": "test123",
                    "description": "Updated",
                    "files": {
                        "test.py": {
                            "content": "print('updated')"
                        }
                    }
                }
            )
            
            service = GistService(config)
            result = service.update_gist("test123", "test.py", "print('updated')")
            
            assert result is not None
            assert result["description"] == "Updated"
            mock_patch.assert_called_once()
    
    def test_update_gist_with_description(self, config):
        """Test Gist update with new description."""
        with patch('src.services.services.requests.patch') as mock_patch:
            mock_patch.return_value = Mock(
                status_code=200,
                json=lambda: {"id": "test123", "description": "New desc"}
            )
            
            service = GistService(config)
            result = service.update_gist("test123", "test.py", "content", "New desc")
            
            assert result is not None
            # Verify description was included in payload
            call_args = mock_patch.call_args
            payload = call_args[1]['json']
            assert payload['description'] == "New desc"
    
    def test_update_gist_empty_id(self, config):
        """Test Gist update fails with empty ID."""
        service = GistService(config)
        result = service.update_gist("", "test.py", "content")
        assert result is None
    
    def test_update_gist_not_found(self, config):
        """Test Gist update with non-existent ID."""
        with patch('src.services.services.requests.patch') as mock_patch:
            mock_response = Mock()
            mock_response.status_code = 404
            mock_response.raise_for_status.side_effect = Exception("Not found")
            mock_patch.return_value = mock_response
            
            service = GistService(config)
            result = service.update_gist("nonexistent", "test.py", "content")
            
            assert result is None
    
    def test_delete_gist_success(self, config):
        """Test successful Gist deletion."""
        with patch('src.services.services.requests.delete') as mock_delete:
            mock_delete.return_value = Mock(status_code=204)
            
            service = GistService(config)
            result = service.delete_gist("test123")
            
            assert result is True
            mock_delete.assert_called_once()
    
    def test_delete_gist_empty_id(self, config):
        """Test Gist deletion fails with empty ID."""
        service = GistService(config)
        result = service.delete_gist("")
        assert result is False
    
    def test_delete_gist_not_found(self, config):
        """Test Gist deletion with non-existent ID."""
        with patch('src.services.services.requests.delete') as mock_delete:
            mock_response = Mock()
            mock_response.status_code = 404
            mock_response.raise_for_status.side_effect = Exception("Not found")
            mock_delete.return_value = mock_response
            
            service = GistService(config)
            result = service.delete_gist("nonexistent")
            
            assert result is False
    
    def test_gist_disabled(self):
        """Test Gist service when disabled."""
        config = Config()
        config.github_gist_token = None
        config.gist_upload_enabled = False
        
        service = GistService(config)
        
        assert service.create_gist("test.py", "content") is None
        assert service.get_gist("test123") is None
        assert service.update_gist("test123", "test.py", "content") is None
        assert service.delete_gist("test123") is False


class TestTrendsServiceComplete:
    """Test TrendsService with get_trending_searches."""
    
    @pytest.fixture
    def config(self):
        """Create test configuration."""
        return Config()
    
    @patch('src.services.services.PYTRENDS_AVAILABLE', True)
    @patch('src.services.services.TrendReq')
    def test_get_trending_searches_success(self, mock_trendreq, config):
        """Test successful trending searches retrieval."""
        import pandas as pd
        
        mock_pytrends = MagicMock()
        mock_pytrends.trending_searches.return_value = pd.DataFrame({
            0: ['trend1', 'trend2', 'trend3']
        })
        mock_trendreq.return_value = mock_pytrends
        
        service = TrendsService(config)
        result = service.get_trending_searches('united_states')
        
        assert result is not None
        assert len(result) == 3
        mock_pytrends.trending_searches.assert_called_once_with(pn='united_states')
    
    @patch('src.services.services.PYTRENDS_AVAILABLE', True)
    @patch('src.services.services.TrendReq')
    def test_get_trending_searches_empty_geo(self, mock_trendreq, config):
        """Test trending searches with empty geo."""
        mock_pytrends = MagicMock()
        mock_trendreq.return_value = mock_pytrends
        
        service = TrendsService(config)
        result = service.get_trending_searches('')
        
        assert result is None
        mock_pytrends.trending_searches.assert_not_called()
    
    @patch('src.services.services.PYTRENDS_AVAILABLE', True)
    @patch('src.services.services.TrendReq')
    def test_get_trending_searches_error(self, mock_trendreq, config):
        """Test trending searches with API error."""
        mock_pytrends = MagicMock()
        mock_pytrends.trending_searches.side_effect = Exception("API error")
        mock_trendreq.return_value = mock_pytrends
        
        service = TrendsService(config)
        result = service.get_trending_searches('united_states')
        
        assert result is None


class TestEmbeddingServiceWrapper:
    """Test EmbeddingService encode wrapper and dimension."""
    
    @pytest.fixture
    def config(self):
        """Create test configuration."""
        config = Config()
        config.embedding_model = 'all-MiniLM-L6-v2'
        config.device = 'cpu'
        return config
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    def test_encode_single_text(self, mock_transformer, config):
        """Test encoding single text returns single embedding."""
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([[0.1, 0.2, 0.3]])
        mock_transformer.return_value = mock_model
        
        service = EmbeddingService(config)
        result = service.encode("test text")
        
        # Should return list (not list of lists) for single text
        assert isinstance(result, list)
        assert len(result) == 3
        assert result == [0.1, 0.2, 0.3]
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    def test_encode_multiple_texts(self, mock_transformer, config):
        """Test encoding multiple texts returns list of embeddings."""
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([
            [0.1, 0.2, 0.3],
            [0.4, 0.5, 0.6]
        ])
        mock_transformer.return_value = mock_model
        
        service = EmbeddingService(config)
        result = service.encode(["text1", "text2"])
        
        # Should return list of lists for multiple texts
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] == [0.1, 0.2, 0.3]
        assert result[1] == [0.4, 0.5, 0.6]
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    def test_encode_empty_text(self, mock_transformer, config):
        """Test encoding empty text returns empty list."""
        mock_model = MagicMock()
        mock_transformer.return_value = mock_model
        
        service = EmbeddingService(config)
        result = service.encode("")
        
        assert result == []
        mock_model.encode.assert_not_called()
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    def test_encode_empty_list(self, mock_transformer, config):
        """Test encoding empty list returns empty list."""
        mock_model = MagicMock()
        mock_transformer.return_value = mock_model
        
        service = EmbeddingService(config)
        result = service.encode([])
        
        assert result == []
        mock_model.encode.assert_not_called()
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    def test_get_dimension(self, mock_transformer, config):
        """Test get_dimension returns correct value."""
        mock_model = MagicMock()
        mock_model.get_sentence_embedding_dimension.return_value = 384
        mock_transformer.return_value = mock_model
        
        service = EmbeddingService(config)
        dimension = service.get_dimension()
        
        assert dimension == 384
        mock_model.get_sentence_embedding_dimension.assert_called_once()


class TestDatabaseServiceEmbeddings:
    """Test DatabaseService with provided embeddings."""
    
    @pytest.fixture
    def config(self, tmp_path):
        """Create test configuration."""
        config = Config()
        config.database.chroma_db_path = str(tmp_path / "test_chroma")
        return config
    
    @patch('src.services.services.CHROMADB_AVAILABLE', True)
    @patch('src.services.services.chromadb.PersistentClient')
    def test_add_documents_with_embeddings(self, mock_client, config):
        """Test adding documents with pre-computed embeddings."""
        # Mock ChromaDB collection
        mock_collection = MagicMock()
        mock_chroma_instance = MagicMock()
        mock_chroma_instance.get_or_create_collection.return_value = mock_collection
        mock_client.return_value = mock_chroma_instance
        
        service = DatabaseService(config)
        
        # Prepare test data
        documents = ["doc1", "doc2"]
        ids = ["id1", "id2"]
        embeddings = [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]
        
        # Add documents with embeddings
        service.add_documents(
            documents=documents,
            ids=ids,
            embeddings=embeddings
        )
        
        # Verify collection.add was called with embeddings
        mock_collection.add.assert_called_once()
        call_args = mock_collection.add.call_args
        assert call_args[1]['embeddings'] == embeddings
        assert call_args[1]['documents'] == documents
        assert call_args[1]['ids'] == ids
    
    @patch('src.services.services.CHROMADB_AVAILABLE', True)
    @patch('src.services.services.chromadb.PersistentClient')
    def test_add_documents_without_embeddings(self, mock_client, config):
        """Test adding documents without embeddings."""
        # Mock ChromaDB collection
        mock_collection = MagicMock()
        mock_chroma_instance = MagicMock()
        mock_chroma_instance.get_or_create_collection.return_value = mock_collection
        mock_client.return_value = mock_chroma_instance
        
        service = DatabaseService(config)
        
        # Prepare test data without embeddings
        documents = ["doc1", "doc2"]
        ids = ["id1", "id2"]
        
        # Add documents without embeddings
        service.add_documents(
            documents=documents,
            ids=ids,
            embeddings=None
        )
        
        # Verify collection.add was called with None embeddings
        mock_collection.add.assert_called_once()
        call_args = mock_collection.add.call_args
        assert call_args[1]['embeddings'] is None
        assert call_args[1]['documents'] == documents
        assert call_args[1]['ids'] == ids
    
    @patch('src.services.services.CHROMADB_AVAILABLE', True)
    @patch('src.services.services.chromadb.PersistentClient')
    def test_add_documents_with_metadata(self, mock_client, config):
        """Test adding documents with embeddings and metadata."""
        # Mock ChromaDB collection
        mock_collection = MagicMock()
        mock_chroma_instance = MagicMock()
        mock_chroma_instance.get_or_create_collection.return_value = mock_collection
        mock_client.return_value = mock_chroma_instance
        
        service = DatabaseService(config)
        
        # Prepare test data
        documents = ["doc1"]
        ids = ["id1"]
        embeddings = [[0.1, 0.2, 0.3]]
        metadatas = [{"source": "test"}]
        
        # Add documents
        service.add_documents(
            documents=documents,
            ids=ids,
            embeddings=embeddings,
            metadatas=metadatas
        )
        
        # Verify all data was passed
        mock_collection.add.assert_called_once()
        call_args = mock_collection.add.call_args
        assert call_args[1]['embeddings'] == embeddings
        assert call_args[1]['metadatas'] == metadatas


class TestLinkCheckerParallel:
    """Test LinkChecker parallel execution and GET fallback."""
    
    @pytest.fixture
    def config(self):
        """Create test configuration."""
        config = Config()
        config.link_check_timeout = 5
        config.link_check_workers = 5
        return config
    
    @patch('src.services.services.requests.head')
    def test_check_url_head_success(self, mock_head, config):
        """Test URL check with successful HEAD request."""
        mock_head.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("https://example.com")
        
        assert is_valid is True
        assert status == 200
        assert msg == "OK"
        mock_head.assert_called_once()
    
    @patch('src.services.services.requests.head')
    @patch('src.services.services.requests.get')
    def test_check_url_head_405_fallback_to_get(self, mock_get, mock_head, config):
        """Test HEAD 405 falls back to GET."""
        mock_head.return_value = Mock(status_code=405)
        mock_get.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("https://example.com")
        
        assert is_valid is True
        assert status == 200
        # Should have tried HEAD first, then GET
        mock_head.assert_called_once()
        mock_get.assert_called_once()
    
    @patch('src.services.services.requests.head')
    @patch('src.services.services.requests.get')
    def test_check_url_head_fails_fallback_to_get(self, mock_get, mock_head, config):
        """Test HEAD failure falls back to GET."""
        mock_head.side_effect = Exception("HEAD failed")
        mock_get.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("https://example.com")
        
        assert is_valid is True
        assert status == 200
        mock_head.assert_called_once()
        mock_get.assert_called_once()
    
    @patch('src.services.services.requests.get')
    def test_check_url_get_method_direct(self, mock_get, config):
        """Test direct GET method call."""
        mock_get.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("https://example.com", method='GET')
        
        assert is_valid is True
        assert status == 200
        mock_get.assert_called_once()
    
    @patch('src.services.services.requests.head')
    def test_check_urls_parallel(self, mock_head, config):
        """Test parallel URL checking."""
        mock_head.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        urls = [f"https://example{i}.com" for i in range(5)]
        
        results = service.check_urls(urls, parallel=True, max_workers=3)
        
        assert len(results) == 5
        # Verify all URLs were checked
        for url in urls:
            assert url in results
            assert results[url][0] is True  # is_valid
            assert results[url][1] == 200  # status_code
    
    @patch('src.services.services.requests.head')
    def test_check_urls_sequential(self, mock_head, config):
        """Test sequential URL checking."""
        mock_head.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        urls = ["https://example1.com", "https://example2.com"]
        
        results = service.check_urls(urls, parallel=False)
        
        assert len(results) == 2
        for url in urls:
            assert url in results
            assert results[url][0] is True
    
    @patch('src.services.services.requests.head')
    @patch('src.services.services.requests.get')
    def test_check_urls_parallel_with_fallback(self, mock_get, mock_head, config):
        """Test parallel checking with GET fallback for some URLs."""
        # First URL: HEAD succeeds
        # Second URL: HEAD fails, GET succeeds
        def head_side_effect(url, **kwargs):
            if "example1" in url:
                return Mock(status_code=200)
            else:
                raise Exception("HEAD not supported")
        
        mock_head.side_effect = head_side_effect
        mock_get.return_value = Mock(status_code=200)
        
        service = LinkChecker(config)
        urls = ["https://example1.com", "https://example2.com"]
        
        results = service.check_urls(urls, parallel=True)
        
        assert len(results) == 2
        # Both should succeed (one via HEAD, one via GET fallback)
        assert results["https://example1.com"][0] is True
        assert results["https://example2.com"][0] is True
    
    def test_check_urls_empty_list(self, config):
        """Test checking empty URL list."""
        service = LinkChecker(config)
        results = service.check_urls([])
        
        assert results == {}
    
    def test_check_urls_filters_empty(self, config):
        """Test checking URL list filters empty strings."""
        service = LinkChecker(config)
        urls = ["", "  ", None]
        results = service.check_urls(urls)
        
        assert results == {}
    
    def test_check_url_invalid_scheme(self, config):
        """Test URL with invalid scheme."""
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("ftp://example.com")
        
        assert is_valid is False
        assert status == 0
        assert msg == "Invalid URL scheme"
    
    def test_check_url_empty(self, config):
        """Test empty URL."""
        service = LinkChecker(config)
        is_valid, status, msg = service.check_url("")
        
        assert is_valid is False
        assert status == 0
        assert msg == "Empty URL"


class TestIntegrationServicesComplete:
    """Integration tests for complete service implementations."""
    
    @pytest.fixture
    def config(self, tmp_path):
        """Create test configuration."""
        config = Config()
        config.cache_dir = str(tmp_path / "cache")
        config.database.chroma_db_path = str(tmp_path / "chroma")
        config.github_gist_token = "test-token"
        config.gist_upload_enabled = True
        config.embedding_model = 'all-MiniLM-L6-v2'
        config.device = 'cpu'
        config.link_check_timeout = 5
        config.link_check_workers = 3
        return config
    
    @patch('src.services.services.requests.post')
    @patch('src.services.services.requests.get')
    def test_gist_crud_workflow(self, mock_get, mock_post, config):
        """Test complete Gist CRUD workflow."""
        # Create
        mock_post.return_value = Mock(
            status_code=201,
            json=lambda: {"html_url": "https://gist.github.com/test123", "id": "test123"}
        )
        
        service = GistService(config)
        create_result = service.create_gist("test.py", "print('hello')")
        assert create_result is not None
        
        # Read
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {"id": "test123", "files": {"test.py": {"content": "print('hello')"}}}
        )
        
        get_result = service.get_gist("test123")
        assert get_result is not None
        assert get_result["id"] == "test123"
    
    @patch('src.services.services.SENTENCE_TRANSFORMERS_AVAILABLE', True)
    @patch('src.services.services.CHROMADB_AVAILABLE', True)
    @patch('src.services.services.SentenceTransformer')
    @patch('src.services.services.chromadb.PersistentClient')
    def test_embedding_database_integration(
        self, mock_client, mock_transformer, config
    ):
        """Test EmbeddingService and DatabaseService integration."""
        # Setup embedding service
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
        mock_model.get_sentence_embedding_dimension.return_value = 3
        mock_transformer.return_value = mock_model
        
        embedding_service = EmbeddingService(config)
        
        # Generate embeddings
        texts = ["text1", "text2"]
        embeddings = embedding_service.encode(texts)
        
        assert len(embeddings) == 2
        assert embedding_service.get_dimension() == 3
        
        # Setup database service
        mock_collection = MagicMock()
        mock_chroma_instance = MagicMock()
        mock_chroma_instance.get_or_create_collection.return_value = mock_collection
        mock_client.return_value = mock_chroma_instance
        
        db_service = DatabaseService(config)
        
        # Store with embeddings
        db_service.add_documents(
            documents=texts,
            ids=["id1", "id2"],
            embeddings=embeddings
        )
        
        # Verify embeddings were stored
        mock_collection.add.assert_called_once()
        call_args = mock_collection.add.call_args
        assert call_args[1]['embeddings'] == embeddings
    
    @patch('src.services.services.requests.head')
    def test_link_checker_batch_parallel(self, mock_head, config):
        """Test link checker handles batch of URLs in parallel."""
        # Simulate some successes and some failures
        def head_side_effect(url, **kwargs):
            if "good" in url:
                return Mock(status_code=200)
            else:
                return Mock(status_code=404)
        
        mock_head.side_effect = head_side_effect
        
        service = LinkChecker(config)
        urls = [
            "https://good1.com",
            "https://bad1.com",
            "https://good2.com",
            "https://bad2.com"
        ]
        
        results = service.check_urls(urls, parallel=True, max_workers=2)
        
        assert len(results) == 4
        assert results["https://good1.com"][0] is True
        assert results["https://bad1.com"][0] is False
        assert results["https://good2.com"][0] is True
        assert results["https://bad2.com"][0] is False
