"""Quick import test for services module."""

try:
    from src.services import LLMService, DatabaseService, EmbeddingService, GistService, LinkChecker, TrendsService
    print("✓ All services imported successfully")
    print(f"  - LLMService: {LLMService}")
    print(f"  - DatabaseService: {DatabaseService}")
    print(f"  - EmbeddingService: {EmbeddingService}")
    print(f"  - GistService: {GistService}")
    print(f"  - LinkChecker: {LinkChecker}")
    print(f"  - TrendsService: {TrendsService}")
except Exception as e:
    print(f"✗ Import failed: {e}")
    import traceback
    traceback.print_exc()
# DOCGEN:LLM-FIRST@v4