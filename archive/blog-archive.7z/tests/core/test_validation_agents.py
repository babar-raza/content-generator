"""Test runbook for ValidationAgent and QualityGateAgent.

This script verifies that the agents can be imported and executed correctly.
"""

import sys
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

print("=" * 70)
print("VALIDATION AGENTS TEST RUNBOOK")
print("=" * 70)

# Test 1: Import agents
print("\n1. Testing imports...")
try:
    from src.agents.support import ValidationAgent, QualityGateAgent
    from src.core.config import Config
    from src.core.event_bus import EventBus
    from src.core.contracts import AgentEvent
    print("   ✓ All imports successful")
except Exception as e:
    print(f"   ✗ Import failed: {e}")
    sys.exit(1)

# Test 2: Initialize mock config and event bus
print("\n2. Initializing mock config and event bus...")
try:
    class MockConfig:
        def __init__(self):
            self.data = {}
    
    config = MockConfig()
    event_bus = EventBus()
    print("   ✓ Mock components created")
except Exception as e:
    print(f"   ✗ Initialization failed: {e}")
    sys.exit(1)

# Test 3: Create ValidationAgent
print("\n3. Creating ValidationAgent...")
try:
    validation_agent = ValidationAgent(config, event_bus)
    print(f"   ✓ ValidationAgent created: {validation_agent.agent_id}")
    print(f"   ✓ Capabilities: {validation_agent.contract.capabilities}")
except Exception as e:
    print(f"   ✗ ValidationAgent creation failed: {e}")
    sys.exit(1)

# Test 4: Test ValidationAgent execution
print("\n4. Testing ValidationAgent execution...")
try:
    # Create test content
    content = " ".join(["word"] * 500)
    frontmatter = {
        "title": "This is a Valid Test Title Meeting Requirements",
        "description": "This is a valid test description that provides enough detail and meets the minimum character requirement for search engines and SEO purposes.",
        "date": "2024-01-01",
        "author": "Test Author"
    }
    
    event = AgentEvent(
        event_type="validate_request",
        data={
            "content": content,
            "frontmatter": frontmatter
        },
        source_agent="test",
        correlation_id="test-001"
    )
    
    result = validation_agent.execute(event)
    print(f"   ✓ ValidationAgent executed successfully")
    print(f"   ✓ Event type: {result.event_type}")
    print(f"   ✓ Total checks: {result.data['summary']['total_checks']}")
    print(f"   ✓ Passed: {result.data['summary']['passed']}")
    print(f"   ✓ Failed: {result.data['summary']['failed']}")
    print(f"   ✓ Warnings: {result.data['summary']['warnings']}")
    
    # Store result for next test
    validation_results = result.data
    
except Exception as e:
    print(f"   ✗ ValidationAgent execution failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 5: Create QualityGateAgent
print("\n5. Creating QualityGateAgent...")
try:
    quality_gate_agent = QualityGateAgent(config, event_bus)
    print(f"   ✓ QualityGateAgent created: {quality_gate_agent.agent_id}")
    print(f"   ✓ Capabilities: {quality_gate_agent.contract.capabilities}")
except Exception as e:
    print(f"   ✗ QualityGateAgent creation failed: {e}")
    sys.exit(1)

# Test 6: Test QualityGateAgent execution
print("\n6. Testing QualityGateAgent execution...")
try:
    gate_event = AgentEvent(
        event_type="quality_gate_request",
        data={"validation_results": validation_results},
        source_agent="test",
        correlation_id="test-002"
    )
    
    gate_result = quality_gate_agent.execute(gate_event)
    print(f"   ✓ QualityGateAgent executed successfully")
    print(f"   ✓ Event type: {gate_result.event_type}")
    print(f"   ✓ Passed: {gate_result.data['passed']}")
    print(f"   ✓ Score: {gate_result.data['score']:.2f}/100")
    print(f"   ✓ Failures: {len(gate_result.data['failures'])}")
    print(f"   ✓ Warnings: {len(gate_result.data['warnings'])}")
    print(f"   ✓ Decision: {gate_result.data['decision']}")
    
except Exception as e:
    print(f"   ✗ QualityGateAgent execution failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 7: Test with failing content
print("\n7. Testing with failing content...")
try:
    # Create content that will fail
    short_content = "Too short"
    bad_frontmatter = {"title": "Short"}
    
    fail_event = AgentEvent(
        event_type="validate_request",
        data={
            "content": short_content,
            "frontmatter": bad_frontmatter
        },
        source_agent="test",
        correlation_id="test-003"
    )
    
    fail_result = validation_agent.execute(fail_event)
    gate_fail_event = AgentEvent(
        event_type="quality_gate_request",
        data={"validation_results": fail_result.data},
        source_agent="test",
        correlation_id="test-004"
    )
    
    gate_fail_result = quality_gate_agent.execute(gate_fail_event)
    print(f"   ✓ Failed content correctly identified")
    print(f"   ✓ Quality gate passed: {gate_fail_result.data['passed']}")
    print(f"   ✓ Failures detected: {len(gate_fail_result.data['failures'])}")
    print(f"   ✓ Suggestions provided: {len(gate_fail_result.data['suggestions'])}")
    
except Exception as e:
    print(f"   ✗ Failure test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "=" * 70)
print("ALL TESTS PASSED ✓")
print("=" * 70)
print("\nValidation agents are working correctly!")
print("Files created:")
print("  - config/validation.yaml")
print("  - src/agents/support/validation.py")
print("  - src/agents/support/quality_gate.py")
print("  - src/agents/support/__init__.py (updated)")
print("  - tests/unit/test_validation.py")
