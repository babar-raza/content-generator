#!/bin/bash

# MCP Endpoint Testing Runbook
# Tests all MCP endpoints with curl commands

set -e

BASE_URL="${MCP_BASE_URL:-http://localhost:8000}"
API_ENDPOINT="${BASE_URL}/api/mcp"

echo "================================"
echo "MCP Endpoint Testing Runbook"
echo "================================"
echo "Base URL: $BASE_URL"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_RUN=0
TESTS_PASSED=0

# Helper function to run test
run_test() {
    local test_name="$1"
    local curl_cmd="$2"
    local expected_key="$3"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    echo -e "${YELLOW}Test $TESTS_RUN: $test_name${NC}"
    echo "Command: $curl_cmd"
    echo ""
    
    response=$(eval "$curl_cmd" 2>/dev/null)
    
    if echo "$response" | grep -q "$expected_key"; then
        echo -e "${GREEN}✓ PASSED${NC}"
        echo "Response: $response"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo -e "${RED}✗ FAILED${NC}"
        echo "Response: $response"
    fi
    echo ""
    echo "---"
    echo ""
}

echo "Starting tests..."
echo ""

# Test 1: workflow.execute
run_test "workflow.execute - Execute workflow" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"workflow.execute\",
        \"params\": {
            \"workflow_id\": \"fast-draft\",
            \"inputs\": {
                \"topic\": \"AI trends\",
                \"output_dir\": \"./output\"
            }
        },
        \"id\": \"req_1\"
    }'" \
    "job_id"

# Test 2: agent.list
run_test "agent.list - List all agents" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"agent.list\",
        \"params\": {},
        \"id\": \"req_2\"
    }'" \
    "agents"

# Test 3: agent.list with category filter
run_test "agent.list - List agents by category" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"agent.list\",
        \"params\": {
            \"category\": \"research\"
        },
        \"id\": \"req_3\"
    }'" \
    "agents"

# Test 4: workflow.status (using mock job_id)
run_test "workflow.status - Get workflow status" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"workflow.status\",
        \"params\": {
            \"job_id\": \"job_20250111_120000_001\"
        },
        \"id\": \"req_4\"
    }'" \
    "job_id"

# Test 5: workflow.checkpoint.list
run_test "workflow.checkpoint.list - List checkpoints" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"workflow.checkpoint.list\",
        \"params\": {
            \"job_id\": \"job_20250111_120000_001\"
        },
        \"id\": \"req_5\"
    }'" \
    "checkpoints"

# Test 6: realtime.subscribe
run_test "realtime.subscribe - Subscribe to updates" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"realtime.subscribe\",
        \"params\": {
            \"job_id\": \"job_20250111_120000_001\",
            \"event_types\": [\"status\", \"progress\", \"log\"]
        },
        \"id\": \"req_6\"
    }'" \
    "websocket_url"

# Test 7: Invalid method (error handling)
run_test "Invalid method - Error handling" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"invalid.method\",
        \"params\": {},
        \"id\": \"req_7\"
    }'" \
    "error"

# Test 8: Missing required parameters
run_test "Missing params - Error handling" \
    "curl -s -X POST $API_ENDPOINT -H 'Content-Type: application/json' -d '{
        \"method\": \"workflow.execute\",
        \"params\": {},
        \"id\": \"req_8\"
    }'" \
    "error"

# Test 9: GET /api/mcp/methods - List available methods
run_test "List MCP methods" \
    "curl -s -X GET ${BASE_URL}/api/mcp/methods" \
    "methods"

# Test 10: GET /api/mcp/status - Check MCP status
run_test "Check MCP status" \
    "curl -s -X GET ${BASE_URL}/api/mcp/status" \
    "status"

# Summary
echo "================================"
echo "Test Summary"
echo "================================"
echo "Tests Run: $TESTS_RUN"
echo "Tests Passed: $TESTS_PASSED"
echo "Tests Failed: $((TESTS_RUN - TESTS_PASSED))"

if [ $TESTS_PASSED -eq $TESTS_RUN ]; then
    echo -e "${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed!${NC}"
    exit 1
fi
