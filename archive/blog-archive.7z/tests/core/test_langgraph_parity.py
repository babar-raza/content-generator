#!/usr/bin/env python3
"""LangGraph Parity Test - Compare Sequential vs LangGraph execution modes.

This script runs a simple workflow in both sequential and LangGraph modes
and compares the outputs to verify parity.
"""

import os
import sys
import json
import yaml
import tempfile
import shutil
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.core import Config
from src.orchestration.production_execution_engine import ProductionExecutionEngine


def setup_test_config(use_langgraph: bool = False) -> Config:
    """Create test configuration."""
    config = Config()
    config.use_langgraph = use_langgraph
    config.llm_provider = "OLLAMA"
    config.ollama_base_url = "http://localhost:11434"
    
    # Use temporary directories
    temp_dir = Path(tempfile.mkdtemp(prefix=f"test_{'lg' if use_langgraph else 'seq'}_"))
    config.output_dir = temp_dir / "output"
    config.chroma_db_path = temp_dir / "chroma"
    config.cache_dir = temp_dir / "cache"
    config.checkpoint_dir = temp_dir / "checkpoints"
    
    # Create directories
    config.output_dir.mkdir(parents=True, exist_ok=True)
    config.chroma_db_path.mkdir(parents=True, exist_ok=True)
    config.cache_dir.mkdir(parents=True, exist_ok=True)
    config.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    return config, temp_dir


def run_workflow(mode: str = "sequential") -> dict:
    """Run workflow in specified mode.
    
    Args:
        mode: Either 'sequential' or 'langgraph'
        
    Returns:
        Results dictionary
    """
    use_langgraph = (mode == "langgraph")
    
    print(f"\n{'='*60}")
    print(f"Running workflow in {mode.upper()} mode")
    print(f"{'='*60}\n")
    
    # Setup config
    config, temp_dir = setup_test_config(use_langgraph=use_langgraph)
    
    try:
        # Create engine
        print("Initializing engine...")
        engine = ProductionExecutionEngine(config)
        
        # Define simple workflow
        steps = [
            {'id': 'topic_identification', 'agent': 'topic_identification'},
        ]
        
        # Input data
        input_data = {
            'topic': 'Python Testing Best Practices',
            'family': 'general'
        }
        
        # Generate job ID
        job_id = f"test-{mode}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        # Execute workflow
        print(f"Executing workflow (job_id: {job_id})...")
        results = engine.execute_pipeline(
            workflow_name="test_workflow",
            steps=steps,
            input_data=input_data,
            job_id=job_id
        )
        
        # Extract key metrics
        summary = {
            'mode': mode,
            'job_id': job_id,
            'workflow_name': results.get('workflow_name', 'unknown'),
            'completed_steps': len(results.get('completed_steps', [])),
            'llm_calls': results.get('llm_calls', 0),
            'tokens_used': results.get('tokens_used', 0),
            'duration': results.get('total_duration', 0),
            'errors': results.get('errors', []),
            'agent_outputs_count': len(results.get('agent_outputs', {})),
            'shared_state_keys': list(results.get('shared_state', {}).keys())
        }
        
        print(f"\n✓ Workflow completed successfully")
        print(f"  - Completed steps: {summary['completed_steps']}")
        print(f"  - LLM calls: {summary['llm_calls']}")
        print(f"  - Duration: {summary['duration']:.2f}s")
        print(f"  - Agent outputs: {summary['agent_outputs_count']}")
        
        return {
            'success': True,
            'summary': summary,
            'full_results': results,
            'temp_dir': str(temp_dir)
        }
        
    except Exception as e:
        print(f"\n✗ Workflow failed: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            'success': False,
            'error': str(e),
            'temp_dir': str(temp_dir)
        }
    
    finally:
        # Cleanup
        try:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
                print(f"\nCleaned up temp directory: {temp_dir}")
        except Exception as e:
            print(f"Warning: Failed to cleanup temp directory: {e}")


def compare_results(seq_results: dict, lg_results: dict) -> dict:
    """Compare results from sequential and LangGraph modes.
    
    Args:
        seq_results: Results from sequential mode
        lg_results: Results from LangGraph mode
        
    Returns:
        Comparison report
    """
    print(f"\n{'='*60}")
    print("COMPARISON RESULTS")
    print(f"{'='*60}\n")
    
    if not seq_results['success'] or not lg_results['success']:
        print("✗ Cannot compare - one or both executions failed")
        return {
            'comparable': False,
            'reason': 'execution_failure'
        }
    
    seq_sum = seq_results['summary']
    lg_sum = lg_results['summary']
    
    comparison = {
        'comparable': True,
        'metrics': {},
        'differences': [],
        'parity_score': 0.0
    }
    
    # Compare metrics
    metrics_to_compare = [
        'completed_steps',
        'agent_outputs_count',
    ]
    
    parity_checks = 0
    parity_passed = 0
    
    for metric in metrics_to_compare:
        seq_val = seq_sum.get(metric, 0)
        lg_val = lg_sum.get(metric, 0)
        match = (seq_val == lg_val)
        
        comparison['metrics'][metric] = {
            'sequential': seq_val,
            'langgraph': lg_val,
            'match': match
        }
        
        parity_checks += 1
        if match:
            parity_passed += 1
            print(f"✓ {metric}: {seq_val} (match)")
        else:
            print(f"✗ {metric}: sequential={seq_val}, langgraph={lg_val} (mismatch)")
            comparison['differences'].append(metric)
    
    # Check shared state keys
    seq_keys = set(seq_sum.get('shared_state_keys', []))
    lg_keys = set(lg_sum.get('shared_state_keys', []))
    
    if seq_keys == lg_keys:
        print(f"✓ shared_state_keys: {len(seq_keys)} keys (match)")
        parity_passed += 1
    else:
        print(f"✗ shared_state_keys: mismatch")
        print(f"  Sequential: {seq_keys}")
        print(f"  LangGraph: {lg_keys}")
        comparison['differences'].append('shared_state_keys')
    
    parity_checks += 1
    
    # Calculate parity score
    comparison['parity_score'] = (parity_passed / parity_checks) * 100 if parity_checks > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"PARITY SCORE: {comparison['parity_score']:.1f}%")
    print(f"{'='*60}\n")
    
    if comparison['parity_score'] >= 90:
        print("✓ PARITY TEST PASSED - Outputs are equivalent")
    elif comparison['parity_score'] >= 70:
        print("⚠ PARITY TEST WARNING - Outputs mostly equivalent with minor differences")
    else:
        print("✗ PARITY TEST FAILED - Significant differences in outputs")
    
    return comparison


def main():
    """Main test runner."""
    print("""
╔═══════════════════════════════════════════════════════════╗
║      LangGraph vs Sequential Execution Parity Test       ║
╚═══════════════════════════════════════════════════════════╝
    """)
    
    # Check if LangGraph is available
    try:
        from src.orchestration.langgraph_executor import LANGGRAPH_AVAILABLE
        if not LANGGRAPH_AVAILABLE:
            print("✗ LangGraph not installed. Install with: pip install langgraph")
            sys.exit(1)
        print("✓ LangGraph is available")
    except ImportError:
        print("✗ Cannot import langgraph_executor module")
        sys.exit(1)
    
    # Run in sequential mode
    seq_results = run_workflow("sequential")
    
    # Run in LangGraph mode
    lg_results = run_workflow("langgraph")
    
    # Compare results
    comparison = compare_results(seq_results, lg_results)
    
    # Save detailed report
    report_file = Path("langgraph_parity_report.json")
    report = {
        'timestamp': datetime.now().isoformat(),
        'sequential': seq_results['summary'] if seq_results['success'] else {'error': seq_results.get('error')},
        'langgraph': lg_results['summary'] if lg_results['success'] else {'error': lg_results.get('error')},
        'comparison': comparison
    }
    
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\nDetailed report saved to: {report_file}")
    
    # Exit with appropriate code
    if comparison.get('parity_score', 0) >= 90:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
