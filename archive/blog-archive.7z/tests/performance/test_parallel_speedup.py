"""Performance tests for parallel execution speedup.

Benchmarks sequential vs parallel execution to verify 2-3× speedup.
"""

import unittest
import tempfile
import shutil
import time
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core import Config, EventBus, AgentEvent
from src.orchestration.production_execution_engine import ProductionExecutionEngine
from src.orchestration.checkpoint_manager import CheckpointManager


class TestParallelSpeedup(unittest.TestCase):
    """Test parallel execution provides speedup over sequential."""
    
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.config = Config()
        self.config.output_dir = Path(self.test_dir) / "output"
        self.config.chroma_db_path = Path(self.test_dir) / "chroma_db"
        self.config.cache_dir = Path(self.test_dir) / "cache"
        self.config.llm_provider = "OLLAMA"
        self.config.ollama_base_url = "http://localhost:11434"
        
        self.checkpoint_manager = CheckpointManager(storage_path=Path(self.test_dir) / "checkpoints")
    
    def tearDown(self):
        """Clean up test environment."""
        if self.test_dir and Path(self.test_dir).exists():
            shutil.rmtree(self.test_dir)
    
    def _create_mock_agent(self, execution_time: float = 1.0):
        """Create a mock agent that simulates work with given execution time."""
        mock_agent = MagicMock()
        
        def execute_with_delay(event):
            time.sleep(execution_time)  # Simulate I/O-bound work (LLM call)
            return AgentEvent(
                event_type="completed",
                data={"result": "success", "agent": "mock"},
                source_agent="mock_agent",
                correlation_id="test"
            )
        
        mock_agent.execute = execute_with_delay
        return mock_agent
    
    @patch('src.orchestration.production_execution_engine.AgentFactory')
    def test_parallel_executor_initialization(self, mock_factory_class):
        """Test that parallel executor is initialized when enabled."""
        # Enable parallel execution
        self.config.enable_parallel_execution = True
        self.config.max_parallel_agents = 3
        
        engine = ProductionExecutionEngine(self.config)
        
        # Verify parallel executor was created
        self.assertIsNotNone(engine.parallel_executor)
        self.assertEqual(engine.parallel_executor.max_workers, 3)
    
    @patch('src.orchestration.production_execution_engine.AgentFactory')
    def test_sequential_executor_when_disabled(self, mock_factory_class):
        """Test that parallel executor is not created when disabled."""
        self.config.enable_parallel_execution = False
        
        engine = ProductionExecutionEngine(self.config)
        
        # Verify no parallel executor
        self.assertIsNone(engine.parallel_executor)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_parallel_group_identification(self, mock_db, mock_llm):
        """Test identification of parallel agent groups."""
        from src.orchestration.parallel_executor import ParallelExecutor
        
        executor = ParallelExecutor(max_workers=3)
        
        # Define workflow with parallelizable agents
        steps = [
            {'id': 'topic_identification', 'agent': 'topic_identification'},
            {'id': 'kb_ingestion', 'agent': 'kb_ingestion'},
            {'id': 'api_ingestion', 'agent': 'api_ingestion'},
            {'id': 'blog_ingestion', 'agent': 'blog_ingestion'},
            {'id': 'outline_creation', 'agent': 'outline_creation'},
        ]
        
        dependencies = {}
        groups = executor.identify_parallel_groups(steps, dependencies)
        
        # Should identify ingestion group as parallel
        parallel_groups = [g for g, is_parallel in groups if is_parallel]
        
        self.assertGreater(len(parallel_groups), 0, "Should identify at least one parallel group")
        
        # Verify ingestion agents are grouped together
        ingestion_group = None
        for group_steps, is_parallel in groups:
            agent_types = [s.get('agent') for s in group_steps]
            if 'kb_ingestion' in agent_types and is_parallel:
                ingestion_group = agent_types
                break
        
        self.assertIsNotNone(ingestion_group)
        self.assertIn('kb_ingestion', ingestion_group)
        self.assertIn('api_ingestion', ingestion_group)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_thread_safe_state(self, mock_db, mock_llm):
        """Test thread-safe state management."""
        from src.orchestration.parallel_executor import ThreadSafeState
        import threading
        
        state = ThreadSafeState({'counter': 0})
        
        def increment():
            for _ in range(100):
                current = state.get('counter', 0)
                state.set('counter', current + 1)
        
        # Run multiple threads
        threads = [threading.Thread(target=increment) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # Counter should be 500 (5 threads × 100 increments)
        # Note: Without proper locking, this would fail
        self.assertEqual(state.get('counter'), 500)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_parallel_execution_faster_than_sequential(self, mock_db, mock_llm):
        """Test that parallel execution is faster than sequential.
        
        This is the key performance test - verifies 2-3× speedup.
        """
        from src.orchestration.parallel_executor import ParallelExecutor, ThreadSafeState
        
        # Setup mock agents with 0.5s execution time each
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        # Create agent factory mock
        mock_factory = MagicMock()
        
        # Create 3 mock agents that take 0.5s each
        execution_time = 0.5
        agent_configs = [
            {'id': 'agent1', 'agent': 'kb_ingestion'},
            {'id': 'agent2', 'agent': 'api_ingestion'},
            {'id': 'agent3', 'agent': 'blog_ingestion'},
        ]
        
        for config in agent_configs:
            agent_type = config['agent']
            mock_factory.create_agent.return_value = self._create_mock_agent(execution_time)
        
        # Measure sequential execution (should take ~1.5s)
        sequential_start = time.time()
        for config in agent_configs:
            agent = self._create_mock_agent(execution_time)
            agent.execute(AgentEvent("test", {}, "test", "test"))
        sequential_duration = time.time() - sequential_start
        
        # Measure parallel execution (should take ~0.5s + overhead)
        # Use max_workers equal to number of agents for true parallelism
        executor = ParallelExecutor(max_workers=len(agent_configs))
        state = ThreadSafeState({})
        context = {'job_id': 'test', 'input_data': {}}
        
        parallel_start = time.time()
        results = executor.execute_parallel(agent_configs, mock_factory, state, context)
        parallel_duration = time.time() - parallel_start
        
        # Verify parallel is significantly faster
        speedup = sequential_duration / parallel_duration
        
        print(f"\n{'='*60}")
        print(f"PARALLEL EXECUTION PERFORMANCE TEST")
        print(f"{'='*60}")
        print(f"  Agents:         {len(agent_configs)}")
        print(f"  Per-agent time: {execution_time:.2f}s")
        print(f"  Sequential:     {sequential_duration:.2f}s")
        print(f"  Parallel:       {parallel_duration:.2f}s")
        print(f"  Speedup:        {speedup:.2f}×")
        print(f"  Efficiency:     {(speedup/len(agent_configs))*100:.1f}%")
        print(f"{'='*60}")
        
        # Verify all agents completed successfully
        self.assertEqual(len(results), len(agent_configs))
        for result in results:
            self.assertEqual(result['status'], 'completed', f"Agent {result['agent_id']} should complete successfully")
        
        # Should achieve at least 2× speedup (ideally 2.5-3×)
        self.assertGreater(
            speedup, 2.0, 
            f"Parallel execution should be >2× faster than sequential. "
            f"Got {speedup:.2f}× speedup (sequential: {sequential_duration:.2f}s, parallel: {parallel_duration:.2f}s)"
        )
        
        # Parallel should complete in roughly the time of the longest agent plus overhead
        # With proper parallelism, it should be close to single agent time (0.5s) + small overhead (< 0.3s)
        max_expected = execution_time + 0.3
        self.assertLess(
            parallel_duration, max_expected,
            f"Parallel execution should complete in ~{execution_time:.2f}s + overhead. "
            f"Got {parallel_duration:.2f}s (expected < {max_expected:.2f}s)"
        )
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_parallel_with_failure(self, mock_db, mock_llm):
        """Test parallel execution handles failures gracefully."""
        from src.orchestration.parallel_executor import ParallelExecutor, ThreadSafeState
        
        mock_factory = MagicMock()
        
        # Create agents where one fails
        def create_agent_with_failure(agent_type):
            mock_agent = MagicMock()
            if agent_type == 'api_ingestion':
                # This agent fails
                def failing_execute(event):
                    raise ValueError("Simulated failure")
                mock_agent.execute = failing_execute
            else:
                # Other agents succeed
                def success_execute(event):
                    return AgentEvent("completed", {"result": "success"}, "test", "test")
                mock_agent.execute = success_execute
            return mock_agent
        
        mock_factory.create_agent = create_agent_with_failure
        
        executor = ParallelExecutor(max_workers=3, fail_fast=False)
        state = ThreadSafeState({})
        context = {'job_id': 'test', 'input_data': {}}
        
        agent_configs = [
            {'id': 'agent1', 'agent': 'kb_ingestion'},
            {'id': 'agent2', 'agent': 'api_ingestion'},  # This one fails
            {'id': 'agent3', 'agent': 'blog_ingestion'},
        ]
        
        results = executor.execute_parallel(agent_configs, mock_factory, state, context)
        
        # Should have 3 results
        self.assertEqual(len(results), 3)
        
        # One should be failed
        failed_results = [r for r in results if r['status'] == 'failed']
        self.assertEqual(len(failed_results), 1)
        
        # The failed one should be api_ingestion
        self.assertEqual(failed_results[0]['agent_id'], 'api_ingestion')
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_parallel_respects_max_workers(self, mock_db, mock_llm):
        """Test that parallel execution respects max_workers limit."""
        from src.orchestration.parallel_executor import ParallelExecutor, ThreadSafeState
        
        # Create executor with max_workers=2
        executor = ParallelExecutor(max_workers=2)
        
        # Verify max_workers is set
        self.assertEqual(executor.max_workers, 2)
        self.assertEqual(executor._executor._max_workers, 2)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_parallel_timeout(self, mock_db, mock_llm):
        """Test that parallel execution times out appropriately."""
        from src.orchestration.parallel_executor import ParallelExecutor, ThreadSafeState
        
        mock_factory = MagicMock()
        
        # Create agent that takes longer than timeout
        def slow_agent(*args, **kwargs):
            mock_agent = MagicMock()
            def slow_execute(event):
                time.sleep(2.0)  # Takes 2 seconds
                return AgentEvent("completed", {"result": "success"}, "test", "test")
            mock_agent.execute = slow_execute
            return mock_agent
        
        mock_factory.create_agent = slow_agent
        
        # Create executor with short timeout
        executor = ParallelExecutor(max_workers=3, group_timeout=1.0)
        state = ThreadSafeState({})
        context = {'job_id': 'test', 'input_data': {}}
        
        agent_configs = [{'id': 'agent1', 'agent': 'slow_agent'}]
        
        start = time.time()
        results = executor.execute_parallel(agent_configs, mock_factory, state, context)
        duration = time.time() - start
        
        # Should timeout and return failed result
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['status'], 'failed')
        
        # Should timeout around 1 second, not wait for 2 seconds
        self.assertLess(duration, 1.5)


class TestParallelExecutorBenchmark(unittest.TestCase):
    """Benchmark tests for parallel execution."""
    
    def test_benchmark_3_agents_parallel(self):
        """Benchmark: 3 agents in parallel vs sequential."""
        from src.orchestration.parallel_executor import ParallelExecutor, ThreadSafeState
        
        execution_time = 0.3  # Each agent takes 0.3s
        num_agents = 3
        
        # Mock factory
        mock_factory = MagicMock()
        
        def create_mock_agent(*args, **kwargs):
            mock_agent = MagicMock()
            def execute_with_delay(event):
                time.sleep(execution_time)
                return AgentEvent("completed", {"result": "success"}, "test", "test")
            mock_agent.execute = execute_with_delay
            return mock_agent
        
        mock_factory.create_agent = create_mock_agent
        
        agent_configs = [
            {'id': f'agent{i}', 'agent': f'test_agent_{i}'}
            for i in range(num_agents)
        ]
        
        # Sequential baseline
        sequential_start = time.time()
        for _ in agent_configs:
            agent = create_mock_agent()
            agent.execute(AgentEvent("test", {}, "test", "test"))
        sequential_time = time.time() - sequential_start
        
        # Parallel execution
        executor = ParallelExecutor(max_workers=num_agents)
        state = ThreadSafeState({})
        context = {'job_id': 'test', 'input_data': {}}
        
        parallel_start = time.time()
        results = executor.execute_parallel(agent_configs, mock_factory, state, context)
        parallel_time = time.time() - parallel_start
        
        speedup = sequential_time / parallel_time
        efficiency = (speedup / num_agents) * 100
        
        print(f"\n{'='*70}")
        print(f"BENCHMARK: {num_agents} agents @ {execution_time}s each")
        print(f"{'='*70}")
        print(f"  Sequential time:     {sequential_time:.3f}s")
        print(f"  Parallel time:       {parallel_time:.3f}s")
        print(f"  Speedup:             {speedup:.2f}×")
        print(f"  Efficiency:          {efficiency:.1f}%")
        print(f"  Time saved:          {sequential_time - parallel_time:.3f}s ({((sequential_time - parallel_time)/sequential_time)*100:.1f}%)")
        print(f"{'='*70}")
        
        # Verify all agents completed
        self.assertEqual(len(results), num_agents)
        for result in results:
            self.assertEqual(result['status'], 'completed')
        
        # Assert meaningful speedup
        self.assertGreater(speedup, 2.0, f"Expected >2× speedup, got {speedup:.2f}×")


if __name__ == '__main__':
    unittest.main()
