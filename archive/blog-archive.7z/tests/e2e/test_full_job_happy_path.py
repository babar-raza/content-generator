"""End-to-end tests for full job execution lifecycle."""

import pytest
import time
from pathlib import Path
from datetime import datetime

from src.core import EventBus, Config
from src.orchestration.workflow_compiler import WorkflowCompiler
from src.orchestration.enhanced_registry import EnhancedAgentRegistry
from src.orchestration.job_execution_engine import JobExecutionEngine
from src.orchestration.job_state import JobStatus
from src.orchestration.job_storage import JobStorage


class TestFullJobHappyPath:
    """Test complete job execution lifecycle."""
    
    @pytest.fixture
    def config(self):
        """Create test configuration."""
        return Config()
    
    @pytest.fixture
    def event_bus(self):
        """Create event bus."""
        return EventBus()
    
    @pytest.fixture
    def compiler(self):
        """Create workflow compiler."""
        workflows_path = Path("tests/fixtures/test_workflows.yaml")
        return WorkflowCompiler(workflows_path=workflows_path)
    
    @pytest.fixture
    def registry(self):
        """Create agent registry."""
        return EnhancedAgentRegistry()
    
    @pytest.fixture
    def engine(self, compiler, registry, event_bus, config):
        """Create job execution engine."""
        storage_dir = Path(".test_jobs")
        engine = JobExecutionEngine(
            compiler=compiler,
            registry=registry,
            event_bus=event_bus,
            config=config,
            max_concurrent_jobs=2,
            storage_dir=storage_dir
        )
        
        yield engine
        
        # Cleanup
        engine.stop()
        
        # Clean up test storage
        import shutil
        if storage_dir.exists():
            shutil.rmtree(storage_dir)
    
    def test_engine_initialization(self, engine):
        """Test engine initializes correctly."""
        assert engine is not None
        assert engine.compiler is not None
        assert engine.registry is not None
        assert engine.storage is not None
    
    def test_engine_start_stop(self, engine):
        """Test engine start and stop."""
        assert not engine._running
        
        engine.start()
        assert engine._running
        assert len(engine._worker_threads) == engine.max_concurrent_jobs
        
        engine.stop()
        assert not engine._running
        assert len(engine._worker_threads) == 0
    
    def test_submit_job(self, engine):
        """Test job submission."""
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={
                'kb_article_path': 'tests/fixtures/sample_kb.md',
                'config': {}
            }
        )
        
        assert job_id is not None
        assert len(job_id) == 36  # UUID format
        
        # Check job exists
        metadata = engine.get_job_status(job_id)
        assert metadata is not None
        assert metadata.job_id == job_id
        assert metadata.workflow_id == 'simple_workflow'
        assert metadata.status == JobStatus.PENDING
    
    def test_job_execution_lifecycle(self, engine, event_bus):
        """Test complete job execution from pending to completed."""
        # Track events
        events_received = []
        
        def event_handler(event):
            events_received.append(event.event_type)
        
        event_bus.subscribe("JobSubmitted", event_handler)
        event_bus.subscribe("JobStarted", event_handler)
        event_bus.subscribe("JobCompleted", event_handler)
        
        # Start engine
        engine.start()
        
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={
                'kb_article_path': 'tests/fixtures/sample_kb.md',
                'config': {}
            }
        )
        
        # Wait for job to complete (with timeout)
        timeout = 30
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            metadata = engine.get_job_status(job_id)
            
            if metadata.status in [JobStatus.COMPLETED, JobStatus.FAILED]:
                break
            
            time.sleep(0.5)
        
        # Verify final status
        final_metadata = engine.get_job_status(job_id)
        
        # Job might fail if agents aren't available, but it should finish
        assert final_metadata.status in [JobStatus.COMPLETED, JobStatus.FAILED]
        assert final_metadata.started_at is not None
        assert final_metadata.completed_at is not None
        
        # Verify events were emitted
        assert "JobSubmitted" in events_received
        
        # If job started, should have JobStarted event
        if final_metadata.status in [JobStatus.COMPLETED, JobStatus.FAILED]:
            assert "JobStarted" in events_received
    
    def test_job_persistence(self, engine):
        """Test job state is persisted to disk."""
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test_input': 'test_value'}
        )
        
        # Check job exists in storage
        assert engine.storage.job_exists(job_id)
        
        # Load job from storage
        job_state = engine.storage.load_job(job_id)
        assert job_state is not None
        assert job_state.metadata.job_id == job_id
        assert job_state.inputs['test_input'] == 'test_value'
    
    def test_pause_resume_job(self, engine):
        """Test job pause and resume."""
        engine.start()
        
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data'}
        )
        
        # Wait a bit for job to start
        time.sleep(1)
        
        # Pause job
        result = engine.pause_job(job_id)
        
        # Wait for pause to take effect
        time.sleep(1)
        
        metadata = engine.get_job_status(job_id)
        
        # Job should be paused or still pending
        assert metadata.status in [JobStatus.PAUSED, JobStatus.PENDING, JobStatus.RUNNING]
        
        # Resume job
        if metadata.status == JobStatus.PAUSED:
            result = engine.resume_job(job_id)
            assert result == True
            
            # Check status changed back to pending
            metadata = engine.get_job_status(job_id)
            assert metadata.status == JobStatus.PENDING
    
    def test_cancel_job(self, engine):
        """Test job cancellation."""
        engine.start()
        
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data'}
        )
        
        # Cancel immediately
        result = engine.cancel_job(job_id)
        assert result == True
        
        # Wait for cancellation
        time.sleep(1)
        
        metadata = engine.get_job_status(job_id)
        assert metadata.status in [JobStatus.CANCELLED, JobStatus.PENDING]
    
    def test_list_jobs(self, engine):
        """Test listing jobs."""
        # Submit multiple jobs
        job_ids = []
        for i in range(3):
            job_id = engine.submit_job(
                workflow_id='simple_workflow',
                inputs={'test': f'data_{i}'}
            )
            job_ids.append(job_id)
        
        # List all jobs
        jobs = engine.list_jobs()
        assert len(jobs) >= 3
        
        # List pending jobs
        pending_jobs = engine.list_jobs(status=JobStatus.PENDING)
        assert len(pending_jobs) >= 3
    
    def test_delete_job(self, engine):
        """Test job deletion."""
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data'}
        )
        
        # Verify job exists
        assert engine.storage.job_exists(job_id)
        
        # Delete job
        result = engine.delete_job(job_id)
        assert result == True
        
        # Verify job deleted
        assert not engine.storage.job_exists(job_id)
    
    def test_engine_stats(self, engine):
        """Test engine statistics."""
        engine.start()
        
        # Submit jobs
        for i in range(3):
            engine.submit_job(
                workflow_id='simple_workflow',
                inputs={'test': f'data_{i}'}
            )
        
        # Get stats
        stats = engine.get_engine_stats()
        
        assert 'running' in stats
        assert stats['running'] == True
        assert 'max_concurrent_jobs' in stats
        assert stats['max_concurrent_jobs'] == 2
        assert 'pending_jobs' in stats
        assert stats['pending_jobs'] >= 3
        assert 'storage' in stats
    
    def test_job_state_tracking(self, engine):
        """Test job state is properly tracked."""
        # Submit job
        job_id = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data'}
        )
        
        # Get job state
        job_state = engine.get_job_state(job_id)
        
        assert job_state is not None
        assert job_state.metadata.job_id == job_id
        assert job_state.inputs['test'] == 'data'
        assert len(job_state.steps) >= 0  # Should have steps initialized
    
    def test_concurrent_job_execution(self, engine):
        """Test multiple jobs can execute concurrently."""
        engine.start()
        
        # Submit multiple jobs
        job_ids = []
        for i in range(5):
            job_id = engine.submit_job(
                workflow_id='simple_workflow',
                inputs={'test': f'data_{i}'}
            )
            job_ids.append(job_id)
        
        # Wait a bit
        time.sleep(2)
        
        # Check that some jobs are running or completed
        statuses = [engine.get_job_status(jid).status for jid in job_ids]
        
        # At least one should have started
        assert any(status != JobStatus.PENDING for status in statuses)
    
    def test_job_recovery_on_restart(self, engine, compiler, registry, event_bus, config):
        """Test jobs are recovered after engine restart."""
        # Submit jobs
        job_id1 = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data1'}
        )
        
        job_id2 = engine.submit_job(
            workflow_id='simple_workflow',
            inputs={'test': 'data2'}
        )
        
        # Stop engine
        engine.stop()
        
        # Create new engine instance (simulating restart)
        storage_dir = Path(".test_jobs")
        new_engine = JobExecutionEngine(
            compiler=compiler,
            registry=registry,
            event_bus=event_bus,
            config=config,
            storage_dir=storage_dir
        )
        
        # Check jobs were loaded
        jobs = new_engine.list_jobs()
        job_ids = [j.job_id for j in jobs]
        
        assert job_id1 in job_ids or job_id2 in job_ids
        
        new_engine.stop()
    
    def test_workflow_not_found(self, engine):
        """Test handling of non-existent workflow."""
        with pytest.raises(Exception):
            engine.submit_job(
                workflow_id='nonexistent_workflow',
                inputs={}
            )
    
    def test_job_not_found_operations(self, engine):
        """Test operations on non-existent job."""
        fake_job_id = "00000000-0000-0000-0000-000000000000"
        
        # Get status
        metadata = engine.get_job_status(fake_job_id)
        assert metadata is None
        
        # Pause
        result = engine.pause_job(fake_job_id)
        assert result == False
        
        # Resume
        result = engine.resume_job(fake_job_id)
        assert result == False
        
        # Cancel
        result = engine.cancel_job(fake_job_id)
        assert result == False


class TestJobExecutionEngineIntegration:
    """Integration tests with real workflows."""
    
    @pytest.fixture
    def engine(self):
        """Create engine with production workflows."""
        compiler = WorkflowCompiler(workflows_path=Path("templates/workflows.yaml"))
        registry = EnhancedAgentRegistry()
        event_bus = EventBus()
        config = Config()
        
        storage_dir = Path(".test_jobs_integration")
        engine = JobExecutionEngine(
            compiler=compiler,
            registry=registry,
            event_bus=event_bus,
            config=config,
            storage_dir=storage_dir
        )
        
        yield engine
        
        # Cleanup
        engine.stop()
        
        import shutil
        if storage_dir.exists():
            shutil.rmtree(storage_dir)
    
    def test_fast_draft_workflow(self, engine):
        """Test fast_draft workflow execution."""
        job_id = engine.submit_job(
            workflow_id='fast_draft',
            inputs={
                'kb_article_path': 'tests/fixtures/sample_kb.md'
            }
        )
        
        assert job_id is not None
        metadata = engine.get_job_status(job_id)
        assert metadata.workflow_id == 'fast_draft'
        assert metadata.total_steps > 0
    
    def test_technical_post_workflow(self, engine):
        """Test technical_post workflow execution."""
        job_id = engine.submit_job(
            workflow_id='technical_post',
            inputs={
                'kb_article_path': 'tests/fixtures/sample_kb.md'
            }
        )
        
        assert job_id is not None
        metadata = engine.get_job_status(job_id)
        assert metadata.workflow_id == 'technical_post'


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
