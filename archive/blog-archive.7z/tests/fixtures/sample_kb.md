# Sample Knowledge Base Article

## Introduction to Aspose.Words for .NET

Aspose.Words for .NET is a powerful API for working with Microsoft Word documents. This article demonstrates key features and code examples.

## Features

### Document Creation
You can easily create Word documents programmatically:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
builder.Writeln("Hello World!");
doc.Save("output.docx");
```

### Document Conversion
Convert documents between formats:

```csharp
Document doc = new Document("input.docx");
doc.Save("output.pdf", SaveFormat.Pdf);
```

### Mail Merge
Perform mail merge operations:

```csharp
Document doc = new Document("template.docx");
doc.MailMerge.Execute(
    new string[] { "Name", "Email" },
    new object[] { "John Doe", "john@example.com" }
);
doc.Save("output.docx");
```

## Conclusion

Aspose.Words for .NET provides comprehensive document processing capabilities for .NET applications.
