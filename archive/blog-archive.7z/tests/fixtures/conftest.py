from __future__ import annotations

# Shared fixtures consolidated by tool

# DOCGEN:LLM-FIRST@v4