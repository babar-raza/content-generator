"""
Comprehensive API tests for UCOP REST API.
Tests all endpoints, error handling, rate limiting, and CORS.
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient
import time

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.web.app import app

client = TestClient(app)


class TestHealthEndpoint:
    """Test health check endpoint."""
    
    def test_health_check(self):
        """Test health check returns OK."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "timestamp" in data
    
    def test_health_check_structure(self):
        """Test health check response structure."""
        response = client.get("/health")
        data = response.json()
        assert isinstance(data, dict)
        assert data["version"] == "1.0.0"
        assert data["status"] == "ok"


class TestRootEndpoint:
    """Test root endpoint."""
    
    def test_root(self):
        """Test root endpoint returns API info."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "UCOP API"
        assert "version" in data
        assert "endpoints" in data
    
    def test_root_endpoints_info(self):
        """Test root endpoint includes correct endpoints."""
        response = client.get("/")
        data = response.json()
        endpoints = data["endpoints"]
        assert "/health" in endpoints["health"]
        assert "/docs" in endpoints["docs"]
        assert "/api/jobs" in endpoints["jobs"]
        assert "/api/workflows" in endpoints["workflows"]
        assert "/api/agents" in endpoints["agents"]


class TestJobsAPI:
    """Test jobs API endpoints."""
    
    def test_list_jobs(self):
        """Test listing jobs."""
        response = client.get("/api/jobs")
        assert response.status_code == 200
        data = response.json()
        assert "jobs" in data
        assert "total" in data
        assert isinstance(data["jobs"], list)
        assert isinstance(data["total"], int)
    
    def test_list_jobs_with_pagination(self):
        """Test job listing with pagination."""
        response = client.get("/api/jobs?limit=10&offset=0")
        assert response.status_code == 200
        data = response.json()
        assert len(data["jobs"]) <= 10
    
    def test_list_jobs_invalid_status(self):
        """Test listing jobs with invalid status filter."""
        response = client.get("/api/jobs?status=invalid")
        assert response.status_code == 400
    
    def test_create_job_invalid_workflow(self):
        """Test creating job with invalid workflow."""
        response = client.post(
            "/api/jobs",
            json={"workflow_id": "nonexistent", "inputs": {}}
        )
        # May be 400 or 500 depending on validation
        assert response.status_code in [400, 500]
    
    def test_create_job_missing_fields(self):
        """Test creating job with missing required fields."""
        response = client.post("/api/jobs", json={})
        assert response.status_code == 422  # Validation error
    
    def test_get_nonexistent_job(self):
        """Test getting a nonexistent job."""
        response = client.get("/api/jobs/nonexistent-job-id")
        assert response.status_code == 404
    
    def test_pause_nonexistent_job(self):
        """Test pausing a nonexistent job."""
        response = client.post("/api/jobs/nonexistent-job-id/pause")
        assert response.status_code == 404
    
    def test_resume_nonexistent_job(self):
        """Test resuming a nonexistent job."""
        response = client.post("/api/jobs/nonexistent-job-id/resume")
        assert response.status_code == 404
    
    def test_cancel_nonexistent_job(self):
        """Test cancelling a nonexistent job."""
        response = client.post("/api/jobs/nonexistent-job-id/cancel")
        assert response.status_code == 404


class TestWorkflowsAPI:
    """Test workflows API endpoints."""
    
    def test_list_workflows(self):
        """Test listing workflows."""
        response = client.get("/api/workflows")
        assert response.status_code == 200
        data = response.json()
        assert "workflows" in data
        assert "total" in data
        assert isinstance(data["workflows"], list)
        assert data["total"] >= 0
    
    def test_workflow_structure(self):
        """Test workflow response structure."""
        response = client.get("/api/workflows")
        data = response.json()
        if data["total"] > 0:
            workflow = data["workflows"][0]
            assert "id" in workflow
            assert "name" in workflow
            assert "steps" in workflow
            assert isinstance(workflow["steps"], list)
    
    def test_get_nonexistent_workflow(self):
        """Test getting a nonexistent workflow."""
        response = client.get("/api/workflows/nonexistent-workflow")
        assert response.status_code == 404


class TestAgentsAPI:
    """Test agents API endpoints."""
    
    def test_list_agents(self):
        """Test listing agents."""
        response = client.get("/api/agents")
        assert response.status_code == 200
        data = response.json()
        assert "agents" in data
        assert "total" in data
        assert isinstance(data["agents"], list)
        assert data["total"] > 0  # Should have some default agents
    
    def test_agent_structure(self):
        """Test agent response structure."""
        response = client.get("/api/agents")
        data = response.json()
        if data["total"] > 0:
            agent = data["agents"][0]
            assert "id" in agent
            assert "name" in agent
            assert "category" in agent
            assert "capabilities" in agent
            assert isinstance(agent["capabilities"], list)
    
    def test_list_agents_by_category(self):
        """Test filtering agents by category."""
        response = client.get("/api/agents?category=content")
        assert response.status_code == 200
        data = response.json()
        # Verify all returned agents are in content category
        for agent in data["agents"]:
            assert agent["category"] == "content"
    
    def test_get_specific_agent(self):
        """Test getting a specific agent."""
        # First get list to find an agent
        response = client.get("/api/agents")
        agents = response.json()["agents"]
        if agents:
            agent_id = agents[0]["id"]
            response = client.get(f"/api/agents/{agent_id}")
            assert response.status_code == 200
            data = response.json()
            assert data["id"] == agent_id
    
    def test_get_nonexistent_agent(self):
        """Test getting a nonexistent agent."""
        response = client.get("/api/agents/nonexistent-agent")
        assert response.status_code == 404


class TestCORS:
    """Test CORS configuration."""
    
    def test_cors_headers_present(self):
        """Test CORS headers are present in responses."""
        response = client.get(
            "/health",
            headers={"Origin": "http://localhost:3000"}
        )
        assert response.status_code == 200
        # Note: TestClient doesn't fully simulate CORS, but we can verify app structure
        # In real deployment, these would be tested with actual browser requests
    
    def test_options_request(self):
        """Test OPTIONS preflight request."""
        response = client.options(
            "/api/jobs",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "POST"
            }
        )
        # TestClient may return 200 or 405 depending on implementation
        assert response.status_code in [200, 405]


class TestRateLimiting:
    """Test rate limiting."""
    
    def test_rate_limit_headers(self):
        """Test rate limit headers are present."""
        response = client.get("/health")
        assert response.status_code == 200
        # Rate limit headers should be present
        assert "X-RateLimit-Limit" in response.headers
        assert "X-RateLimit-Remaining" in response.headers
        assert "X-RateLimit-Reset" in response.headers
    
    def test_rate_limit_values(self):
        """Test rate limit header values."""
        response = client.get("/health")
        assert int(response.headers["X-RateLimit-Limit"]) == 100
        assert int(response.headers["X-RateLimit-Remaining"]) >= 0


class TestErrorHandling:
    """Test error handling."""
    
    def test_404_error(self):
        """Test 404 error for nonexistent endpoint."""
        response = client.get("/api/nonexistent")
        assert response.status_code == 404
    
    def test_validation_error(self):
        """Test validation error response."""
        response = client.post("/api/jobs", json={"invalid": "data"})
        assert response.status_code == 422
        data = response.json()
        assert "detail" in data


class TestDocumentation:
    """Test API documentation endpoints."""
    
    def test_openapi_json(self):
        """Test OpenAPI JSON schema is accessible."""
        response = client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert "openapi" in data
        assert "info" in data
        assert "paths" in data
    
    def test_swagger_docs(self):
        """Test Swagger UI is accessible."""
        response = client.get("/docs")
        assert response.status_code == 200
    
    def test_redoc_docs(self):
        """Test ReDoc is accessible."""
        response = client.get("/redoc")
        assert response.status_code == 200


class TestMiddleware:
    """Test middleware functionality."""
    
    def test_gzip_compression(self):
        """Test GZip compression is applied."""
        response = client.get("/api/workflows")
        # GZip should be applied for responses > 1000 bytes
        assert response.status_code == 200
    
    def test_request_logging(self):
        """Test requests are logged."""
        # This is implicitly tested by successful responses
        response = client.get("/health")
        assert response.status_code == 200


class TestIntegration:
    """Integration tests for full workflows."""
    
    def test_full_api_flow(self):
        """Test complete API flow: list workflows, list jobs."""
        # List workflows
        response = client.get("/api/workflows")
        assert response.status_code == 200
        workflows = response.json()
        assert workflows["total"] >= 0
        
        # List jobs
        response = client.get("/api/jobs")
        assert response.status_code == 200
        jobs = response.json()
        assert "jobs" in jobs
        
        # List agents
        response = client.get("/api/agents")
        assert response.status_code == 200
        agents = response.json()
        assert agents["total"] > 0


# Pytest configuration
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
