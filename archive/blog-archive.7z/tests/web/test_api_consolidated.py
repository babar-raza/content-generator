"""Comprehensive tests for consolidated API endpoints."""

import pytest
import uuid
from datetime import datetime
from unittest.mock import Mock, patch, MagicMock
from fastapi.testclient import TestClient

from src.web.app import create_app
from src.web.routes.agents import redact_secrets


# Mock executor for testing
class MockExecutor:
    """Mock executor for testing."""
    
    def __init__(self):
        self.jobs = {}
        self.agents = [
            {
                "id": "agent_1",
                "name": "Content Writer",
                "type": "content",
                "description": "Writes content",
                "status": "available",
                "capabilities": ["write", "edit"],
            },
            {
                "id": "agent_2",
                "name": "SEO Optimizer",
                "type": "seo",
                "description": "Optimizes for SEO",
                "status": "available",
                "capabilities": ["optimize", "analyze"],
            }
        ]
        self.workflows = [
            {
                "id": "default_blog",
                "name": "Default Blog Workflow",
                "description": "Standard blog generation workflow",
                "agents": ["agent_1", "agent_2"],
            },
            {
                "id": "code_gen",
                "name": "Code Generation Workflow",
                "description": "Generates code examples",
                "agents": ["agent_1"],
            }
        ]
    
    def submit_job(self, job_id, workflow_id, inputs, config_overrides=None):
        """Mock job submission."""
        self.jobs[job_id] = {
            "job_id": job_id,
            "workflow_id": workflow_id,
            "inputs": inputs,
            "status": "queued",
        }
    
    def pause_job(self, job_id):
        """Mock pause job."""
        if job_id in self.jobs:
            self.jobs[job_id]["status"] = "paused"
    
    def resume_job(self, job_id):
        """Mock resume job."""
        if job_id in self.jobs:
            self.jobs[job_id]["status"] = "running"
    
    def cancel_job(self, job_id):
        """Mock cancel job."""
        if job_id in self.jobs:
            self.jobs[job_id]["status"] = "cancelled"
    
    def get_agents(self):
        """Mock get agents."""
        return self.agents
    
    def get_agent(self, agent_id):
        """Mock get agent."""
        for agent in self.agents:
            if agent["id"] == agent_id:
                return agent
        return None
    
    def get_workflows(self):
        """Mock get workflows."""
        return self.workflows
    
    def get_workflow(self, workflow_id):
        """Mock get workflow."""
        for workflow in self.workflows:
            if workflow["id"] == workflow_id:
                return workflow
        return None
    
    def get_status(self):
        """Mock get status."""
        return {
            "active_jobs": len([j for j in self.jobs.values() if j["status"] in ["running", "queued"]]),
            "completed_jobs": len([j for j in self.jobs.values() if j["status"] == "completed"]),
        }


@pytest.fixture
def mock_executor():
    """Fixture for mock executor."""
    return MockExecutor()


@pytest.fixture
def client(mock_executor):
    """Fixture for test client with mock executor."""
    app = create_app(executor=mock_executor)
    # Clear the jobs store before each test
    from src.web.app import get_jobs_store, get_agent_logs
    jobs_store = get_jobs_store()
    agent_logs = get_agent_logs()
    jobs_store.clear()
    agent_logs.clear()
    return TestClient(app)


class TestJobCreation:
    """Test job creation endpoints."""
    
    def test_create_job_success(self, client):
        """Test successful job creation."""
        response = client.post(
            "/api/jobs",
            json={
                "workflow_id": "default_blog",
                "inputs": {"topic": "Python Testing"}
            }
        )
        
        assert response.status_code == 201
        data = response.json()
        assert "job_id" in data
        assert data["status"] in ["created", "queued"]
        assert data["message"] is not None
    
    def test_create_job_via_generate(self, client):
        """Test job creation via /api/generate endpoint."""
        response = client.post(
            "/api/generate",
            json={
                "topic": "Python Testing",
                "template": "default_blog",
                "metadata": {"author": "test"}
            }
        )
        
        assert response.status_code == 201
        data = response.json()
        assert "job_id" in data
        assert data["status"] in ["created", "queued"]
        assert "Python Testing" in data["message"]
    
    def test_create_batch_jobs(self, client):
        """Test batch job creation."""
        response = client.post(
            "/api/batch",
            json={
                "workflow_id": "default_blog",
                "batch_name": "test_batch",
                "jobs": [
                    {"topic": "Topic 1"},
                    {"topic": "Topic 2"},
                    {"topic": "Topic 3"},
                ]
            }
        )
        
        assert response.status_code == 201
        data = response.json()
        assert "batch_id" in data
        assert "job_ids" in data
        assert len(data["job_ids"]) == 3
        assert data["status"] == "created"


class TestJobListing:
    """Test job listing and retrieval."""
    
    def test_list_jobs_empty(self, client):
        """Test listing jobs when none exist."""
        response = client.get("/api/jobs")
        
        assert response.status_code == 200
        data = response.json()
        assert "jobs" in data
        assert "total" in data
        assert data["total"] == 0
    
    def test_list_jobs_with_jobs(self, client):
        """Test listing jobs after creating some."""
        # Create a few jobs
        for i in range(3):
            client.post(
                "/api/jobs",
                json={
                    "workflow_id": "default_blog",
                    "inputs": {"topic": f"Topic {i}"}
                }
            )
        
        response = client.get("/api/jobs")
        
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 3
        assert len(data["jobs"]) == 3
    
    def test_list_jobs_with_status_filter(self, client):
        """Test listing jobs with status filter."""
        # Create jobs
        client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        
        response = client.get("/api/jobs?status=queued")
        
        assert response.status_code == 200
        data = response.json()
        # Should only return queued jobs
        for job in data["jobs"]:
            assert job["status"] == "queued"
    
    def test_list_jobs_with_pagination(self, client):
        """Test job listing pagination."""
        # Create multiple jobs
        for i in range(10):
            client.post(
                "/api/jobs",
                json={"workflow_id": "default_blog", "inputs": {"topic": f"Topic {i}"}}
            )
        
        # Test first page
        response = client.get("/api/jobs?limit=5&offset=0")
        assert response.status_code == 200
        data = response.json()
        assert len(data["jobs"]) == 5
        assert data["total"] == 10
        
        # Test second page
        response = client.get("/api/jobs?limit=5&offset=5")
        assert response.status_code == 200
        data = response.json()
        assert len(data["jobs"]) == 5
    
    def test_get_job_by_id(self, client):
        """Test getting a specific job by ID."""
        # Create a job
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        
        # Get the job
        response = client.get(f"/api/jobs/{job_id}")
        
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["status"] in ["created", "queued"]
    
    def test_get_nonexistent_job(self, client):
        """Test getting a job that doesn't exist."""
        response = client.get("/api/jobs/nonexistent-id")
        
        assert response.status_code == 404
        data = response.json()
        assert "not found" in data["detail"].lower()


class TestJobControl:
    """Test job control operations (pause/resume/cancel)."""
    
    def test_pause_job_success(self, client):
        """Test successfully pausing a job."""
        # Create a job
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        
        # Pause the job
        response = client.post(f"/api/jobs/{job_id}/pause")
        
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["action"] == "pause"
        assert data["status"] == "paused"
    
    def test_pause_nonexistent_job(self, client):
        """Test pausing a job that doesn't exist."""
        response = client.post("/api/jobs/nonexistent-id/pause")
        
        assert response.status_code == 404
    
    def test_resume_job_success(self, client):
        """Test successfully resuming a paused job."""
        # Create and pause a job
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        client.post(f"/api/jobs/{job_id}/pause")
        
        # Resume the job
        response = client.post(f"/api/jobs/{job_id}/resume")
        
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["action"] == "resume"
        assert data["status"] == "running"
    
    def test_resume_non_paused_job(self, client):
        """Test resuming a job that isn't paused."""
        # Create a job (not paused)
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        
        # Try to resume
        response = client.post(f"/api/jobs/{job_id}/resume")
        
        assert response.status_code == 400
        assert "Cannot resume" in response.json()["detail"]
    
    def test_cancel_job_success(self, client):
        """Test successfully cancelling a job."""
        # Create a job
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        
        # Cancel the job
        response = client.post(f"/api/jobs/{job_id}/cancel")
        
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["action"] == "cancel"
        assert data["status"] == "cancelled"


class TestAgentEndpoints:
    """Test agent-related endpoints."""
    
    def test_list_agents(self, client):
        """Test listing all agents."""
        response = client.get("/api/agents")
        
        assert response.status_code == 200
        data = response.json()
        assert "agents" in data
        assert "total" in data
        assert data["total"] > 0
        assert len(data["agents"]) > 0
    
    def test_get_agent_by_id(self, client):
        """Test getting a specific agent."""
        response = client.get("/api/agents/agent_1")
        
        assert response.status_code == 200
        data = response.json()
        assert data["agent_id"] == "agent_1"
        assert data["name"] == "Content Writer"
        assert "capabilities" in data
    
    def test_get_nonexistent_agent(self, client):
        """Test getting an agent that doesn't exist."""
        response = client.get("/api/agents/nonexistent")
        
        assert response.status_code == 404


class TestAgentLogs:
    """Test agent log endpoints with secret redaction."""
    
    def test_get_job_agent_logs_empty(self, client):
        """Test getting logs when none exist."""
        # Create a job first
        create_response = client.post(
            "/api/jobs",
            json={"workflow_id": "default_blog", "inputs": {"topic": "Test"}}
        )
        job_id = create_response.json()["job_id"]
        
        response = client.get(f"/api/jobs/{job_id}/logs/agent_1")
        
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["agent_name"] == "agent_1"
        assert data["total"] == 0
        assert len(data["logs"]) == 0
    
    def test_get_job_agent_logs_nonexistent_job(self, client):
        """Test getting logs for a nonexistent job."""
        response = client.get("/api/jobs/nonexistent/logs/agent_1")
        
        assert response.status_code == 404
    
    def test_get_agent_logs_all_jobs(self, client):
        """Test getting logs for an agent across all jobs."""
        response = client.get("/api/agents/agent_1/logs")
        
        assert response.status_code == 200
        data = response.json()
        assert data["agent_name"] == "agent_1"
        assert "logs" in data
        assert "total" in data
    
    def test_secret_redaction(self):
        """Test secret redaction in log messages."""
        # Test various secret patterns
        test_cases = [
            ("api_key=sk-12345", "api_key=***REDACTED***"),
            ("token: bearer_token_12345", "token=***REDACTED***"),
            ("password=mypassword", "password=***REDACTED***"),
            ("secret: my_secret_value", "secret=***REDACTED***"),
            ('Authorization: Bearer xyz123', 'Authorization: Bearer ***REDACTED***'),
            ('"apikey":"sk-12345"', '"apikey":"***REDACTED***'),
        ]
        
        for original, expected_pattern in test_cases:
            redacted = redact_secrets(original)
            assert "REDACTED" in redacted, f"Failed to redact: {original}"
            # Should not contain the original secret
            assert "sk-12345" not in redacted
            assert "bearer_token_12345" not in redacted
            assert "mypassword" not in redacted
            assert "my_secret_value" not in redacted
            assert "xyz123" not in redacted


class TestWorkflowEndpoints:
    """Test workflow-related endpoints."""
    
    def test_list_workflows(self, client):
        """Test listing all workflows."""
        response = client.get("/api/workflows")
        
        assert response.status_code == 200
        data = response.json()
        assert "workflows" in data
        assert "total" in data
        assert data["total"] > 0
    
    def test_get_workflow_by_id(self, client):
        """Test getting a specific workflow."""
        response = client.get("/api/workflows/default_blog")
        
        assert response.status_code == 200
        data = response.json()
        assert data["workflow_id"] == "default_blog"
        assert data["name"] == "Default Blog Workflow"
        assert "agents" in data
    
    def test_get_nonexistent_workflow(self, client):
        """Test getting a workflow that doesn't exist."""
        response = client.get("/api/workflows/nonexistent")
        
        assert response.status_code == 404


class TestSystemHealth:
    """Test system health endpoint."""
    
    def test_basic_health_check(self, client):
        """Test basic health check endpoint."""
        response = client.get("/health")
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
    
    def test_system_health_detailed(self, client):
        """Test detailed system health endpoint."""
        response = client.get("/api/system/health")
        
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "timestamp" in data
        assert "components" in data
        assert "version" in data
        assert "uptime" in data
        
        # Check components
        components = data["components"]
        assert "executor" in components
        assert "jobs_store" in components
        assert "config" in components
        
        # Executor should be healthy with mock
        assert components["executor"]["status"] == "healthy"


class TestErrorHandling:
    """Test error handling and edge cases."""
    
    def test_invalid_json(self, client):
        """Test handling of invalid JSON."""
        response = client.post(
            "/api/jobs",
            data="not valid json",
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 422  # Unprocessable Entity
    
    def test_missing_required_fields(self, client):
        """Test handling of missing required fields."""
        response = client.post(
            "/api/jobs",
            json={"inputs": {"topic": "Test"}}  # Missing workflow_id
        )
        
        assert response.status_code == 422


class TestDeterministicBehavior:
    """Test deterministic behavior for testing."""
    
    def test_job_list_ordering(self, client):
        """Test that job lists are consistently ordered."""
        # Create jobs with delays to ensure different timestamps
        job_ids = []
        for i in range(3):
            response = client.post(
                "/api/jobs",
                json={"workflow_id": "default_blog", "inputs": {"topic": f"Topic {i}"}}
            )
            job_ids.append(response.json()["job_id"])
        
        # Get list twice
        response1 = client.get("/api/jobs")
        response2 = client.get("/api/jobs")
        
        # Should be in same order (newest first)
        jobs1 = [j["job_id"] for j in response1.json()["jobs"]]
        jobs2 = [j["job_id"] for j in response2.json()["jobs"]]
        
        assert jobs1 == jobs2
        # Newest should be first
        assert jobs1[0] == job_ids[-1]


def test_root_endpoint(client):
    """Test root endpoint."""
    response = client.get("/")
    
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "UCOP API"
    assert data["status"] == "operational"
    assert "docs" in data
