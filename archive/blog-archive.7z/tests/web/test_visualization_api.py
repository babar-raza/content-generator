"""Tests for visualization API endpoints."""

import pytest
from fastapi.testclient import TestClient
from datetime import datetime, timezone

from src.web.app import create_app
from src.visualization.workflow_visualizer import WorkflowVisualizer
from src.visualization.workflow_debugger import WorkflowDebugger
from src.visualization.monitor import VisualOrchestrationMonitor


@pytest.fixture
def client():
    """Create test client."""
    app = create_app()
    return TestClient(app)


@pytest.fixture
def visualizer():
    """Create workflow visualizer."""
    return WorkflowVisualizer()


@pytest.fixture
def debugger():
    """Create workflow debugger."""
    return WorkflowDebugger()


@pytest.fixture
def monitor():
    """Create orchestration monitor."""
    return VisualOrchestrationMonitor()


# ============================================================================
# Workflow Visualization Tests
# ============================================================================

def test_list_workflows(client):
    """Test listing available workflows."""
    response = client.get("/api/visualization/workflows")
    assert response.status_code == 200
    
    data = response.json()
    assert "workflows" in data
    assert "total" in data
    assert isinstance(data["workflows"], list)
    assert data["total"] >= 0
    
    # Check workflows are sorted alphabetically
    if len(data["workflows"]) > 1:
        workflow_ids = [w["workflow_id"] for w in data["workflows"]]
        assert workflow_ids == sorted(workflow_ids)


def test_get_workflow_graph_success(client):
    """Test getting workflow graph data."""
    # First get available workflows
    list_response = client.get("/api/visualization/workflows")
    assert list_response.status_code == 200
    
    workflows = list_response.json()["workflows"]
    if not workflows:
        pytest.skip("No workflows available")
    
    workflow_id = workflows[0]["workflow_id"]
    
    # Get workflow graph
    response = client.get(f"/api/visualization/workflows/{workflow_id}")
    assert response.status_code == 200
    
    data = response.json()
    assert "profile_name" in data
    assert "name" in data
    assert "nodes" in data
    assert "edges" in data
    assert "metadata" in data
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)


def test_get_workflow_graph_not_found(client):
    """Test getting non-existent workflow."""
    response = client.get("/api/visualization/workflows/nonexistent_workflow")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()


def test_render_workflow_json(client):
    """Test rendering workflow as JSON."""
    # Get first workflow
    list_response = client.get("/api/visualization/workflows")
    workflows = list_response.json()["workflows"]
    if not workflows:
        pytest.skip("No workflows available")
    
    workflow_id = workflows[0]["workflow_id"]
    
    response = client.get(f"/api/visualization/workflows/{workflow_id}/render?format=json")
    assert response.status_code == 200
    
    data = response.json()
    assert data["workflow_id"] == workflow_id
    assert data["format"] == "json"
    assert "content" in data


def test_render_workflow_dot(client):
    """Test rendering workflow as DOT format."""
    # Get first workflow
    list_response = client.get("/api/visualization/workflows")
    workflows = list_response.json()["workflows"]
    if not workflows:
        pytest.skip("No workflows available")
    
    workflow_id = workflows[0]["workflow_id"]
    
    response = client.get(f"/api/visualization/workflows/{workflow_id}/render?format=dot")
    assert response.status_code == 200
    
    data = response.json()
    assert data["workflow_id"] == workflow_id
    assert data["format"] == "dot"
    assert "content" in data
    assert "dot" in data["content"]


def test_render_workflow_invalid_format(client):
    """Test rendering workflow with invalid format."""
    list_response = client.get("/api/visualization/workflows")
    workflows = list_response.json()["workflows"]
    if not workflows:
        pytest.skip("No workflows available")
    
    workflow_id = workflows[0]["workflow_id"]
    
    response = client.get(f"/api/visualization/workflows/{workflow_id}/render?format=invalid")
    assert response.status_code == 400


# ============================================================================
# Agent Monitoring Tests
# ============================================================================

def test_get_agent_metrics_empty(client):
    """Test getting agent metrics when no agents registered."""
    response = client.get("/api/monitoring/agents")
    assert response.status_code == 200
    
    data = response.json()
    assert "agents" in data
    assert "total" in data
    assert isinstance(data["agents"], list)


def test_get_agent_metrics_by_id_not_found(client):
    """Test getting metrics for non-existent agent."""
    response = client.get("/api/monitoring/agents/nonexistent_agent")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()


# ============================================================================
# System Monitoring Tests
# ============================================================================

def test_get_system_metrics(client):
    """Test getting system metrics."""
    response = client.get("/api/monitoring/system")
    assert response.status_code == 200
    
    data = response.json()
    assert "cpu_percent" in data
    assert "memory_percent" in data
    assert "memory_available_mb" in data
    assert "memory_total_mb" in data
    assert "active_jobs" in data
    assert "total_agents" in data
    assert "uptime_seconds" in data
    assert "timestamp" in data
    
    # Validate types
    assert isinstance(data["cpu_percent"], (int, float))
    assert isinstance(data["memory_percent"], (int, float))
    assert isinstance(data["active_jobs"], int)
    assert isinstance(data["total_agents"], int)
    assert isinstance(data["uptime_seconds"], (int, float))


def test_get_job_metrics_not_found(client):
    """Test getting metrics for non-existent job."""
    response = client.get("/api/monitoring/jobs/nonexistent_job/metrics")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()


# ============================================================================
# Breakpoint Tests
# ============================================================================

def test_create_breakpoint(client):
    """Test creating a breakpoint."""
    breakpoint_data = {
        "agent_id": "test_agent",
        "event_type": "agent_start",
        "correlation_id": "test_correlation"
    }
    
    response = client.post("/api/debug/breakpoints", json=breakpoint_data)
    assert response.status_code == 201
    
    data = response.json()
    assert "breakpoint_id" in data
    assert "session_id" in data
    assert data["agent_id"] == "test_agent"
    assert data["event_type"] == "agent_start"
    assert data["enabled"] is True
    assert data["hit_count"] == 0


def test_create_breakpoint_with_condition(client):
    """Test creating a breakpoint with condition."""
    breakpoint_data = {
        "agent_id": "test_agent",
        "event_type": "agent_complete",
        "condition": "status == 'error'",
        "max_hits": 5,
        "correlation_id": "test_correlation"
    }
    
    response = client.post("/api/debug/breakpoints", json=breakpoint_data)
    assert response.status_code == 201
    
    data = response.json()
    assert data["condition"] == "status == 'error'"
    assert data["max_hits"] == 5


def test_list_breakpoints_empty(client):
    """Test listing breakpoints when none exist."""
    response = client.get("/api/debug/breakpoints")
    assert response.status_code == 200
    
    data = response.json()
    assert "breakpoints" in data
    assert "total" in data
    assert isinstance(data["breakpoints"], list)


def test_list_breakpoints_with_session(client):
    """Test listing breakpoints for specific session."""
    # Create a breakpoint first
    breakpoint_data = {
        "agent_id": "test_agent",
        "event_type": "agent_start",
        "correlation_id": "test_correlation"
    }
    
    create_response = client.post("/api/debug/breakpoints", json=breakpoint_data)
    assert create_response.status_code == 201
    session_id = create_response.json()["session_id"]
    
    # List breakpoints for session
    response = client.get(f"/api/debug/breakpoints?session_id={session_id}")
    assert response.status_code == 200
    
    data = response.json()
    assert data["total"] >= 1
    assert all(bp["session_id"] == session_id for bp in data["breakpoints"])


def test_delete_breakpoint(client):
    """Test deleting a breakpoint."""
    # Create a breakpoint first
    breakpoint_data = {
        "agent_id": "test_agent",
        "event_type": "agent_start",
        "correlation_id": "test_correlation"
    }
    
    create_response = client.post("/api/debug/breakpoints", json=breakpoint_data)
    assert create_response.status_code == 201
    
    breakpoint_id = create_response.json()["breakpoint_id"]
    
    # Delete breakpoint
    delete_response = client.delete(f"/api/debug/breakpoints/{breakpoint_id}")
    assert delete_response.status_code == 200
    assert "removed successfully" in delete_response.json()["message"]


def test_delete_nonexistent_breakpoint(client):
    """Test deleting non-existent breakpoint."""
    response = client.delete("/api/debug/breakpoints/nonexistent_breakpoint")
    assert response.status_code == 404


# ============================================================================
# Debug Step Tests
# ============================================================================

def test_debug_step(client):
    """Test debug step operation."""
    # Create a debug session first
    breakpoint_data = {
        "agent_id": "test_agent",
        "event_type": "agent_start",
        "correlation_id": "test_correlation"
    }
    
    create_response = client.post("/api/debug/breakpoints", json=breakpoint_data)
    assert create_response.status_code == 201
    session_id = create_response.json()["session_id"]
    
    # Execute step
    step_data = {
        "session_id": session_id,
        "action": "step"
    }
    
    response = client.post("/api/debug/step", json=step_data)
    assert response.status_code == 200
    
    data = response.json()
    assert data["session_id"] == session_id
    assert "status" in data


def test_debug_step_invalid_session(client):
    """Test debug step with invalid session."""
    step_data = {
        "session_id": "nonexistent_session",
        "action": "step"
    }
    
    response = client.post("/api/debug/step", json=step_data)
    assert response.status_code == 404


def test_get_debug_state_not_found(client):
    """Test getting debug state for non-existent job."""
    response = client.get("/api/debug/state/nonexistent_job")
    assert response.status_code == 404


# ============================================================================
# WebSocket Tests
# ============================================================================

def test_monitoring_websocket_connection(client):
    """Test WebSocket monitoring connection."""
    with client.websocket_connect("/ws/monitoring") as websocket:
        # Receive connection message
        data = websocket.receive_json()
        assert data["type"] == "connected"
        assert "timestamp" in data
        
        # Send ping
        websocket.send_text("ping")
        
        # Receive pong
        response = websocket.receive_json()
        assert response["type"] == "pong"


# ============================================================================
# Integration Tests
# ============================================================================

def test_workflow_visualization_integration(visualizer):
    """Test workflow visualizer integration."""
    # Test with sample workflows
    workflows = visualizer.workflows.get('profiles', {})
    assert len(workflows) > 0
    
    for profile_name in workflows.keys():
        # Create visual graph
        graph = visualizer.create_visual_graph(profile_name)
        
        assert "nodes" in graph
        assert "edges" in graph
        assert len(graph["nodes"]) > 0
        
        # Verify node structure
        for node in graph["nodes"]:
            assert "id" in node
            assert "data" in node
            assert "position" in node


def test_debugger_integration(debugger):
    """Test workflow debugger integration."""
    # Start debug session
    session_id = debugger.start_debug_session("test_correlation")
    assert session_id in debugger.debug_sessions
    
    # Add breakpoint
    bp_id = debugger.add_breakpoint(
        session_id=session_id,
        agent_id="test_agent",
        event_type="test_event"
    )
    
    assert bp_id in debugger.active_breakpoints
    
    # Remove breakpoint
    debugger.remove_breakpoint(session_id, bp_id)
    assert bp_id not in debugger.active_breakpoints


def test_monitor_integration(monitor):
    """Test orchestration monitor integration."""
    # Register agent
    monitor.register_agent(
        agent_id="test_agent",
        name="Test Agent",
        agent_type="test"
    )
    
    assert "test_agent" in monitor.registered_agents
    assert "test_agent" in monitor.agent_metrics
    
    # Unregister agent
    monitor.unregister_agent("test_agent")
    assert "test_agent" not in monitor.registered_agents


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
