"""WebSocket endpoint tests for UCOP web application."""

import pytest
import asyncio
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch, MagicMock, AsyncMock
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.web.app import create_app
from src.web.connection_manager import ConnectionManager


@pytest.fixture
def app():
    """Create test app."""
    return create_app()


@pytest.fixture
def client(app):
    """Create test client."""
    return TestClient(app)


@pytest.fixture
def connection_manager():
    """Create connection manager."""
    return ConnectionManager()


class TestConnectionManager:
    """Test ConnectionManager functionality."""
    
    @pytest.mark.asyncio
    async def test_job_connection(self, connection_manager):
        """Test connecting to job updates."""
        mock_ws = AsyncMock()
        mock_ws.accept = AsyncMock()
        mock_ws.send_json = AsyncMock()
        
        await connection_manager.connect_job(mock_ws, "test-job-123")
        
        assert "test-job-123" in connection_manager.job_connections
        assert mock_ws in connection_manager.job_connections["test-job-123"]
        assert mock_ws in connection_manager.connection_metadata
        
        mock_ws.accept.assert_called_once()
        mock_ws.send_json.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_visual_connection(self, connection_manager):
        """Test connecting to visual updates."""
        mock_ws = AsyncMock()
        mock_ws.accept = AsyncMock()
        mock_ws.send_json = AsyncMock()
        
        await connection_manager.connect_visual(mock_ws)
        
        assert mock_ws in connection_manager.visual_connections
        assert mock_ws in connection_manager.connection_metadata
        
        mock_ws.accept.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_agents_connection(self, connection_manager):
        """Test connecting to agent updates."""
        mock_ws = AsyncMock()
        mock_ws.accept = AsyncMock()
        mock_ws.send_json = AsyncMock()
        
        await connection_manager.connect_agents(mock_ws)
        
        assert mock_ws in connection_manager.agent_connections
        assert mock_ws in connection_manager.connection_metadata
        
        mock_ws.accept.assert_called_once()
    
    def test_disconnect_job(self, connection_manager):
        """Test disconnecting from job."""
        mock_ws = Mock()
        
        # Setup connection
        connection_manager.job_connections["test-job"] = {mock_ws}
        connection_manager.connection_metadata[mock_ws] = {
            "type": "job",
            "job_id": "test-job"
        }
        
        # Disconnect
        connection_manager.disconnect(mock_ws)
        
        assert "test-job" not in connection_manager.job_connections
        assert mock_ws not in connection_manager.connection_metadata
    
    @pytest.mark.asyncio
    async def test_broadcast_job(self, connection_manager):
        """Test broadcasting to job connections."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()
        
        # Setup connections
        connection_manager.job_connections["test-job"] = {mock_ws1, mock_ws2}
        connection_manager.connection_metadata[mock_ws1] = {"type": "job"}
        connection_manager.connection_metadata[mock_ws2] = {"type": "job"}
        
        message = {"type": "job.started", "data": {"job_id": "test-job"}}
        
        await connection_manager.broadcast_job("test-job", message)
        
        # Both clients should receive message
        assert mock_ws1.send_json.called
        assert mock_ws2.send_json.called
    
    @pytest.mark.asyncio
    async def test_broadcast_visual(self, connection_manager):
        """Test broadcasting to visual connections."""
        mock_ws = AsyncMock()
        
        connection_manager.visual_connections = {mock_ws}
        connection_manager.connection_metadata[mock_ws] = {"type": "visual"}
        
        message = {"type": "workflow.state", "data": {}}
        
        await connection_manager.broadcast_visual(message)
        
        mock_ws.send_json.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_broadcast_agents(self, connection_manager):
        """Test broadcasting to agent connections."""
        mock_ws = AsyncMock()
        
        connection_manager.agent_connections = {mock_ws}
        connection_manager.connection_metadata[mock_ws] = {"type": "agents"}
        
        message = {"type": "agent.status", "data": {}}
        
        await connection_manager.broadcast_agents(message)
        
        mock_ws.send_json.assert_called_once()
    
    def test_get_connection_stats(self, connection_manager):
        """Test getting connection statistics."""
        mock_ws1 = Mock()
        mock_ws2 = Mock()
        mock_ws3 = Mock()
        
        connection_manager.job_connections["job1"] = {mock_ws1}
        connection_manager.job_connections["job2"] = {mock_ws2}
        connection_manager.visual_connections = {mock_ws3}
        
        stats = connection_manager.get_connection_stats()
        
        assert stats["job_connections"]["total"] == 2
        assert stats["visual_connections"] == 1
        assert stats["total_connections"] == 3


class TestWebSocketEndpoints:
    """Test WebSocket endpoints."""
    
    def test_job_websocket_endpoint(self, client):
        """Test job WebSocket endpoint."""
        with client.websocket_connect("/ws/jobs/test-job-123") as websocket:
            # Should receive connection established message
            data = websocket.receive_json()
            assert data["type"] == "connection.established"
            assert "job_id" in data["data"]
    
    def test_visual_websocket_endpoint(self, client):
        """Test visual WebSocket endpoint."""
        with client.websocket_connect("/ws/visual") as websocket:
            data = websocket.receive_json()
            assert data["type"] == "connection.established"
    
    def test_agents_websocket_endpoint(self, client):
        """Test agents WebSocket endpoint."""
        with client.websocket_connect("/ws/agents") as websocket:
            data = websocket.receive_json()
            assert data["type"] == "connection.established"
    
    def test_job_websocket_ping(self, client):
        """Test ping/pong on job WebSocket."""
        with client.websocket_connect("/ws/jobs/test-job-123") as websocket:
            # Receive connection message
            websocket.receive_json()
            
            # Send ping
            websocket.send_json({"type": "ping"})
            
            # Receive pong
            data = websocket.receive_json()
            assert data["type"] == "pong"
    
    def test_job_websocket_get_status(self, client):
        """Test getting job status via WebSocket."""
        with client.websocket_connect("/ws/jobs/test-job-123") as websocket:
            # Receive connection message
            websocket.receive_json()
            
            # Request status
            websocket.send_json({"type": "get_status"})
            
            # Should receive response (error since job doesn't exist in test)
            data = websocket.receive_json()
            assert data["type"] in ["job.status", "error"]


class TestWebSocketIntegration:
    """Integration tests for WebSocket with job execution."""
    
    @patch('src.web.routes.jobs.get_job_engine')
    def test_job_creation_websocket_notification(self, mock_get_engine, client):
        """Test that job creation triggers WebSocket notification."""
        # Setup mock
        mock_engine = MagicMock()
        mock_engine.submit_job.return_value = "test-job-123"
        mock_engine.get_job_status.return_value = {
            'job_id': 'test-job-123',
            'workflow_name': 'test',
            'status': 'pending',
            'progress': 0.0,
            'input_params': {},
            'output_data': {},
            'metadata': {}
        }
        mock_get_engine.return_value = mock_engine
        
        # Create job via API
        response = client.post(
            "/api/jobs/",
            json={"workflow_id": "test", "inputs": {}}
        )
        
        assert response.status_code == 201
        assert response.json()["job_id"] == "test-job-123"


class TestWebSocketMessages:
    """Test WebSocket message handling."""
    
    def test_invalid_json_handling(self, client):
        """Test handling of invalid JSON messages."""
        with client.websocket_connect("/ws/jobs/test-job") as websocket:
            # Receive connection message
            websocket.receive_json()
            
            # Send invalid JSON
            websocket.send_text("invalid json {")
            
            # Should receive error message
            data = websocket.receive_json()
            assert data["type"] == "error"
            assert "Invalid JSON" in data["data"]["message"]
    
    def test_unknown_message_type(self, client):
        """Test handling of unknown message types."""
        with client.websocket_connect("/ws/jobs/test-job") as websocket:
            # Receive connection message
            websocket.receive_json()
            
            # Send unknown message type
            websocket.send_json({"type": "unknown_type"})
            
            # Connection should remain open (no error)
            # Server just logs warning


class TestWebSocketCleanup:
    """Test WebSocket connection cleanup."""
    
    def test_disconnect_cleanup(self, connection_manager):
        """Test that disconnect properly cleans up resources."""
        mock_ws = Mock()
        
        # Setup multiple connection types
        connection_manager.job_connections["job1"] = {mock_ws}
        connection_manager.visual_connections.add(mock_ws)
        connection_manager.connection_metadata[mock_ws] = {
            "type": "job",
            "job_id": "job1"
        }
        
        # Disconnect
        connection_manager.disconnect(mock_ws)
        
        # Should be cleaned up
        assert "job1" not in connection_manager.job_connections
        assert mock_ws not in connection_manager.visual_connections
        assert mock_ws not in connection_manager.connection_metadata


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
# DOCGEN:LLM-FIRST@v4