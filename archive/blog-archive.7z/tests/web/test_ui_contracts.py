"""Tests for UI contract verification.

Verifies that the data formats returned by the backend API
match what the frontend UI expects.
"""

import pytest
from typing import Dict, Any


class TestAgentContracts:
    """Test agent data format contracts."""
    
    def test_agent_structure(self):
        """Test that agent objects have required fields."""
        agent = {
            "id": "test_agent",
            "version": "1.0.0",
            "description": "Test agent",
            "entrypoint": {
                "type": "python",
                "module": "agents",
                "function": "test_agent",
                "async": False
            },
            "contract": {
                "inputs": {
                    "type": "object",
                    "required": ["config"],
                    "properties": {
                        "config": {"type": "object"}
                    }
                },
                "outputs": {
                    "type": "object",
                    "required": ["result"],
                    "properties": {
                        "result": {"type": "string"}
                    }
                }
            },
            "capabilities": {
                "stateful": True,
                "async": False,
                "model_switchable": False
            },
            "resources": {
                "max_runtime_s": 300,
                "max_tokens": 4096,
                "max_memory_mb": 1024
            }
        }
        
        # Verify required fields
        assert "id" in agent
        assert "version" in agent
        assert "description" in agent
        assert "entrypoint" in agent
        assert "contract" in agent
        assert "capabilities" in agent
        assert "resources" in agent
        
        # Verify nested structures
        assert "inputs" in agent["contract"]
        assert "outputs" in agent["contract"]
        assert "type" in agent["entrypoint"]
        assert "stateful" in agent["capabilities"]
        assert "max_runtime_s" in agent["resources"]


class TestWorkflowContracts:
    """Test workflow data format contracts."""
    
    def test_workflow_structure(self):
        """Test that workflow objects have required fields."""
        workflow = {
            "name": "test_workflow",
            "description": "Test workflow",
            "nodes": [
                {
                    "id": "node-1",
                    "type": "agent",
                    "position": {"x": 100, "y": 100},
                    "data": {
                        "label": "Test Node",
                        "agentId": "test_agent",
                        "config": {}
                    }
                }
            ],
            "edges": [
                {
                    "id": "edge-1",
                    "source": "node-1",
                    "target": "node-2"
                }
            ]
        }
        
        # Verify required fields
        assert "name" in workflow
        assert "nodes" in workflow
        assert "edges" in workflow
        
        # Verify node structure
        node = workflow["nodes"][0]
        assert "id" in node
        assert "type" in node
        assert "position" in node
        assert "data" in node
        assert "x" in node["position"]
        assert "y" in node["position"]
        
        # Verify edge structure
        edge = workflow["edges"][0]
        assert "id" in edge
        assert "source" in edge
        assert "target" in edge


class TestJobContracts:
    """Test job data format contracts."""
    
    def test_job_structure(self):
        """Test that job objects have required fields."""
        job = {
            "job_id": "job-123",
            "workflow_name": "test_workflow",
            "status": "running",
            "progress": 50,
            "started_at": "2025-01-01T00:00:00",
            "current_node": "node-1"
        }
        
        # Verify required fields
        assert "job_id" in job
        assert "workflow_name" in job
        assert "status" in job
        assert "progress" in job
        assert "started_at" in job
        
        # Verify status is valid
        valid_statuses = ["pending", "running", "paused", "completed", "failed", "cancelled"]
        assert job["status"] in valid_statuses
        
        # Verify progress is percentage
        assert 0 <= job["progress"] <= 100
    
    def test_job_status_structure(self):
        """Test that job status objects have required fields."""
        status = {
            "job_id": "job-123",
            "status": "running",
            "progress": 50,
            "current_node": "node-1",
            "logs": [
                {
                    "timestamp": "2025-01-01T00:00:00",
                    "level": "info",
                    "node_id": "node-1",
                    "message": "Processing..."
                }
            ],
            "metrics": {
                "nodes_completed": 5,
                "nodes_total": 10,
                "runtime_seconds": 120
            }
        }
        
        # Verify required fields
        assert "job_id" in status
        assert "status" in status
        assert "progress" in status
        assert "logs" in status
        
        # Verify log entry structure
        if status["logs"]:
            log = status["logs"][0]
            assert "timestamp" in log
            assert "level" in log
            assert "message" in log
            
            # Verify log level is valid
            valid_levels = ["info", "warning", "error", "debug"]
            assert log["level"] in valid_levels


class TestWebSocketContracts:
    """Test WebSocket event format contracts."""
    
    def test_websocket_event_structure(self):
        """Test that WebSocket events have required fields."""
        event = {
            "type": "NODE.START",
            "timestamp": "2025-01-01T00:00:00",
            "job_id": "job-123",
            "data": {
                "node_id": "node-1"
            }
        }
        
        # Verify required fields
        assert "type" in event
        assert "timestamp" in event
        assert "job_id" in event
        assert "data" in event
        
        # Verify event type format
        assert "." in event["type"]  # Should be in format CATEGORY.ACTION
    
    def test_websocket_command_structure(self):
        """Test that WebSocket commands have required fields."""
        command = {
            "type": "CONTROL.PAUSE",
            "params": {
                "job_id": "job-123"
            }
        }
        
        # Verify required fields
        assert "type" in command
        assert "params" in command or command.get("params") is None


class TestAPIResponseContracts:
    """Test API response format contracts."""
    
    def test_mcp_response_structure(self):
        """Test that MCP responses have required fields."""
        response = {
            "result": {
                "job_id": "job-123",
                "status": "success"
            },
            "id": "request-123"
        }
        
        # Verify required fields
        assert "result" in response or "error" in response
        
        # If error, verify error structure
        error_response = {
            "error": {
                "code": -32603,
                "message": "Internal error"
            },
            "id": "request-123"
        }
        
        if "error" in error_response:
            assert "code" in error_response["error"]
            assert "message" in error_response["error"]
    
    def test_agents_list_response(self):
        """Test agents list response format."""
        response = {
            "agents": {
                "agent_1": {
                    "id": "agent_1",
                    "version": "1.0.0",
                    "description": "Test agent"
                }
            }
        }
        
        assert "agents" in response
        assert isinstance(response["agents"], dict)
    
    def test_jobs_list_response(self):
        """Test jobs list response format."""
        response = {
            "jobs": [
                {
                    "job_id": "job-123",
                    "workflow_name": "test",
                    "status": "running",
                    "progress": 50,
                    "started_at": "2025-01-01T00:00:00"
                }
            ]
        }
        
        assert "jobs" in response
        assert isinstance(response["jobs"], list)


class TestConfigContracts:
    """Test configuration data format contracts."""
    
    def test_config_snapshot_structure(self):
        """Test config snapshot response format."""
        config = {
            "status": "success",
            "config": {
                "hash": "abc123",
                "timestamp": "2025-01-01T00:00:00",
                "engine_version": "1.0.0",
                "agent_count": 10,
                "workflows": ["workflow1", "workflow2"]
            }
        }
        
        assert "status" in config
        assert "config" in config
        assert "hash" in config["config"]
        assert "workflows" in config["config"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
