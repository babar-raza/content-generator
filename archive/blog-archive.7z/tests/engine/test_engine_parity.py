"""Engine Parity Tests - Verify Sequential and LangGraph modes produce identical outputs."""

import unittest
import tempfile
import shutil
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core import Config, EventBus, AgentEvent
from src.orchestration.production_execution_engine import ProductionExecutionEngine, AgentFactory
from src.orchestration.checkpoint_manager import CheckpointManager


class TestEngineParity(unittest.TestCase):
    """Test that LangGraph and Sequential execution produce equivalent results."""
    
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.config = Config()
        self.config.output_dir = Path(self.test_dir) / "output"
        self.config.chroma_db_path = Path(self.test_dir) / "chroma_db"
        self.config.cache_dir = Path(self.test_dir) / "cache"
        self.config.llm_provider = "OLLAMA"
        self.config.ollama_base_url = "http://localhost:11434"
        
        self.checkpoint_dir = Path(self.test_dir) / "checkpoints"
        self.checkpoint_manager = CheckpointManager(storage_path=self.checkpoint_dir)
    
    def tearDown(self):
        """Clean up test environment."""
        if self.test_dir and Path(self.test_dir).exists():
            shutil.rmtree(self.test_dir)
    
    def test_langgraph_import(self):
        """Test that LangGraph can be imported."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor, LANGGRAPH_AVAILABLE
            
            if not LANGGRAPH_AVAILABLE:
                self.skipTest("LangGraph not installed")
            
            self.assertTrue(LANGGRAPH_AVAILABLE)
        except ImportError:
            self.skipTest("LangGraph not installed")
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_state_structure_parity(self, mock_db, mock_llm):
        """Test that state structure is equivalent between modes."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor
            from src.orchestration.langgraph_state import WorkflowState
        except ImportError:
            self.skipTest("LangGraph not installed")
        
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        # Create engine
        prod_engine = ProductionExecutionEngine(self.config)
        
        # Define minimal workflow steps
        steps = [
            {'id': 'topic_identification', 'agent': 'topic_identification'},
            {'id': 'outline_creation', 'agent': 'outline_creation'}
        ]
        
        # Create LangGraph executor
        lg_executor = LangGraphExecutor(
            config=self.config,
            workflow_steps=steps,
            agent_factory=prod_engine.agent_factory,
            checkpoint_manager=self.checkpoint_manager
        )
        
        # Verify state structure
        from src.orchestration.langgraph_state import WorkflowState
        
        # Check required state keys
        required_keys = {
            'job_id', 'workflow_name', 'current_step', 'total_steps',
            'completed_steps', 'agent_outputs', 'shared_state', 
            'input_data', 'llm_calls', 'tokens_used'
        }
        
        state_annotations = WorkflowState.__annotations__
        for key in required_keys:
            self.assertIn(key, state_annotations)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_graph_building(self, mock_db, mock_llm):
        """Test that LangGraph graph is built correctly."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor
        except ImportError:
            self.skipTest("LangGraph not installed")
        
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        prod_engine = ProductionExecutionEngine(self.config)
        
        steps = [
            {'id': 'topic_identification', 'agent': 'topic_identification'},
            {'id': 'outline_creation', 'agent': 'outline_creation'}
        ]
        
        lg_executor = LangGraphExecutor(
            config=self.config,
            workflow_steps=steps,
            agent_factory=prod_engine.agent_factory,
            checkpoint_manager=self.checkpoint_manager
        )
        
        # Build graph
        graph = lg_executor.build_graph()
        
        # Verify graph structure
        self.assertIsNotNone(graph)
        self.assertIsNotNone(lg_executor.graph)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_checkpoint_compatibility(self, mock_db, mock_llm):
        """Test that checkpoints are compatible between modes."""
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        # Create checkpoint in sequential mode format
        job_id = "test-job-123"
        step_name = "outline_creation"
        
        sequential_state = {
            'workflow_name': 'test_workflow',
            'current_step': 2,
            'shared_state': {
                'topic': 'Python Testing',
                'outline': {'sections': ['intro', 'body', 'conclusion']}
            },
            'agent_outputs': {
                'topic_identification': {'status': 'completed', 'output_data': {}},
                'outline_creation': {'status': 'completed', 'output_data': {}}
            },
            'llm_calls': 5,
            'tokens_used': 1000,
            'completed_steps': ['topic_identification', 'outline_creation']
        }
        
        # Save checkpoint
        checkpoint_id = self.checkpoint_manager.save(job_id, step_name, sequential_state)
        
        # Restore checkpoint
        restored = self.checkpoint_manager.restore(job_id, checkpoint_id)
        
        # Verify state structure matches
        self.assertEqual(restored['workflow_name'], sequential_state['workflow_name'])
        self.assertEqual(restored['current_step'], sequential_state['current_step'])
        self.assertEqual(restored['shared_state'], sequential_state['shared_state'])
        self.assertEqual(restored['llm_calls'], sequential_state['llm_calls'])
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_agent_input_preparation(self, mock_db, mock_llm):
        """Test that agent inputs are prepared identically in both modes."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor
            from src.orchestration.langgraph_state import WorkflowState
        except ImportError:
            self.skipTest("LangGraph not installed")
        
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        prod_engine = ProductionExecutionEngine(self.config)
        
        steps = [{'id': 'section_writer', 'agent': 'section_writer'}]
        
        lg_executor = LangGraphExecutor(
            config=self.config,
            workflow_steps=steps,
            agent_factory=prod_engine.agent_factory,
            checkpoint_manager=self.checkpoint_manager
        )
        
        # Create test state
        test_state: WorkflowState = {
            'job_id': 'test-123',
            'workflow_name': 'test',
            'current_step': 1,
            'total_steps': 2,
            'completed_steps': [],
            'agent_outputs': {},
            'shared_state': {
                'outline': {'sections': ['intro', 'body']},
                'topic': 'Python Testing'
            },
            'input_data': {'topic': 'Python Testing'},
            'llm_calls': 0,
            'tokens_used': 0
        }
        
        # Prepare input for section_writer
        agent_input = lg_executor._prepare_agent_input('section_writer', test_state)
        
        # Verify expected keys
        self.assertIn('outline', agent_input)
        self.assertIn('topic', agent_input)
        self.assertEqual(agent_input['outline'], test_state['shared_state']['outline'])
        self.assertEqual(agent_input['topic'], test_state['shared_state']['topic'])
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_output_format_parity(self, mock_db, mock_llm):
        """Test that output format is equivalent between modes."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor
            from src.orchestration.langgraph_state import WorkflowState
        except ImportError:
            self.skipTest("LangGraph not installed")
        
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        prod_engine = ProductionExecutionEngine(self.config)
        
        steps = [{'id': 'topic_identification', 'agent': 'topic_identification'}]
        
        lg_executor = LangGraphExecutor(
            config=self.config,
            workflow_steps=steps,
            agent_factory=prod_engine.agent_factory,
            checkpoint_manager=self.checkpoint_manager
        )
        
        # Create final state
        final_state: WorkflowState = {
            'job_id': 'test-123',
            'workflow_name': 'test',
            'current_step': 1,
            'total_steps': 1,
            'completed_steps': ['topic_identification'],
            'agent_outputs': {
                'topic_identification': {
                    'status': 'completed',
                    'output_data': {'topic': 'Python Testing'},
                    'execution_time': 1.5,
                    'llm_calls': 1,
                    'tokens_used': 100
                }
            },
            'shared_state': {'topic': 'Python Testing'},
            'input_data': {},
            'llm_calls': 1,
            'tokens_used': 100,
            'total_duration': 2.0
        }
        
        # Format results
        results = lg_executor._format_results(final_state)
        
        # Verify output structure matches sequential format
        required_keys = {
            'workflow_name', 'agent_outputs', 'shared_state',
            'llm_calls', 'tokens_used', 'total_duration', 'completed_steps'
        }
        
        for key in required_keys:
            self.assertIn(key, results)
        
        self.assertEqual(results['workflow_name'], 'test')
        self.assertEqual(results['llm_calls'], 1)
        self.assertEqual(len(results['completed_steps']), 1)
    
    @patch('src.orchestration.production_execution_engine.LLMService')
    @patch('src.orchestration.production_execution_engine.DatabaseService')
    def test_conditional_branching(self, mock_db, mock_llm):
        """Test conditional branching logic."""
        try:
            from src.orchestration.langgraph_executor import LangGraphExecutor
            from src.orchestration.langgraph_state import WorkflowState
        except ImportError:
            self.skipTest("LangGraph not installed")
        
        # Mock services
        mock_llm_instance = MagicMock()
        mock_db_instance = MagicMock()
        mock_llm.return_value = mock_llm_instance
        mock_db.return_value = mock_db_instance
        
        prod_engine = ProductionExecutionEngine(self.config)
        
        steps = [
            {'id': 'code_generation', 'agent': 'code_generation'},
            {'id': 'code_validation', 'agent': 'code_validation'}
        ]
        
        lg_executor = LangGraphExecutor(
            config=self.config,
            workflow_steps=steps,
            agent_factory=prod_engine.agent_factory,
            checkpoint_manager=self.checkpoint_manager
        )
        
        # Test with code generated
        state_with_code: WorkflowState = {
            'job_id': 'test',
            'workflow_name': 'test',
            'current_step': 1,
            'total_steps': 2,
            'completed_steps': [],
            'agent_outputs': {},
            'shared_state': {},
            'input_data': {},
            'llm_calls': 0,
            'tokens_used': 0,
            'code_generated': True
        }
        
        result_with_code = lg_executor._should_validate_code(state_with_code)
        self.assertEqual(result_with_code, 'validate')
        
        # Test without code
        state_no_code: WorkflowState = {
            'job_id': 'test',
            'workflow_name': 'test',
            'current_step': 1,
            'total_steps': 2,
            'completed_steps': [],
            'agent_outputs': {},
            'shared_state': {},
            'input_data': {},
            'llm_calls': 0,
            'tokens_used': 0,
            'code_generated': False
        }
        
        result_no_code = lg_executor._should_validate_code(state_no_code)
        self.assertEqual(result_no_code, 'skip')
    
    def test_fallback_to_sequential(self):
        """Test that system falls back to sequential if LangGraph fails."""
        # Set use_langgraph but LangGraph not available
        self.config.use_langgraph = True
        
        # This should handle the fallback gracefully
        # The actual test would be in integration but we verify the config flag exists
        self.assertTrue(hasattr(self.config, 'use_langgraph'))


class TestLangGraphState(unittest.TestCase):
    """Test LangGraph state definitions."""
    
    def test_workflow_state_structure(self):
        """Test WorkflowState TypedDict structure."""
        try:
            from src.orchestration.langgraph_state import WorkflowState
        except ImportError:
            self.skipTest("LangGraph state module not available")
        
        # Verify required fields
        required_fields = {
            'job_id', 'workflow_name', 'current_step', 'total_steps',
            'completed_steps', 'agent_outputs', 'shared_state',
            'input_data', 'llm_calls', 'tokens_used'
        }
        
        state_annotations = WorkflowState.__annotations__
        for field in required_fields:
            self.assertIn(field, state_annotations)
    
    def test_agent_output_structure(self):
        """Test AgentOutput TypedDict structure."""
        try:
            from src.orchestration.langgraph_state import AgentOutput
        except ImportError:
            self.skipTest("LangGraph state module not available")
        
        required_fields = {
            'agent_id', 'status', 'output_data', 'execution_time',
            'llm_calls', 'tokens_used'
        }
        
        output_annotations = AgentOutput.__annotations__
        for field in required_fields:
            self.assertIn(field, output_annotations)


if __name__ == '__main__':
    unittest.main()
# DOCGEN:LLM-FIRST@v4