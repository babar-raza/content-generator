"""Comprehensive tests for services module.

Tests all 6 services with mocked external dependencies:
- LLMService (with fallback chain Ollama → Gemini → OpenAI)
- DatabaseService (ChromaDB)
- EmbeddingService (sentence-transformers)
- GistService (GitHub API)
- TrendsService (Google Trends)
- LinkChecker (HTTP validation)
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, call
from pathlib import Path
import tempfile
import json
from datetime import datetime

from src.core.config import Config
from src.services import (
    LLMService,
    DatabaseService,
    EmbeddingService,
    GistService,
    LinkChecker,
    TrendsService,
)

from tests.fixtures.mock_responses import (
    OLLAMA_TAGS_RESPONSE,
    OLLAMA_GENERATE_RESPONSE,
    GEMINI_GENERATE_RESPONSE,
    OPENAI_CHAT_RESPONSE,
    CHROMADB_COLLECTION_RESPONSE,
    CHROMADB_QUERY_RESPONSE,
    EMBEDDING_VECTOR,
    GIST_CREATE_RESPONSE,
    GIST_GET_RESPONSE,
    PYTRENDS_INTEREST_RESPONSE,
    LINK_CHECK_SUCCESS,
    LINK_CHECK_NOT_FOUND,
)


@pytest.fixture
def test_config():
    """Create a test configuration object."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = Mock(spec=Config)
        config.cache_dir = tmpdir
        config.gemini_rpm_limit = 60
        config.llm_provider = "OLLAMA"
        config.llm_temperature = 0.7
        config.llm_top_p = 0.9
        config.global_seed = 42
        config.deterministic = False
        config.cache_ttl = 3600
        config.ollama_topic_model = "llama2"
        config.gemini_api_key = None
        config.openai_api_key = None
        config.github_token = "test_token"
        config.chroma_persist_directory = str(Path(tmpdir) / "chroma")
        config.embedding_model = "all-MiniLM-L6-v2"
        yield config


class TestLLMService:
    """Test LLMService functionality including provider fallback."""

    def test_initialization_ollama(self, test_config):
        """Test LLMService initialization with Ollama provider."""
        with patch('requests.get') as mock_get:
            mock_get.return_value.status_code = 200
            
            service = LLMService(test_config)
            
            assert service.config == test_config
            assert "OLLAMA" in service.provider_priority
            mock_get.assert_called_once()

    def test_initialization_gemini_missing_key(self, test_config):
        """Test LLMService fails when Gemini selected but no API key."""
        test_config.llm_provider = "GEMINI"
        test_config.gemini_api_key = None
        
        with pytest.raises(ValueError, match="GEMINI_API_KEY"):
            LLMService(test_config)

    def test_initialization_openai_missing_key(self, test_config):
        """Test LLMService fails when OpenAI selected but no API key."""
        test_config.llm_provider = "OPENAI"
        test_config.openai_api_key = None
        
        with pytest.raises(ValueError, match="OPENAI_API_KEY"):
            LLMService(test_config)

    def test_generate_ollama_success(self, test_config):
        """Test successful text generation with Ollama."""
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post:
            
            # Mock Ollama availability check
            mock_get.return_value.status_code = 200
            
            # Mock Ollama generate response
            mock_response = Mock()
            mock_response.json.return_value = OLLAMA_GENERATE_RESPONSE
            mock_response.status_code = 200
            mock_post.return_value = mock_response
            
            service = LLMService(test_config)
            result = service.generate("Test prompt")
            
            assert isinstance(result, str)
            assert len(result) > 0
            mock_post.assert_called_once()

    def test_generate_fallback_to_gemini(self, test_config):
        """Test fallback from Ollama to Gemini when Ollama fails."""
        test_config.gemini_api_key = "test_key"
        
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post:
            
            # Mock Ollama availability
            mock_get.return_value.status_code = 200
            
            # Mock Ollama failure then Gemini success
            mock_post.side_effect = [
                Exception("Ollama connection failed"),  # First call fails
            ]
            
            with patch('google.generativeai.GenerativeModel') as mock_gemini:
                mock_model = Mock()
                mock_model.generate_content.return_value.text = "Gemini response"
                mock_gemini.return_value = mock_model
                
                service = LLMService(test_config)
                result = service.generate("Test prompt")
                
                # Should get Gemini response after Ollama fails
                assert "Gemini" in result or result == "Gemini response"

    def test_generate_fallback_to_openai(self, test_config):
        """Test fallback chain: Ollama → Gemini → OpenAI."""
        test_config.gemini_api_key = "test_key"
        test_config.openai_api_key = "test_key"
        
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post:
            
            # Mock Ollama availability
            mock_get.return_value.status_code = 200
            
            # Both Ollama and Gemini fail
            mock_post.side_effect = [
                Exception("Ollama failed"),
            ]
            
            with patch('google.generativeai.GenerativeModel') as mock_gemini, \
                 patch('openai.OpenAI') as mock_openai:
                
                # Gemini fails
                mock_gemini.side_effect = Exception("Gemini failed")
                
                # OpenAI succeeds
                mock_client = Mock()
                mock_response = Mock()
                mock_response.choices = [Mock()]
                mock_response.choices[0].message.content = "OpenAI response"
                mock_client.chat.completions.create.return_value = mock_response
                mock_openai.return_value = mock_client
                
                service = LLMService(test_config)
                result = service.generate("Test prompt", provider="OPENAI")
                
                assert result == "OpenAI response"

    def test_generate_all_providers_fail(self, test_config):
        """Test exception raised when all providers fail."""
        test_config.gemini_api_key = "test_key"
        test_config.openai_api_key = "test_key"
        
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post:
            
            # Mock Ollama availability
            mock_get.return_value.status_code = 200
            
            # All providers fail
            mock_post.side_effect = Exception("Ollama failed")
            
            with patch('google.generativeai.GenerativeModel') as mock_gemini, \
                 patch('openai.OpenAI') as mock_openai:
                
                mock_gemini.side_effect = Exception("Gemini failed")
                mock_openai.side_effect = Exception("OpenAI failed")
                
                service = LLMService(test_config)
                
                with pytest.raises(Exception):
                    service.generate("Test prompt")

    def test_check_health(self, test_config):
        """Test provider health check functionality."""
        test_config.gemini_api_key = "test_key"
        test_config.openai_api_key = "test_key"
        
        with patch('requests.get') as mock_get:
            mock_get.return_value.status_code = 200
            
            service = LLMService(test_config)
            health = service.check_health()
            
            assert isinstance(health, dict)
            assert "OLLAMA" in health
            assert "GEMINI" in health
            assert "OPENAI" in health
            assert health["OLLAMA"] == True  # Ollama available
            assert health["GEMINI"] == True  # API key configured
            assert health["OPENAI"] == True  # API key configured

    def test_caching(self, test_config):
        """Test response caching functionality."""
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post:
            
            mock_get.return_value.status_code = 200
            
            mock_response = Mock()
            mock_response.json.return_value = OLLAMA_GENERATE_RESPONSE
            mock_response.status_code = 200
            mock_post.return_value = mock_response
            
            service = LLMService(test_config)
            
            # First call
            result1 = service.generate("Test prompt")
            
            # Second call with same prompt (should use cache)
            result2 = service.generate("Test prompt")
            
            assert result1 == result2
            # Should only call API once due to caching
            assert mock_post.call_count == 1


class TestDatabaseService:
    """Test DatabaseService (ChromaDB wrapper)."""

    def test_initialization(self, test_config):
        """Test DatabaseService initialization."""
        with patch('chromadb.Client') as mock_client:
            service = DatabaseService(test_config)
            assert service.config == test_config

    def test_get_or_create_collection(self, test_config):
        """Test collection creation."""
        with patch('chromadb.Client') as mock_client:
            mock_collection = Mock()
            mock_client.return_value.get_or_create_collection.return_value = mock_collection
            
            service = DatabaseService(test_config)
            collection = service.get_or_create_collection("test_collection")
            
            assert collection is not None


class TestEmbeddingService:
    """Test EmbeddingService (sentence-transformers)."""

    def test_initialization(self, test_config):
        """Test EmbeddingService initialization."""
        with patch('sentence_transformers.SentenceTransformer') as mock_model:
            service = EmbeddingService(test_config)
            assert service.config == test_config
            mock_model.assert_called_once()

    def test_encode_text(self, test_config):
        """Test text encoding to embeddings."""
        with patch('sentence_transformers.SentenceTransformer') as mock_model:
            mock_instance = Mock()
            mock_instance.encode.return_value = EMBEDDING_VECTOR
            mock_model.return_value = mock_instance
            
            service = EmbeddingService(test_config)
            embedding = service.encode("Test text")
            
            assert isinstance(embedding, list)
            assert len(embedding) > 0
            mock_instance.encode.assert_called_once()


class TestGistService:
    """Test GistService (GitHub Gist API)."""

    def test_initialization(self, test_config):
        """Test GistService initialization."""
        service = GistService(test_config)
        assert service.config == test_config
        assert service.token == test_config.github_token

    def test_create_gist(self, test_config):
        """Test Gist creation."""
        with patch('requests.post') as mock_post:
            mock_response = Mock()
            mock_response.json.return_value = GIST_CREATE_RESPONSE
            mock_response.status_code = 201
            mock_post.return_value = mock_response
            
            service = GistService(test_config)
            result = service.create_gist(
                filename="test.cs",
                content="// Test code",
                description="Test gist"
            )
            
            assert "url" in result
            assert "html_url" in result
            mock_post.assert_called_once()

    def test_get_gist(self, test_config):
        """Test fetching existing Gist."""
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = GIST_GET_RESPONSE
            mock_response.status_code = 200
            mock_get.return_value = mock_response
            
            service = GistService(test_config)
            result = service.get_gist("abc123def456")
            
            assert result["id"] == "abc123def456"
            mock_get.assert_called_once()


class TestTrendsService:
    """Test TrendsService (Google Trends via pytrends)."""

    def test_initialization(self, test_config):
        """Test TrendsService initialization."""
        with patch('pytrends.request.TrendReq'):
            service = TrendsService(test_config)
            assert service.config == test_config

    def test_get_interest_over_time(self, test_config):
        """Test fetching interest over time data."""
        with patch('pytrends.request.TrendReq') as mock_trends:
            mock_instance = Mock()
            mock_instance.interest_over_time.return_value = PYTRENDS_INTEREST_RESPONSE
            mock_trends.return_value = mock_instance
            
            service = TrendsService(test_config)
            result = service.get_interest_over_time(["python", "javascript"])
            
            assert result is not None
            mock_instance.build_payload.assert_called_once()
            mock_instance.interest_over_time.assert_called_once()


class TestLinkChecker:
    """Test LinkChecker (HTTP link validation)."""

    def test_initialization(self, test_config):
        """Test LinkChecker initialization."""
        service = LinkChecker(test_config)
        assert service.config == test_config

    def test_check_link_success(self, test_config):
        """Test successful link validation."""
        with patch('requests.head') as mock_head:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_head.return_value = mock_response
            
            service = LinkChecker(test_config)
            is_valid = service.check_link("https://example.com")
            
            assert is_valid == True
            mock_head.assert_called_once()

    def test_check_link_not_found(self, test_config):
        """Test link validation with 404 response."""
        with patch('requests.head') as mock_head:
            mock_response = Mock()
            mock_response.status_code = 404
            mock_head.return_value = mock_response
            
            service = LinkChecker(test_config)
            is_valid = service.check_link("https://example.com/notfound")
            
            assert is_valid == False

    def test_check_link_with_retry(self, test_config):
        """Test link validation with retry on timeout."""
        with patch('requests.head') as mock_head:
            # First call times out, second succeeds
            mock_head.side_effect = [
                Exception("Timeout"),
                Mock(status_code=200)
            ]
            
            service = LinkChecker(test_config)
            is_valid = service.check_link("https://example.com", max_retries=2)
            
            assert is_valid == True
            assert mock_head.call_count == 2


class TestServiceIntegration:
    """Test services working together."""

    def test_llm_with_embeddings(self, test_config):
        """Test LLM service generating text that gets embedded."""
        with patch('requests.get') as mock_get, \
             patch('requests.post') as mock_post, \
             patch('sentence_transformers.SentenceTransformer') as mock_model:
            
            # Mock Ollama
            mock_get.return_value.status_code = 200
            mock_response = Mock()
            mock_response.json.return_value = OLLAMA_GENERATE_RESPONSE
            mock_response.status_code = 200
            mock_post.return_value = mock_response
            
            # Mock embeddings
            mock_instance = Mock()
            mock_instance.encode.return_value = EMBEDDING_VECTOR
            mock_model.return_value = mock_instance
            
            llm_service = LLMService(test_config)
            embedding_service = EmbeddingService(test_config)
            
            # Generate text
            text = llm_service.generate("Write about Python")
            
            # Embed it
            embedding = embedding_service.encode(text)
            
            assert len(embedding) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
# DOCGEN:LLM-FIRST@v4