"""MCP protocol compliance tests for job creation, listing and retrieval.

These tests issue requests to the ``/mcp/request`` endpoint using a
``TestClient`` and verify that the responses conform to the MCP protocol
specification.  In particular they check the structure of the returned
objects for job creation, listing and getting an individual job.  The
tests run synchronously against the unified engine, which blocks until
completion, so the returned job status should already be ``COMPLETED``.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from src.engine.unified_engine import UnifiedEngine
from src.web.app import create_app
from src.mcp.protocol import MCPRequest

from tests.integration.test_full_pipeline import get_fixture_path


@pytest.fixture
def mcp_client(tmp_path: Path):
    """Provide a TestClient bound to a new engine for MCP testing."""
    engine = UnifiedEngine()
    app = create_app(engine, engine.config_snapshot)
    client = TestClient(app)
    yield client


def test_mcp_job_lifecycle(mcp_client: TestClient) -> None:
    """Create a job via MCP, list jobs, then retrieve the job details."""
    # Submit a new job
    req_create = MCPRequest(
        method="jobs/create",
        params={
            "workflow_name": "default",
            "input_data": {"topic": "MCP Lifecycle"},
            "params": {},
            "blog_mode": False,
            "title": None,
        },
        id="1",
    )
    resp_create = mcp_client.post("/mcp/request", json=json.loads(req_create.model_dump_json()))
    assert resp_create.status_code == 200
    job_res = resp_create.json()["result"]
    job_id = job_res["job_id"]
    assert job_id, "job_id missing from creation response"

    # List jobs
    req_list = MCPRequest(
        method="jobs/list",
        params={},
        id="2",
    )
    resp_list = mcp_client.post("/mcp/request", json=json.loads(req_list.model_dump_json()))
    assert resp_list.status_code == 200
    jobs = resp_list.json()["result"]
    assert isinstance(jobs, list), "jobs/list should return a list"
    # Our job should appear in the list
    assert any(j["job_id"] == job_id for j in jobs)

    # Get specific job
    req_get = MCPRequest(
        method="jobs/get",
        params={"job_id": job_id},
        id="3",
    )
    resp_get = mcp_client.post("/mcp/request", json=json.loads(req_get.model_dump_json()))
    assert resp_get.status_code == 200
    job_detail = resp_get.json()["result"]
    assert job_detail["job_id"] == job_id
    assert job_detail["status"] in {"completed", "partial", "failed"}
    # Metadata should include output_path when completed
    metadata = job_detail.get("metadata", {})
    assert "output_path" in metadata
    # Additional fields such as created_at should be ISO formatted strings
    assert "created_at" in job_detail
    assert "T" in job_detail["created_at"], "created_at should be ISO format"