"""End‑to‑end tests for the WebSocket real‑time update channel.

The realtime mesh endpoint exposes a WebSocket that accepts control
commands and streams job events.  These tests verify that clients can
connect, send commands and receive responses without needing to run a
full job.  It also checks error handling for unknown commands.  A
shared unified engine instance powers the FastAPI app used for the test.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from src.engine.unified_engine import UnifiedEngine, RunSpec, JobStatus
from src.web.app import create_app
from src.mcp.protocol import MCPRequest

from tests.integration.test_full_pipeline import get_fixture_path


@pytest.fixture
def websocket_client(tmp_path: Path):
    """Create a FastAPI TestClient with a global executor for WebSocket testing."""
    engine = UnifiedEngine()
    app = create_app(engine, engine.config_snapshot)
    client = TestClient(app)
    yield client


def test_websocket_connection_and_command(websocket_client: TestClient) -> None:
    """Connect to the WebSocket endpoint and issue an invalid command."""
    # First create a job via the API so we have a job_id to attach to
    kb_file = get_fixture_path("test_kb.md")
    req = MCPRequest(
        method="jobs/create",
        params={
            "workflow_name": "default",
            "input_data": {"topic": "WebSocket Test"},
            "params": {},
            "blog_mode": False,
            "title": None,
        },
        id="ws"
    )
    resp = websocket_client.post("/mcp/request", json=json.loads(req.model_dump_json()))
    assert resp.status_code == 200
    job_id = resp.json()["result"]["job_id"]

    # Open WebSocket connection for this job
    with websocket_client.websocket_connect(f"/ws/mesh?job={job_id}") as websocket:
        # Send an invalid command; should get error response
        websocket.send_json({"type": "INVALID", "params": {}})
        message = websocket.receive_json()
        assert message["data"]["status"] == "error"
        assert "Unknown command" in message["data"]["message"]