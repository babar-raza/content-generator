"""Tests for configuration hot reload behavior.

Tests the hot reload monitor functionality including:
- File watching and detection
- Config validation
- Reload triggering
- Rollback on error
- WebSocket notifications
"""

import asyncio
import json
import logging
import tempfile
import time
from pathlib import Path
from typing import List, Optional
from unittest.mock import MagicMock, patch, AsyncMock

import pytest
import yaml

from src.orchestration.hot_reload import (
    HotReloadMonitor,
    ReloadEvent,
    ConfigValidator,
)
from src.orchestration.agent_scanner import AgentScanner


logger = logging.getLogger(__name__)


@pytest.fixture
def temp_config_dir(tmp_path):
    """Create temporary config directory with test files."""
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    
    # Create agents.yaml
    agents_config = {
        "agents": {
            "test_agent": {
                "class": "TestAgent",
                "module": "test.module",
                "enabled": True
            }
        }
    }
    agents_file = config_dir / "agents.yaml"
    with open(agents_file, "w") as f:
        yaml.dump(agents_config, f)
    
    # Create workflows.yaml
    workflows_config = {
        "workflows": {
            "test_workflow": {
                "steps": [
                    {"agent": "test_agent", "action": "process"}
                ]
            }
        }
    }
    workflows_file = config_dir / "workflows.yaml"
    with open(workflows_file, "w") as f:
        yaml.dump(workflows_config, f)
    
    return config_dir


@pytest.fixture
def mock_event_bus():
    """Create mock event bus."""
    event_bus = MagicMock()
    event_bus.publish = MagicMock()
    return event_bus


@pytest.fixture
def reload_monitor(temp_config_dir, mock_event_bus):
    """Create hot reload monitor instance."""
    paths = [
        temp_config_dir / "agents.yaml",
        temp_config_dir / "workflows.yaml"
    ]
    
    monitor = HotReloadMonitor(
        paths=paths,
        event_bus=mock_event_bus
    )
    
    yield monitor
    
    # Cleanup
    if monitor._running:
        monitor.stop()


class TestConfigValidator:
    """Tests for configuration validation."""
    
    def test_validate_agents_config_valid(self):
        """Test validation of valid agents config."""
        config = {
            "agents": {
                "agent1": {
                    "class": "Agent1",
                    "enabled": True
                }
            }
        }
        
        is_valid, error = ConfigValidator.validate_agents_config(config)
        assert is_valid
        assert error is None
    
    def test_validate_agents_config_missing_agents_key(self):
        """Test validation fails when 'agents' key is missing."""
        config = {"other": "data"}
        
        is_valid, error = ConfigValidator.validate_agents_config(config)
        assert not is_valid
        assert "Missing 'agents' key" in error
    
    def test_validate_agents_config_missing_class(self):
        """Test validation fails when agent missing 'class' field."""
        config = {
            "agents": {
                "agent1": {
                    "enabled": True
                }
            }
        }
        
        is_valid, error = ConfigValidator.validate_agents_config(config)
        assert not is_valid
        assert "missing 'class' field" in error
    
    def test_validate_workflows_config_valid(self):
        """Test validation of valid workflows config."""
        config = {
            "workflows": {
                "workflow1": {
                    "steps": [
                        {"agent": "agent1", "action": "process"}
                    ]
                }
            }
        }
        
        is_valid, error = ConfigValidator.validate_workflows_config(config)
        assert is_valid
        assert error is None
    
    def test_validate_workflows_config_missing_steps(self):
        """Test validation fails when workflow missing 'steps' field."""
        config = {
            "workflows": {
                "workflow1": {
                    "name": "Test Workflow"
                }
            }
        }
        
        is_valid, error = ConfigValidator.validate_workflows_config(config)
        assert not is_valid
        assert "missing 'steps' field" in error


class TestHotReloadMonitor:
    """Tests for hot reload monitor functionality."""
    
    def test_monitor_initialization(self, temp_config_dir):
        """Test monitor initializes correctly."""
        paths = [temp_config_dir / "agents.yaml"]
        monitor = HotReloadMonitor(paths=paths)
        
        assert not monitor._running
        assert len(monitor.paths) == 1
        assert monitor.paths[0] == temp_config_dir / "agents.yaml"
    
    def test_monitor_start_stop(self, reload_monitor):
        """Test monitor can start and stop."""
        reload_monitor.start()
        assert reload_monitor._running
        assert len(reload_monitor._observers) > 0
        
        reload_monitor.stop()
        assert not reload_monitor._running
    
    def test_register_reload_callback(self, reload_monitor):
        """Test registering reload callbacks."""
        callback = MagicMock()
        
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        assert "agents.yaml" in reload_monitor._reload_callbacks
        assert reload_monitor._reload_callbacks["agents.yaml"] == callback
    
    def test_is_monitored_file(self, reload_monitor, temp_config_dir):
        """Test checking if file is monitored."""
        agents_file = temp_config_dir / "agents.yaml"
        other_file = temp_config_dir / "other.yaml"
        
        assert reload_monitor.is_monitored_file(agents_file)
        assert not reload_monitor.is_monitored_file(other_file)
    
    def test_reload_config_file_success(self, reload_monitor, temp_config_dir):
        """Test successful config file reload."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Modify file
        with open(agents_file, "a") as f:
            f.write("\n# Modified\n")
        
        # Reload
        success = reload_monitor.reload_config_file(agents_file)
        
        assert success
        assert callback.called
    
    def test_reload_config_file_validation_failure(self, reload_monitor, temp_config_dir):
        """Test reload fails with invalid config."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Write invalid config
        with open(agents_file, "w") as f:
            yaml.dump({"invalid": "config"}, f)
        
        # Reload should fail
        success = reload_monitor.reload_config_file(agents_file)
        
        assert not success
        assert not callback.called
    
    def test_reload_callback_execution(self, reload_monitor, temp_config_dir):
        """Test reload callback is executed with correct args."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Add comment to trigger change
        with open(agents_file, "a") as f:
            f.write("\n# Modified\n")
        
        reload_monitor.reload_config_file(agents_file)
        
        # Verify callback was called with file path and config data
        assert callback.called
        call_args = callback.call_args[0]
        assert call_args[0] == agents_file
        assert isinstance(call_args[1], dict)
        assert "agents" in call_args[1]
    
    def test_get_stats(self, reload_monitor):
        """Test getting reload statistics."""
        stats = reload_monitor.get_stats()
        
        assert "running" in stats
        assert "monitored_paths" in stats
        assert "total_reloads" in stats
        assert "failed_reloads" in stats
        assert "success_rate" in stats
        assert isinstance(stats["monitored_paths"], list)
    
    def test_force_reload(self, reload_monitor, temp_config_dir):
        """Test force reload functionality."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Force reload without file change
        reload_monitor.force_reload(agents_file)
        
        assert callback.called
    
    def test_event_bus_notification(self, reload_monitor, temp_config_dir, mock_event_bus):
        """Test event bus receives reload notifications."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Modify and reload
        with open(agents_file, "a") as f:
            f.write("\n# Modified\n")
        
        reload_monitor.reload_config_file(agents_file)
        
        # Verify event bus was notified
        assert mock_event_bus.publish.called


class TestHotReloadIntegration:
    """Integration tests for hot reload with agent scanner."""
    
    def test_agent_scanner_reload_integration(self, temp_config_dir):
        """Test hot reload triggers agent scanner reload."""
        # Create agent scanner
        scanner = AgentScanner()
        
        # Track reload calls
        reload_called = []
        
        def reload_callback(file_path, config_data):
            reload_called.append(True)
            scanner.trigger_reload()
        
        # Create monitor with callback
        monitor = HotReloadMonitor(
            paths=[temp_config_dir / "agents.yaml"]
        )
        monitor.register_reload_callback("agents.yaml", reload_callback)
        
        # Modify agents.yaml
        agents_file = temp_config_dir / "agents.yaml"
        with open(agents_file, "a") as f:
            f.write("\n# Trigger reload\n")
        
        # Trigger reload
        success = monitor.reload_config_file(agents_file)
        
        assert success
        assert len(reload_called) > 0
        
        # Cleanup
        monitor.stop()


@pytest.mark.asyncio
class TestWebSocketNotification:
    """Tests for WebSocket notification on config reload."""
    
    async def test_websocket_notification_on_reload(self, temp_config_dir, mock_event_bus):
        """Test WebSocket clients are notified of config reload."""
        monitor = HotReloadMonitor(
            paths=[temp_config_dir / "agents.yaml"],
            event_bus=mock_event_bus
        )
        
        callback = MagicMock()
        monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Modify file
        with open(agents_file, "a") as f:
            f.write("\n# Modified\n")
        
        # Reload
        success = monitor.reload_config_file(agents_file)
        
        assert success
        
        # Check event bus was used to publish reload event
        assert mock_event_bus.publish.called
        
        # Get the published event
        call_args = mock_event_bus.publish.call_args[0]
        event = call_args[0]
        
        # Verify event structure
        assert event.event_type == "config.reloaded"
        assert event.source_agent == "hot_reload_monitor"
        assert "file_path" in event.data
        
        monitor.stop()


class TestFileWatching:
    """Tests for file watching functionality."""
    
    def test_file_change_detection(self, reload_monitor, temp_config_dir):
        """Test file changes are detected."""
        reload_monitor.start()
        
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Give monitor time to start watching
        time.sleep(0.5)
        
        # Modify file
        with open(agents_file, "a") as f:
            f.write("\n# Auto-detected change\n")
        
        # Wait for debounce and processing
        time.sleep(2.0)
        
        # Callback should have been triggered
        assert callback.called
    
    def test_debouncing(self, reload_monitor, temp_config_dir):
        """Test that rapid changes are debounced."""
        reload_monitor.start()
        
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Give monitor time to start
        time.sleep(0.5)
        
        # Make multiple rapid changes
        for i in range(5):
            with open(agents_file, "a") as f:
                f.write(f"\n# Change {i}\n")
            time.sleep(0.1)  # 100ms between changes
        
        # Wait for debounce (1 second) + processing
        time.sleep(2.0)
        
        # Should only be called once due to debouncing
        assert callback.call_count == 1


class TestRollback:
    """Tests for config rollback on error."""
    
    def test_rollback_on_validation_failure(self, reload_monitor, temp_config_dir):
        """Test config is rolled back when validation fails."""
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Create initial snapshot
        reload_monitor._create_snapshot(agents_file)
        
        # Write invalid config
        with open(agents_file, "w") as f:
            yaml.dump({"invalid": "config"}, f)
        
        # Try to reload - should fail and rollback
        success = reload_monitor.reload_config_file(agents_file)
        
        assert not success
        assert not callback.called
        
        # Verify stats show failure
        stats = reload_monitor.get_stats()
        assert stats["failed_reloads"] > 0
    
    def test_rollback_on_callback_failure(self, reload_monitor, temp_config_dir):
        """Test rollback when callback raises exception."""
        def failing_callback(file_path, config_data):
            raise RuntimeError("Callback failed")
        
        reload_monitor.register_reload_callback("agents.yaml", failing_callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        
        # Create snapshot
        reload_monitor._create_snapshot(agents_file)
        
        # Modify file
        with open(agents_file, "a") as f:
            f.write("\n# Modified\n")
        
        # Reload should fail but not crash
        success = reload_monitor.reload_config_file(agents_file)
        
        assert not success
        
        # Check failure was recorded
        stats = reload_monitor.get_stats()
        assert stats["failed_reloads"] > 0


class TestThreadSafety:
    """Tests for thread-safe operations."""
    
    def test_concurrent_reloads(self, reload_monitor, temp_config_dir):
        """Test multiple concurrent reload operations are thread-safe."""
        import threading
        
        callback = MagicMock()
        reload_monitor.register_reload_callback("agents.yaml", callback)
        
        agents_file = temp_config_dir / "agents.yaml"
        workflows_file = temp_config_dir / "workflows.yaml"
        
        results = []
        
        def reload_file(file_path):
            success = reload_monitor.reload_config_file(file_path)
            results.append(success)
        
        # Start multiple threads
        threads = [
            threading.Thread(target=reload_file, args=(agents_file,)),
            threading.Thread(target=reload_file, args=(agents_file,)),
            threading.Thread(target=reload_file, args=(workflows_file,)),
        ]
        
        for thread in threads:
            thread.start()
        
        for thread in threads:
            thread.join()
        
        # All should complete without crashing
        assert len(results) == 3


def test_hot_reload():
    """Main test function that can be run with pytest."""
    pytest.main([__file__, "-v", "-k", "test_hot_reload"])


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])
