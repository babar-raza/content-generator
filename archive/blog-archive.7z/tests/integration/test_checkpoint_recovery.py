"""Integration tests for checkpoint save, restore and cleanup scenarios.

These tests focus on the ``CheckpointManager`` and its interaction
with job execution.  While the unified engine does not yet emit
checkpoints automatically, the manager can be used independently
to persist arbitrary workflow state.  The tests exercise listing,
restoration, deletion and cleanup of checkpoints.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict

import pytest

from src.orchestration.checkpoint_manager import CheckpointManager


@pytest.fixture
def checkpoint_dir(tmp_path: Path) -> Path:
    """Return a temporary directory for storing checkpoints."""
    return tmp_path / ".checkpoints"


def test_checkpoint_save_restore_delete_cleanup(checkpoint_dir: Path) -> None:
    """Verify that checkpoints can be saved, restored, deleted and cleaned up."""
    manager = CheckpointManager(storage_path=checkpoint_dir)
    job_id = "chkjob"
    state: Dict[str, int] = {"counter": 42}

    # Save a checkpoint
    cp_id = manager.save(job_id, "step", state)
    assert cp_id
    assert any(cp.checkpoint_id == cp_id for cp in manager.list(job_id))

    # Restore the checkpoint
    restored = manager.restore(job_id, cp_id)
    assert restored == state

    # Delete and verify removal
    manager.delete(job_id, cp_id)
    assert not manager.list(job_id)

    # Create multiple checkpoints for cleanup
    ids = []
    for i in range(5):
        ids.append(manager.save(job_id, f"step{i}", {"i": i}))
    # Keep only the latest two
    manager.cleanup(job_id, keep_last=2)
    remaining = manager.list(job_id)
    assert len(remaining) == 2
    # The remaining checkpoints should correspond to the last two saved
    remaining_ids = [cp.checkpoint_id for cp in remaining]
    assert all(rid in ids[-2:] for rid in remaining_ids)